/**
 * 
 */
package ca.uhn.example.model;

import ca.uhn.fhir.model.api.annotation.ResourceDef;
import ca.uhn.fhir.model.dstu2.resource.Bundle;

/**
 * @author heerendra.singh
 *
 */
@ResourceDef(name="CarePlanBundle", profile="http://hl7.org/fhir/profiles/Bundle", id="carePlanBundle")
public class CarePlanBundle extends Bundle {

	/**
	 * 
	 */
	public CarePlanBundle() {
		super();
	}

}
