package ca.uhn.example.provider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import ca.uhn.example.model.CarePlanBundle;
import ca.uhn.fhir.model.dstu2.composite.AnnotationDt;
import ca.uhn.fhir.model.dstu2.composite.CodeableConceptDt;
import ca.uhn.fhir.model.dstu2.resource.Bundle;
import ca.uhn.fhir.model.dstu2.resource.Bundle.Entry;
import ca.uhn.fhir.model.dstu2.resource.CarePlan;
import ca.uhn.fhir.model.dstu2.valueset.BundleTypeEnum;
import ca.uhn.fhir.model.dstu2.valueset.CarePlanActivityStatusEnum;
import ca.uhn.fhir.model.dstu2.valueset.CarePlanStatusEnum;
import ca.uhn.fhir.model.primitive.IdDt;
import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.rest.server.IResourceProvider;
import ca.uhn.fhir.rest.server.exceptions.ResourceNotFoundException;

/**
 * All resource providers must implement IResourceProvider
 */
public class CarePlanResourceProvider implements IResourceProvider {

	/**
	 * This map has a resource ID as a key, and each key maps to a Deque list
	 * containing all versions of the resource with that ID.
	 */
	private Map<String, Deque<CarePlanBundle>> myIdToBundleVersions = new HashMap<String, Deque<CarePlanBundle>>();

	public CarePlanResourceProvider() {
		Connection conn = null;
		Statement statement = null;
		ResultSet rs = null;
		try {
			String db_connect_string = "jdbc:sqlserver://smd-HYD-sql1:1433;databaseName=Analytics_v830_interfaces";
			String db_userid = "devuser";
			String db_password = "Spectramd1234";

			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(db_connect_string, db_userid, db_password);
			statement = conn.createStatement();

			String queryString = "select * from Administration.Patient ORDER BY RecordId";

			rs = statement.executeQuery(queryString);

			CarePlanBundle bundle = new CarePlanBundle();
			bundle.setId(UUID.randomUUID().toString()); // Need to fix
			bundle.getMeta().setLastUpdated(new Date());
			bundle.setType(BundleTypeEnum.COLLECTION);

			Map<String, List<CarePlan>> map = new HashMap<>();
			while (rs.next()) {
				List<CarePlan> list = map.get("GSIH123456");
				if (list == null) {
					list = new ArrayList<>();
					map.put("GSIH123456", list);
				}

				CarePlan carePlan = new CarePlan();
				carePlan.setId(UUID.randomUUID().toString()); // Need to fix
				carePlan.setStatus(CarePlanStatusEnum.ACTIVE);
				carePlan.getSubject().setReference("Patient/GSIH123456");// need to make dynamic
				carePlan.getPeriod().setStartWithSecondsPrecision(new Date());
				carePlan.getPeriod().setEndWithSecondsPrecision(new Date());
				// --------------Activity-----------------------
				carePlan.addActivity();
				CodeableConceptDt codeableConceptDt = new CodeableConceptDt();
				codeableConceptDt.setText("caregap");
				carePlan.getActivity().get(0).getDetail().setCategory(codeableConceptDt);
				carePlan.getActivity().get(0).getDetail().getCode().getCodingFirstRep().setCode("AAP_1a_2018");
				carePlan.getActivity().get(0).getDetail().getCode().getCodingFirstRep()
						.setDisplay("Adult Access to Primary and Preventive or Ambulatory Care - 20 to 44 yr.");
				carePlan.getActivity().get(0).getDetail().setStatus(CarePlanActivityStatusEnum.IN_PROGRESS);
				// --------------Note-----------------------
				AnnotationDt note = new AnnotationDt();
				note.setText("CommunityId/AB06778X");
				carePlan.setNote(note);
				list.add(carePlan);
			}

			// Merge Activities of the same patient across all CareGaps
			List<Bundle.Entry> entries = new ArrayList<>();
			for (Map.Entry<String, List<CarePlan>> mapEntry : map.entrySet()) {
				Entry entry = new Entry();
				for (CarePlan careGap : mapEntry.getValue()) {
					if (entry.getResource() == null) {
						entry.setResource(careGap);
					} else {
						((CarePlan) entry.getResource()).getActivity().addAll(careGap.getActivity());
					}
				}
				entries.add(entry);
			}
			bundle.setEntry(entries);
			bundle.setTotal(entries.size());

			LinkedList<CarePlanBundle> list = new LinkedList<CarePlanBundle>();
			list.add(bundle);
			myIdToBundleVersions.put(bundle.getId().getValue(), list);
		} // end of try
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				statement.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Search
	public List<CarePlanBundle> findBundlesUsingArbitraryCtriteria() {
		LinkedList<CarePlanBundle> retVal = new LinkedList<CarePlanBundle>();

		for (Deque<CarePlanBundle> nextBundleList : myIdToBundleVersions.values()) {
			CarePlanBundle nextBundle = nextBundleList.getLast();
			retVal.add(nextBundle);
		}

		return retVal;
	}

	@Read(version = true)
	public CarePlanBundle readCarePlanBundle(@IdParam IdDt theId) {
		Deque<CarePlanBundle> retVal;
		try {
			retVal = myIdToBundleVersions.get(theId.getIdPartAsLong());
		} catch (NumberFormatException e) {
			throw new ResourceNotFoundException(theId);
		}

		if (theId.hasVersionIdPart() == false) {
			return retVal.getLast();
		} else {
			for (CarePlanBundle nextVersion : retVal) {
				String nextVersionId = nextVersion.getId().getVersionIdPart();
				if (theId.getVersionIdPart().equals(nextVersionId)) {
					return nextVersion;
				}
			}
			// No matching version
			throw new ResourceNotFoundException("Unknown version: " + theId.getValue());
		}

	}

	@Override
	public Class<CarePlanBundle> getResourceType() {
		return CarePlanBundle.class;
	}
}
