package ca.uhn.example.provider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.hl7.fhir.instance.model.api.IBaseResource;

import ca.uhn.example.model.CarePlanBundle;
import ca.uhn.example.model.RiskAssessmentBundle;
import ca.uhn.fhir.model.api.ResourceMetadataKeyEnum;
import ca.uhn.fhir.model.base.resource.ResourceMetadataMap;
import ca.uhn.fhir.model.dstu2.composite.CodeableConceptDt;
import ca.uhn.fhir.model.dstu2.composite.CodingDt;
import ca.uhn.fhir.model.dstu2.resource.Bundle;
import ca.uhn.fhir.model.dstu2.resource.CarePlan;
import ca.uhn.fhir.model.dstu2.resource.RiskAssessment;
import ca.uhn.fhir.model.dstu2.resource.RiskAssessment.Prediction;
import ca.uhn.fhir.model.dstu2.resource.Bundle.Entry;
import ca.uhn.fhir.model.dstu2.valueset.BundleTypeEnum;
import ca.uhn.fhir.model.dstu2.valueset.CarePlanStatusEnum;
import ca.uhn.fhir.model.primitive.CodeDt;
import ca.uhn.fhir.model.primitive.IdDt;
import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.rest.server.IResourceProvider;
import ca.uhn.fhir.rest.server.exceptions.ResourceNotFoundException;

public class RiskAssessmentResourceProvider  implements IResourceProvider {
	private Map<String, Deque<RiskAssessmentBundle>> myIdToBundleVersions = new HashMap<String, Deque<RiskAssessmentBundle>>();

	public RiskAssessmentResourceProvider() {
		RiskAssessmentBundle bundle = null;

		Connection conn = null;
		Statement statement = null;
		ResultSet rs = null;
		try {
			String db_connect_string = "jdbc:sqlserver://smd-HYD-sql1:1433;databaseName=Analytics_v830_interfaces";
			String db_userid = "devuser";
			String db_password = "Spectramd1234";
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(db_connect_string, db_userid, db_password);
			statement = conn.createStatement();
			String queryString = "select * from Administration.Patient ORDER BY RecordId";
//					"WHERE cg.SysLastUpdateddatetime = '#{jobParameters['CalculationDate']}'";
			rs = statement.executeQuery(queryString);
			// LinkedList<RiskAssessment> list = new LinkedList<RiskAssessment>();
			bundle = new RiskAssessmentBundle();
			bundle.setId(UUID.randomUUID().toString());
			bundle.getMeta().setLastUpdated(new Date());
			bundle.setType(BundleTypeEnum.COLLECTION);
			while (rs.next()) {
				Bundle.Entry entry = new Bundle.Entry();
				List<Bundle.Entry> entries = new ArrayList<Entry>();
				entries.add(entry);
				bundle.setEntry(entries);
				bundle.setTotal(entries.size());
//					entry.setElementSpecificId(UUID.randomUUID().toString());
				entry.setElementSpecificId("RiskAssessmentelement");
				RiskAssessment riskAssessment = new RiskAssessment();
//					Prediction prediction = new Prediction();
//					CodeableConceptDt codeableConceptDt=new CodeableConceptDt();
//					codeableConceptDt.addCoding();
//					prediction.setOutcome(codeableConceptDt);
//					riskAssessment.addPrediction(prediction);
				entry.setResource(riskAssessment);
				riskAssessment.setId(UUID.randomUUID().toString());
				riskAssessment.getSubject().setReference("Patient/GSIH123456");
				riskAssessment.addPrediction();

				riskAssessment.getPrediction().get(0).setRationale("hello");
				CodingDt codingDt = new CodingDt("system", "Code");
				CodeDt codeDt = new CodeDt("HCC");
				codeDt.setElementSpecificId("gekki");
				codingDt.setCode(codeDt);
				riskAssessment.getPrediction().get(0).getOutcome().getCoding().set(0, codingDt);

//				riskAssessment.addActivity();
//				CodeableConceptDt codeableConceptDt= new CodeableConceptDt();
//				codeableConceptDt.setText("caregap");
//				riskAssessment.getActivity().get(0).getDetail().setCategory(codeableConceptDt);
//				riskAssessment.getActivity().get(0).getDetail().getCode().getCodingFirstRep().setCode("AAP_1a_2018");
//				riskAssessment.getActivity().get(0).getDetail().getCode().getCodingFirstRep().setDisplay("Adult Access to Primary and Preventive or Ambulatory Care - 20 to 44 yr.");
//				riskAssessment.getActivity().get(0).getDetail().setStatus(RiskAssessmentActivityStatusEnum.IN_PROGRESS);
//				IBaseResource theResource=(IBaseResource) new RiskAssessmentResourceProvider();
//				riskAssessment.addGoal().setResource(theResource);
			} // end of while
		} // end of try
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				statement.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		LinkedList<RiskAssessmentBundle> list = new LinkedList<RiskAssessmentBundle>();
		list.add(bundle);
		myIdToBundleVersions.put(bundle.getId().getValue(), list);
	}
	@Override
	public Class<RiskAssessmentBundle> getResourceType() {
		return RiskAssessmentBundle.class;
	}
//	@Read()
//	public Bundle getResourceById(@IdParam IdDt theId) {		
//		RiskAssessmentBundle bundle = null;
//		
//		Connection conn = null;
//		Statement statement = null;
//		ResultSet rs = null;
//		try {
//			String db_connect_string = "jdbc:sqlserver://smd-HYD-sql1:1433;databaseName=Analytics_v830_interfaces";
//			String db_userid = "devuser";
//			String db_password = "Spectramd1234";
//			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
//			conn = DriverManager.getConnection(db_connect_string, db_userid, db_password);
//			statement = conn.createStatement();
//			String queryString = "select * from Administration.Patient ORDER BY RecordId"; 
////					"WHERE cg.SysLastUpdateddatetime = '#{jobParameters['CalculationDate']}'";
//			    rs = statement.executeQuery(queryString);
//				//LinkedList<RiskAssessment> list = new LinkedList<RiskAssessment>();
//				bundle=new RiskAssessmentBundle();
//				bundle.setId(UUID.randomUUID().toString());
//				bundle.getMeta().setLastUpdated(new Date());
//				bundle.setType(BundleTypeEnum.COLLECTION);
//				while (rs.next()) {
//					Bundle.Entry entry = new Bundle.Entry();
//					List<Bundle.Entry> entries = new ArrayList<Entry>();
//					entries.add(entry);
//					bundle.setEntry(entries);	
//					bundle.setTotal(entries.size());
////					entry.setElementSpecificId(UUID.randomUUID().toString());
//					entry.setElementSpecificId("RiskAssessmentelement");
//					RiskAssessment riskAssessment = new RiskAssessment();
////					Prediction prediction = new Prediction();
////					CodeableConceptDt codeableConceptDt=new CodeableConceptDt();
////					codeableConceptDt.addCoding();
////					prediction.setOutcome(codeableConceptDt);
////					riskAssessment.addPrediction(prediction);
//					entry.setResource(riskAssessment);
//					riskAssessment.setId(UUID.randomUUID().toString());
//					riskAssessment.getSubject().setReference("Patient/GSIH123456");
//					riskAssessment.addPrediction();
//					
//					riskAssessment.getPrediction().get(0).setRationale("hello");
//					CodingDt codingDt = new CodingDt("system","Code");
//					CodeDt codeDt = new CodeDt("HCC");
//					codeDt.setElementSpecificId("gekki");
//					codingDt.setCode(codeDt);
//					riskAssessment.getPrediction().get(0).getOutcome().getCoding().set(0,codingDt);
//                                     
////				riskAssessment.addActivity();
////				CodeableConceptDt codeableConceptDt= new CodeableConceptDt();
////				codeableConceptDt.setText("caregap");
////				riskAssessment.getActivity().get(0).getDetail().setCategory(codeableConceptDt);
////				riskAssessment.getActivity().get(0).getDetail().getCode().getCodingFirstRep().setCode("AAP_1a_2018");
////				riskAssessment.getActivity().get(0).getDetail().getCode().getCodingFirstRep().setDisplay("Adult Access to Primary and Preventive or Ambulatory Care - 20 to 44 yr.");
////				riskAssessment.getActivity().get(0).getDetail().setStatus(RiskAssessmentActivityStatusEnum.IN_PROGRESS);
////				IBaseResource theResource=(IBaseResource) new RiskAssessmentResourceProvider();
////				riskAssessment.addGoal().setResource(theResource);
//			} // end of while
//		} // end of try
//		catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			try {
//				rs.close();
//				statement.close();
//				conn.close();
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//			
//		}
//		return bundle;
//	}
	@Search
	public List<RiskAssessmentBundle> findBundlesUsingArbitraryCtriteria() {
		LinkedList<RiskAssessmentBundle> retVal = new LinkedList<RiskAssessmentBundle>();

		for (Deque<RiskAssessmentBundle> nextBundleList : myIdToBundleVersions.values()) {
			RiskAssessmentBundle nextBundle = nextBundleList.getLast();
			retVal.add(nextBundle);
		}

		return retVal;
	}

	@Read(version = true)
	public RiskAssessmentBundle readRiskAssessmentBundle(@IdParam IdDt theId) {
		Deque<RiskAssessmentBundle> retVal;
		try {
			retVal = myIdToBundleVersions.get(theId.getIdPartAsLong());
		} catch (NumberFormatException e) {
			throw new ResourceNotFoundException(theId);
		}

		if (theId.hasVersionIdPart() == false) {
			return retVal.getLast();
		} else {
			for (RiskAssessmentBundle nextVersion : retVal) {
				String nextVersionId = nextVersion.getId().getVersionIdPart();
				if (theId.getVersionIdPart().equals(nextVersionId)) {
					return nextVersion;
				}
			}
			// No matching version
			throw new ResourceNotFoundException("Unknown version: " + theId.getValue());
		}

	}

}
//END SNIPPET: provider