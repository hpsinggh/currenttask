/**
 * 
 */
package ca.uhn.example.model;

import ca.uhn.fhir.model.api.annotation.ResourceDef;
import ca.uhn.fhir.model.dstu2.resource.Bundle;

/**
 * @author heerendra.singh
 *
 */
@ResourceDef(name="RiskAssessmentBundle", profile="http://hl7.org/fhir/profiles/Bundle", id="riskAssessmentBundle")
public class RiskAssessmentBundle extends Bundle {

	/**
	 * 
	 */
	public RiskAssessmentBundle() {
		super();
	}

}
