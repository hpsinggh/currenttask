/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusConfigInitializer;
import com.spectramd.products.focus.common.FocusDefaultLogInitializer;
import com.spectramd.products.focus.common.FocusLogger;
import com.spectramd.products.focus.common.utils.ThreadUtils;
import java.util.HashMap;
import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameter;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.context.support.ClassPathXmlApplicationContext;

/**
 *
 * @author Heerendra.singh
 */
public class FocusOlapJSONGenerator {

	/**
	 * @param args the command line arguments
	 */
	public static void main(String[] args) {

		try {
			ThreadUtils.initializeInheritableThread();
			// 1. Initialize the logger
			FocusDefaultLogInitializer init = new FocusDefaultLogInitializer();
			init.Initialize(null);
			FocusLogger.info("Logger Initialized");

			if (args.length < 2) {
				printHelpMessage();
			} else {
				// Get the job Name
				String clientId = (args[0].split("="))[1];
				String jobType = (args[1].split("="))[1];
				FocusLogger.info("JobType =" + jobType);

				// 2. Initialize the configuration
				String configFile = ".\\config\\" + clientId + "\\focusconfig.properties";
				FocusConfigInitializer.initialize(configFile);
				FocusLogger.info("Configuration Intialized");

				FocusConfig.getCurrentLogger().writeDebug("Start: FocusSyntheaAdaptor method: main(..)");

				// Create JobParameters and default Parameter
				HashMap<String, JobParameter> map = new HashMap<>();
				map.put("time", new JobParameter(System.currentTimeMillis()));

				for (int index = 1; index < args.length; index++) {
					String argName = (args[index].split("="))[0];
					String argValue = (args[index].split("="))[1];
					map.put(argName, new JobParameter(argValue));

					FocusLogger.info("argName =" + argName + ",argValue = " + argValue);
				}

				String configFileName = "file:.\\config\\" + jobType + "\\" + jobType + ".xml";
				String dbFileName = "file:.\\config\\" + clientId + "\\database.xml";
				String[] configFilesLocation = {configFileName, dbFileName};

				ClassPathXmlApplicationContext context
						= new ClassPathXmlApplicationContext(configFilesLocation);
				JobLauncher jobLauncher = (JobLauncher) context.getBean("jobLauncher");
				Job job = (Job) context.getBean(jobType);
				System.out.println(map);
				JobExecution jobExecution = jobLauncher.run(job, new JobParameters(map));
				if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
					FocusLogger.info("Job completed successfully");
				} else {
					FocusLogger.info("Batch execution failed");
					jobExecution.getAllFailureExceptions().forEach((exception) -> FocusLogger.error("Exception : ", exception));
				}
			}
		} catch (Exception ex) {
			FocusLogger.error("Error : ", ex);
		}
	}

	private static void printHelpMessage() {
		FocusConfig.getCurrentLogger().writeInfo("=======================================");
		FocusConfig.getCurrentLogger().writeInfo("Please pass JOB NAME & "
				+ "JobParameters as a commandline arguments as given below:");
		FocusConfig.getCurrentLogger().writeInfo("java -jar FocusSyntheaAdaptor.jar "
				+ "jobName=FocusSyntheaAdaptor inputFolder='.//input' viewName=MIPS_VALUESETS_2018");
		FocusConfig.getCurrentLogger().writeInfo("=======================================");
	}

}
