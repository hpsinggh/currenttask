/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.focus.jsongenerator.writer;

/**
 *
 * @author heerendra.singh
 */
import com.spectramd.focus.jsongenerator.entity.CareGap;
import com.spectramd.focus.jsongenerator.entity.CareGapBundle;
import com.spectramd.focus.jsongenerator.entity.CareGapBundle.Entry;
import com.spectramd.focus.jsongenerator.entity.CareGapBundle.Meta;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.codehaus.jackson.util.DefaultPrettyPrinter;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.item.ItemWriter;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.ObjectWriter;

public class CareGapsJSONWriter implements ItemWriter<CareGap>, StepExecutionListener {

	private String outputFolder;

	@Override
	public void write(List<? extends CareGap> items) throws Exception {
		ObjectMapper mapper = new ObjectMapper();
		ObjectWriter writer = mapper.writer(new DefaultPrettyPrinter());
		try {
			CareGapBundle bundle = new CareGapBundle();
			bundle.setResourceType("Bundle");
			bundle.setId(UUID.randomUUID().toString());
			bundle.setType("collection");

			Meta meta = new Meta();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssXXX");
			meta.setLastUpdated(sdf.format(new Date()));
			bundle.setMeta(meta);

			// Group all CareGaps for the same patient together
			Map<String, List<CareGap>> map = new HashMap<>();
			for (CareGap careGap : items) {
				String key = careGap.getSubject().getReference();
				List<CareGap> value = map.get(key);
				if (value == null) {
					value = new ArrayList<>();
					map.put(key, value);
				}
				value.add(careGap);
			}

			// Merge Activities of the same patient across all CareGaps
			List<Entry> entries = new ArrayList<>();
			for (Map.Entry<String, List<CareGap>> mapEntry : map.entrySet()) {
				Entry entry = new Entry();
				for (CareGap careGap : mapEntry.getValue()) {
					if (entry.getResource() == null) {
						entry.setResource(careGap);
					} else {
						entry.getResource().getActivity().addAll(careGap.getActivity());
					}
				}
				entries.add(entry);
			}
			bundle.setEntry(entries);
			bundle.setTotal(entries.size());

			writer.writeValue(new File(outputFolder + "/CareGap-" + (new Date()).getTime() + ".json"), bundle);
		} catch (IOException ex) {
			Logger.getLogger(CareGapsJSONWriter.class.getName()).log(Level.SEVERE, null, ex);
		}
	}

	public void setOutputFolder(String outputFolder) {
		this.outputFolder = outputFolder;
	}

	@Override
	public ExitStatus afterStep(StepExecution arg0) {
		return null;
	}

//    @Override
//    public void beforeStep(StepExecution arg0) {
//        gson = new GsonBuilder().setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").disableHtmlEscaping().create();
//    }
	@Override
	public void beforeStep(StepExecution se) {

		// throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	}

}
