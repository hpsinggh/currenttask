package com.spectramd.focus.jsongenerator.entity;

import java.util.List;

public class RiskScore {

	private String resourceType;
	private String id;
	private String status;
	private Subject subject;
	private String occurrenceDateTime;
	private List<Prediction> prediction = null;
	private String comment;

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Subject getSubject() {
		return subject;
	}

	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	public String getOccurrenceDateTime() {
		return occurrenceDateTime;
	}

	public void setOccurrenceDateTime(String occurrenceDateTime) {
		this.occurrenceDateTime = occurrenceDateTime;
	}

	public List<Prediction> getPrediction() {
		return prediction;
	}

	public void setPrediction(List<Prediction> prediction) {
		this.prediction = prediction;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public static class Prediction {

		private Outcome outcome;
		private String probabilityDecimal;

		public Outcome getOutcome() {
			return outcome;
		}

		public void setOutcome(Outcome outcome) {
			this.outcome = outcome;
		}

		public String getProbabilityDecimal() {
			return probabilityDecimal;
		}

		public void setProbabilityDecimal(String probabilityDecimal) {
			this.probabilityDecimal = probabilityDecimal;
		}

	}

	public static class Outcome {

		private List<Coding> coding = null;
		private String text;

		public List<Coding> getCoding() {
			return coding;
		}

		public void setCoding(List<Coding> coding) {
			this.coding = coding;
		}

		public String getText() {
			return text;
		}

		public void setText(String text) {
			this.text = text;
		}

	}

	public static class Coding {

		private String code;

		public String getCode() {
			return code;
		}

		public void setCode(String code) {
			this.code = code;
		}
	}

	public static class Subject {

		private String reference;

		public String getReference() {
			return reference;
		}

		public void setReference(String reference) {
			this.reference = reference;
		}

	}

}
