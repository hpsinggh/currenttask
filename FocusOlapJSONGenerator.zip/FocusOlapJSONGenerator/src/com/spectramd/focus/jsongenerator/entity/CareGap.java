/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.focus.jsongenerator.entity;

/**
 *
 * @author heerendra.singh
 */
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.codehaus.jackson.annotate.JsonAnyGetter;
import org.codehaus.jackson.annotate.JsonAnySetter;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

@JsonPropertyOrder({
	"resourceType",
	"id",
	"status",
	"type",
	"subject",
	"intent",
	"period",
	"activity",
	"note"
})
public class CareGap {

	@JsonProperty("resourceType")
	private String resourceType;
	@JsonProperty("id")
	private String id;
	@JsonProperty("status")
	private String status;
	@JsonProperty("type")
	private String type;
	@JsonProperty("subject")
	private Subject subject;
	@JsonProperty("intent")
	private String intent;
	@JsonProperty("period")
	private Period period;
	@JsonProperty("activity")
	private List<Activity> activity = null;
	@JsonProperty("note")
	private List<Note> note = null;

	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("resourceType")
	public String getResourceType() {
		return resourceType;
	}

	@JsonProperty("resourceType")
	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("status")
	public String getStatus() {
		return status;
	}

	@JsonProperty("status")
	public void setStatus(String status) {
		this.status = status;
	}

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("subject")
	public Subject getSubject() {
		return subject;
	}

	@JsonProperty("subject")
	public void setSubject(Subject subject) {
		this.subject = subject;
	}

	@JsonProperty("intent")
	public String getIntent() {
		return intent;
	}

	@JsonProperty("intent")
	public void setIntent(String intent) {
		this.intent = intent;
	}

	@JsonProperty("period")
	public Period getPeriod() {
		return period;
	}

	@JsonProperty("period")
	public void setPeriod(Period period) {
		this.period = period;
	}

	@JsonProperty("activity")
	public List<Activity> getActivity() {
		return activity;
	}

	@JsonProperty("activity")
	public void setActivity(List<Activity> activity) {
		this.activity = activity;
	}

	@JsonProperty("note")
	public List<Note> getNote() {
		return note;
	}

	@JsonProperty("note")
	public void setNote(List<Note> note) {
		this.note = note;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@JsonPropertyOrder({
		"reference"
	})
	public static class Subject {

		@JsonProperty("reference")
		private String reference;
		@JsonIgnore
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		@JsonProperty("reference")
		public String getReference() {
			return reference;
		}

		@JsonProperty("reference")
		public void setReference(String reference) {
			this.reference = reference;
		}

		@JsonAnyGetter
		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		@JsonAnySetter
		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}
	}

	@JsonPropertyOrder({
		"start",
		"end"
	})
	public static class Period {

		@JsonProperty("start")
		private String start;
		@JsonProperty("end")
		private String end;
		@JsonIgnore
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		@JsonProperty("start")
		public String getStart() {
			return start;
		}

		@JsonProperty("start")
		public void setStart(String start) {
			this.start = start;
		}

		@JsonProperty("end")
		public String getEnd() {
			return end;
		}

		@JsonProperty("end")
		public void setEnd(String end) {
			this.end = end;
		}

		@JsonAnyGetter
		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		@JsonAnySetter
		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}
	}

	@JsonPropertyOrder({
		"detail"
	})
	public static class Activity {

		@JsonProperty("detail")
		private Detail detail;
//@JsonIgnore
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		@JsonProperty("detail")
		public Detail getDetail() {
			return detail;
		}

		@JsonProperty("detail")
		public void setDetail(Detail detail) {
			this.detail = detail;
		}

		@JsonAnyGetter
		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		@JsonAnySetter
		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}
	}

	@JsonPropertyOrder({
		"category",
		"code",
		"status"
	})
	public static class Detail {

		@JsonProperty("category")
		private String category;
		@JsonProperty("code")
		private Code code;
		@JsonProperty("status")
		private String status;
		@JsonIgnore
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		@JsonProperty("category")
		public String getCategory() {
			return category;
		}

		@JsonProperty("category")
		public void setCategory(String category) {
			this.category = category;
		}

		@JsonProperty("code")
		public Code getCode() {
			return code;
		}

		@JsonProperty("code")
		public void setCode(Code code) {
			this.code = code;
		}

		@JsonProperty("status")
		public String getStatus() {
			return status;
		}

		@JsonProperty("status")
		public void setStatus(String status) {
			this.status = status;
		}

		@JsonAnyGetter
		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		@JsonAnySetter
		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}
	}

	public static class Code {

		@JsonIgnore
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		@JsonAnyGetter
		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		@JsonAnySetter
		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}
	}

	@JsonPropertyOrder({
		"code",
		"display"
	})
	public static class Coding {

		@JsonProperty("code")
		private String code;
		@JsonProperty("display")
		private String display;
		@JsonIgnore
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		@JsonProperty("code")
		public String getCode() {
			return code;
		}

		@JsonProperty("code")
		public void setCode(String code) {
			this.code = code;
		}

		@JsonProperty("display")
		public String getDisplay() {
			return display;
		}

		@JsonProperty("display")
		public void setDisplay(String display) {
			this.display = display;
		}

		@JsonAnyGetter
		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		@JsonAnySetter
		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}
	}

	@JsonPropertyOrder({
		"text"
	})
	public static class Note {

		@JsonProperty("text")
		private String text;
		@JsonIgnore
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		@JsonProperty("text")
		public String getText() {
			return text;
		}

		@JsonProperty("text")
		public void setText(String text) {
			this.text = text;
		}

		@JsonAnyGetter
		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		@JsonAnySetter
		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}
	}
}
