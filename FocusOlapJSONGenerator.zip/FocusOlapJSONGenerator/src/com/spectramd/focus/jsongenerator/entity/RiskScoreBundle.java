package com.spectramd.focus.jsongenerator.entity;

import java.util.List;

public class RiskScoreBundle {

	private String resourceType;
	private String id;
	private Meta meta;
	private String type;
	private Integer total;
	private List<RiskScore> entry = null;

	public String getResourceType() {
		return resourceType;
	}

	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Meta getMeta() {
		return meta;
	}

	public void setMeta(Meta meta) {
		this.meta = meta;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public List<RiskScore> getEntry() {
		return entry;
	}

	public void setEntry(List<RiskScore> entry) {
		this.entry = entry;
	}

	public static class Meta {

		private String lastUpdated;

		public String getLastUpdated() {
			return lastUpdated;
		}

		public void setLastUpdated(String lastUpdated) {
			this.lastUpdated = lastUpdated;
		}

	}

	public static class Subject {

		private String reference;

		public String getReference() {
			return reference;
		}

		public void setReference(String reference) {
			this.reference = reference;
		}

	}

	public static class Prediction {

		private RiskScore.Outcome outcome;
		private Integer probabilityDecimal;

		public RiskScore.Outcome getOutcome() {
			return outcome;
		}

		public void setOutcome(RiskScore.Outcome outcome) {
			this.outcome = outcome;
		}

		public Integer getProbabilityDecimal() {
			return probabilityDecimal;
		}

		public void setProbabilityDecimal(Integer probabilityDecimal) {
			this.probabilityDecimal = probabilityDecimal;
		}
	}

}
