/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.focus.jsongenerator.entity;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.codehaus.jackson.annotate.JsonAnyGetter;
import org.codehaus.jackson.annotate.JsonAnySetter;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;
import org.codehaus.jackson.annotate.JsonPropertyOrder;

/**
 *
 * @author heerendra.singh
 */
public class CareGapBundle {

	@JsonProperty("resourceType")
	private String resourceType;
	@JsonProperty("id")
	private String id;
	@JsonProperty("meta")
	private Meta meta;
	@JsonProperty("type")
	private String type;
	@JsonProperty("total")
	private Integer total;
	@JsonProperty("entry")
	private List<Entry> entry = null;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	@JsonProperty("resourceType")
	public String getResourceType() {
		return resourceType;
	}

	@JsonProperty("resourceType")
	public void setResourceType(String resourceType) {
		this.resourceType = resourceType;
	}

	@JsonProperty("id")
	public String getId() {
		return id;
	}

	@JsonProperty("id")
	public void setId(String id) {
		this.id = id;
	}

	@JsonProperty("meta")
	public Meta getMeta() {
		return meta;
	}

	@JsonProperty("meta")
	public void setMeta(Meta meta) {
		this.meta = meta;
	}

	@JsonProperty("type")
	public String getType() {
		return type;
	}

	@JsonProperty("type")
	public void setType(String type) {
		this.type = type;
	}

	@JsonProperty("total")
	public Integer getTotal() {
		return total;
	}

	@JsonProperty("total")
	public void setTotal(Integer total) {
		this.total = total;
	}

	@JsonProperty("entry")
	public List<Entry> getEntry() {
		return entry;
	}

	@JsonProperty("entry")
	public void setEntry(List<Entry> entry) {
		this.entry = entry;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

	@JsonPropertyOrder({
		"resource"
	})
	public static class Entry {

		@JsonProperty("resource")
		private CareGap resource;

		@JsonProperty("resource")
		public CareGap getResource() {
			return resource;
		}

		@JsonProperty("resource")
		public void setResource(CareGap resource) {
			this.resource = resource;
		}
	}

	@JsonPropertyOrder({
		"lastUpdated"
	})
	public static class Meta {

		@JsonProperty("lastUpdated")
		private String lastUpdated;
		@JsonIgnore
		private Map<String, Object> additionalProperties = new HashMap<String, Object>();

		@JsonProperty("lastUpdated")
		public String getLastUpdated() {
			return lastUpdated;
		}

		@JsonProperty("lastUpdated")
		public void setLastUpdated(String lastUpdated) {
			this.lastUpdated = lastUpdated;
		}

		@JsonAnyGetter
		public Map<String, Object> getAdditionalProperties() {
			return this.additionalProperties;
		}

		@JsonAnySetter
		public void setAdditionalProperty(String name, Object value) {
			this.additionalProperties.put(name, value);
		}

	}
}
