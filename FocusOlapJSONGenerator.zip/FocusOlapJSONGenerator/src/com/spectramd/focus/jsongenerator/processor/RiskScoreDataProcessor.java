/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.focus.jsongenerator.processor;

import com.spectramd.focus.jsongenerator.entity.RiskScore;
import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.springframework.batch.item.ItemProcessor;

/**
 *
 * @author heerendra.singh
 */
public class RiskScoreDataProcessor implements ItemProcessor<OrderedInsensitiveMap, RiskScore> {

	@Override
	public RiskScore process(OrderedInsensitiveMap map) throws Exception {
		RiskScore riskScore = new RiskScore();
		riskScore.setResourceType("RiskAssessment");
		riskScore.setId(UUID.randomUUID().toString());
		riskScore.setStatus("active");
		riskScore.setOccurrenceDateTime(map.get("CalculationDate").toString());		// TODO: Confirm with Ravi

		RiskScore.Subject subject = new RiskScore.Subject();
		subject.setReference("Patient/" + map.get("GSIPatientId").toString());
		riskScore.setSubject(subject);

		List<RiskScore.Prediction> predictions = new ArrayList<>();
		riskScore.setPrediction(predictions);

		RiskScore.Prediction prediction = new RiskScore.Prediction();
		predictions.add(prediction);

		RiskScore.Outcome outcome = new RiskScore.Outcome();
		prediction.setOutcome(outcome);

		List<RiskScore.Coding> codings = new ArrayList();
		RiskScore.Coding coding = new RiskScore.Coding();
		coding.setCode(map.get("RiskScoreCode").toString());
		codings.add(coding);
		outcome.setCoding(codings);
		outcome.setText(map.get("RiskScoreDescription").toString());
		prediction.setProbabilityDecimal(map.get("Score").toString());
		riskScore.setComment("CommunityId/" + map.get("CommunityId").toString());
		return riskScore;
	}
}
