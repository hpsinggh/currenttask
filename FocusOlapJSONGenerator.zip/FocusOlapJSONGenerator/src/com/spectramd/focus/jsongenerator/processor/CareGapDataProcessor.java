/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.focus.jsongenerator.processor;

import com.spectramd.focus.jsongenerator.entity.CareGap;
import com.spectramd.focus.jsongenerator.entity.CareGap.Activity;
import com.spectramd.focus.jsongenerator.entity.CareGap.Code;
import com.spectramd.focus.jsongenerator.entity.CareGap.Coding;
import com.spectramd.focus.jsongenerator.entity.CareGap.Detail;
import com.spectramd.focus.jsongenerator.entity.CareGap.Note;
import com.spectramd.focus.jsongenerator.entity.CareGap.Period;
import com.spectramd.focus.jsongenerator.entity.CareGap.Subject;
import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import org.springframework.batch.item.ItemProcessor;

/**
 *
 * @author heerendra.singh
 */
public class CareGapDataProcessor implements ItemProcessor<OrderedInsensitiveMap, CareGap> {

	@Override
	public CareGap process(OrderedInsensitiveMap map) throws Exception {
		CareGap careGap = new CareGap();
		careGap.setResourceType("CarePlan");
		careGap.setId(UUID.randomUUID().toString());
		careGap.setStatus("active");		// TODO: Confirm with Ravi
		careGap.setType("individual");		// TODO: Confirm with Ravi
		careGap.setIntent("proposal");		// TODO: Confirm with Ravi

		Subject subject = new Subject();
		subject.setReference("Patient/" + map.get("GSIPatientId").toString());
		careGap.setSubject(subject);

		Period period = new Period();
		period.setStart(map.get("EvalPeriodStartDatetime").toString());
		period.setEnd(map.get("EvalPeriodEndDatetime").toString());
		careGap.setPeriod(period);

		List<Activity> activities = new ArrayList<>();
		careGap.setActivity(activities);

		Activity activity = new Activity();
		activities.add(activity);

		Detail detail = new Detail();
		activity.setDetail(detail);
		detail.setCategory(map.get("CareGap").toString());		// TODO: Confirm with Ravi
		detail.setStatus(map.get("StatusCode").toString().toLowerCase());

		Code code = new Code();
		Coding coding = new Coding();
		coding.setCode(map.get("MeasureCode").toString());
		coding.setDisplay(map.get("MeasureDisplayName").toString());
		code.setAdditionalProperty("coding", coding);
		detail.setCode(code);

		Note note = new Note();
		note.setText("CommunityId/" + map.get("CommunityId").toString());
		List<Note> noteList = new ArrayList<>();
		noteList.add(note);
		careGap.setNote(noteList);

		return careGap;
	}
}
