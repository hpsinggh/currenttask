package ca.uhn.example.provider;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import ca.uhn.fhir.model.dstu2.valueset.IdentifierUseEnum;
import ca.uhn.fhir.model.dstu2.resource.Bundle;
import ca.uhn.fhir.model.dstu2.resource.Patient;
import ca.uhn.fhir.model.dstu2.valueset.AdministrativeGenderEnum;
import ca.uhn.fhir.model.primitive.IdDt;
import ca.uhn.fhir.model.primitive.StringDt;
import ca.uhn.fhir.model.primitive.UriDt;
import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.annotation.RequiredParam;
import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.rest.server.IResourceProvider;

//START SNIPPET: provider
/**
 * All resource providers must implement IResourceProvider
 */
public class ResourceProvider implements IResourceProvider {

	/**
	 * The getResourceType method comes from IResourceProvider, and must
	 * be overridden to indicate what type of resource this provider
	 * supplies.
	 */
	@Override
	public Class<Bundle> getResourceType() {
		return Bundle.class;
	}

	/**
	 * The "@Read" annotation indicates that this method supports the read
	 * operation. It takes one argument, the Resource type being returned.
	 * 
	 * @param theId The read operation takes one parameter, which must be of type
	 *              IdDt and must be annotated with the "@Read.IdParam" annotation.
	 * @return Returns a resource matching this identifier, or null if none exists.
	 */
	@Read()
	public Bundle getResourceById(@IdParam IdDt theId) {
		Bundle bundle = null;

//		Connection conn = null;
//		Statement statement = null;
//		ResultSet rs = null;
		try {
//			String db_connect_string = "jdbc:sqlserver://smd-HYD-sql1:1433;databaseName=Analytics_v830_interfaces";
//			String db_userid = "devuser";
//			String db_password = "Spectramd1234";
			
			//Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			//conn = DriverManager.getConnection(db_connect_string, db_userid, db_password);
			//statement = conn.createStatement();
			//String queryString = "select * from Administration.Patient ORDER BY RecordId";
			// rs = statement.executeQuery(queryString);
			// LinkedList<CarePlan> list = new LinkedList<CarePlan>();
			bundle = new Bundle();
			bundle.setId(UUID.randomUUID().toString());
			bundle.getMeta().setLastUpdated(new Date());
			//while (rs.next()) {
//				Bundle.Entry entry = new Bundle.Entry();
//				List<Bundle.Entry> entries = new ArrayList<Entry>();
//				entries.add(entry);
//				bundle.setEntry(entries);
//				bundle.setTotal(entries.size());
//				CarePlan carePlan = new CarePlan();
//				entry.setResource(carePlan);
//				carePlan.setId(UUID.randomUUID().toString());
//				carePlan.setStatus(CarePlanStatusEnum.ACTIVE);
//				// SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssXXX");
//				carePlan.getSubject().setReference("Patient/GSIH123456");// need to make dynamic
//				carePlan.getPeriod().setStartWithSecondsPrecision(new Date());
//				carePlan.getPeriod().setEndWithSecondsPrecision(new Date());
//
//				// --------------Acitivity-----------------------
//
//				carePlan.addActivity();
//				CodeableConceptDt codeableConceptDt = new CodeableConceptDt();
//				codeableConceptDt.setText("caregap");
//				carePlan.getActivity().get(0).getDetail().setCategory(codeableConceptDt);
//				carePlan.getActivity().get(0).getDetail().getCode().getCodingFirstRep().setCode("AAP_1a_2018");
//				carePlan.getActivity().get(0).getDetail().getCode().getCodingFirstRep()
//						.setDisplay("Adult Access to Primary and Preventive or Ambulatory Care - 20 to 44 yr.");
//				carePlan.getActivity().get(0).getDetail().setStatus(CarePlanActivityStatusEnum.IN_PROGRESS);
				
				
				
				
//				CarePlanResourceProvider theResource = new CarePlanResourceProvider();
//				carePlan.addGoal().setResource(theResource);
			//} // end of while
		} // end of try
		catch (Exception e) {
			e.printStackTrace();
		} finally {
//			try {
////				rs.close();
////				statement.close();
////				conn.close();
//			} catch (SQLException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}

		}
		return bundle;
	}


	/**
	 * The "@Search" annotation indicates that this method supports the 
	 * search operation. You may have many different method annotated with 
	 * this annotation, to support many different search criteria. This
	 * example searches by family name.
	 * 
	 * @param theIdentifier
	 *    This operation takes one parameter which is the search criteria. It is
	 *    annotated with the "@Required" annotation. This annotation takes one argument,
	 *    a string containing the name of the search criteria. The datatype here
	 *    is StringDt, but there are other possible parameter types depending on the
	 *    specific search criteria.
	 * @return
	 *    This method returns a list of Patients. This list may contain multiple
	 *    matching resources, or it may also be empty.
	 */
//	@Search()
//	public List<Patient> getPatient(@RequiredParam(name = Patient.SP_FAMILY) StringDt theFamilyName) {
//		Patient patient = new Patient();
//		patient.addIdentifier();
//		patient.getIdentifier().get(0).setUse(IdentifierUseEnum.OFFICIAL);
//		patient.getIdentifier().get(0).setSystem(new UriDt("urn:hapitest:mrns"));
//		patient.getIdentifier().get(0).setValue("00001");
//		patient.addName();
//		patient.getName().get(0).addFamily("Test");
//		patient.getName().get(0).addGiven("PatientOne");
//		patient.setGender(AdministrativeGenderEnum.MALE);
//		return Collections.singletonList(patient);
//	}

}
//END SNIPPET: provider