package ca.uhn.example.provider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import ca.uhn.example.model.CarePlanBundle;
import ca.uhn.fhir.model.dstu2.composite.AnnotationDt;
import ca.uhn.fhir.model.dstu2.composite.CodeableConceptDt;
import ca.uhn.fhir.model.dstu2.resource.Bundle.Entry;
import ca.uhn.fhir.model.dstu2.resource.CarePlan;
import ca.uhn.fhir.model.dstu2.valueset.BundleTypeEnum;
import ca.uhn.fhir.model.dstu2.valueset.CarePlanActivityStatusEnum;
import ca.uhn.fhir.model.dstu2.valueset.CarePlanStatusEnum;
import ca.uhn.fhir.model.primitive.IdDt;
import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.rest.server.IResourceProvider;

/**	
 * All resource providers must implement IResourceProvider
 */
public class CarePlanResourceProvider implements IResourceProvider {

	/**
	 * This map has a resource ID as a key, and each key maps to a Deque list
	 * containing all versions of the resource with that ID.
	 */
	private Map<String, Deque<Entry>> myIdToBundleVersions = new HashMap<String, Deque<Entry>>();

	public CarePlanResourceProvider() {
		Connection conn = null;
		Statement statement = null;
		ResultSet rs = null;
		try {
			String db_connect_string = "jdbc:sqlserver://smd-HYD-sql1:1433;databaseName=Analytics_v830_interfaces";
			String db_userid = "devuser";
			String db_password = "Spectramd1234";
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(db_connect_string, db_userid, db_password);
			statement = conn.createStatement();
			String queryString = "Select commpid.ValueDetails AS CommunityId, gsipid.ValueDetails AS GSIPatientId, patient.RecordId AS PatientId,\n"
					+ "			oi.ValueDetails AS FacilityKey, mgi.IdentifierValueDetails AS ProgramCode, 'N/A' AS MeasureCode, cg.IdentifierValueDetails AS CareGap,\n"
					+ "			cgf.GapResult AS Status, cgf.SysLastUpdateddatetime AS CalculationDate\n"
					+ "			from OlapMart.CareGap cg\n"
					+ "			JOIN OlapMart.CareGapFact cgf ON cgf.CareGapRecordKey = cg.RecordKey\n"
					+ "			JOIN Administration.Patient patient ON patient.RecordId = cgf.PatientDimensionRecordKey\n"
					+ "			JOIN Administration.Organization org ON patient.OrganizationRecordId = org.RecordId\n"
					+ "			JOIN Administration.OrganizationIdentifier oi ON oi.RecordId = org.PartofOrganizationRecordId\n"
					+ "			JOIN OlapMart.MeasureGroupIdentifier mgi on mgi.RecordKey = cgf.MeasureGroupIdentifierRecordKey\n"
					+ "			JOIN Administration.PatientIdentifier commpid ON patient.RecordId = commpid.PatientRecordId AND commpid.IdentifieruseCode = 'CommunityID'\n"
					+ "			JOIN Administration.PatientIdentifier gsipid ON patient.RecordId = gsipid.PatientRecordId AND gsipid.IdentifieruseCode = 'GSIPatientID'\n";
			rs = statement.executeQuery(queryString);
			
			Map<String, List<CarePlan>> map = new HashMap<>();
			while (rs.next()) {
				String gsiId = rs.getString("PatientId");
				List<CarePlan> list = map.get(gsiId);
				if (list == null) {
					list = new ArrayList<>();
					map.put(gsiId, list);
				}

				CarePlan carePlan = new CarePlan();	
				carePlan.setId(UUID.randomUUID().toString()); // Need to fix
				carePlan.setStatus(CarePlanStatusEnum.ACTIVE);
				carePlan.getSubject().setReference("Patient/" + rs.getString("GSIPatientId"));
				carePlan.getPeriod().setStartWithSecondsPrecision(new Date());
				carePlan.getPeriod().setEndWithSecondsPrecision(new Date());
				// --------------Activity-----------------------
				carePlan.addActivity();
				CodeableConceptDt codeableConceptDt = new CodeableConceptDt();
				codeableConceptDt.setText(rs.getString("CareGap"));
				carePlan.getActivity().get(0).getDetail().setCategory(codeableConceptDt);
				carePlan.getActivity().get(0).getDetail().getCode().getCodingFirstRep()
						.setCode(rs.getString("MeasureCode"));
				carePlan.getActivity().get(0).getDetail().getCode().getCodingFirstRep().setDisplay("N/A");
				carePlan.getActivity().get(0).getDetail().setStatus(CarePlanActivityStatusEnum.IN_PROGRESS);
				// --------------Note-----------------------
				AnnotationDt note = new AnnotationDt();
				note.setText("CommunityId/" + rs.getString("CommunityId"));
				carePlan.setNote(note);
				list.add(carePlan);
			}

			// Merge Activities of the same patient across all CareGaps
			for (Map.Entry<String, List<CarePlan>> mapEntry : map.entrySet()) {
				Deque<Entry> entryList = myIdToBundleVersions.get(mapEntry.getKey());
				if (entryList == null) {
					entryList = new LinkedList<Entry>();
					myIdToBundleVersions.put(mapEntry.getKey(), entryList);
				}

				Entry entry = null;
				if(!entryList.isEmpty()) {
					entry = entryList.getLast();
				} else {
					entry = new Entry();
					entryList.add(entry);
				}
				
				for (CarePlan carePlan : mapEntry.getValue()) {
					if (entry.getResource() == null) {
						entry.setResource(carePlan);
					} else {
						((CarePlan) entry.getResource()).getActivity().addAll(carePlan.getActivity());
					}
				}
			}
		} // end of try
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				statement.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Search
	public CarePlanBundle findBundlesUsingArbitraryCtriteria() {
		CarePlanBundle bundle = new CarePlanBundle();
		bundle.setId(UUID.randomUUID().toString()); // Need to fix
		bundle.getMeta().setLastUpdated(new Date());
		bundle.setType(BundleTypeEnum.COLLECTION);

		List<Entry> entries = new ArrayList<>();
		for (Deque<Entry> nextBundleList : myIdToBundleVersions.values()) {
			Entry entry = nextBundleList.getLast();
			entries.add(entry);
		}
		bundle.setEntry(entries);
		bundle.setTotal(entries.size());

		return bundle;
	}

	@Override
	public Class<CarePlanBundle> getResourceType() {
		return CarePlanBundle.class;
	}

	@Read()
	public CarePlanBundle getResourceById(@IdParam IdDt theId) {
		
		CarePlanBundle bundle = new CarePlanBundle();
		bundle.setId(UUID.randomUUID().toString()); // Need to fix
		bundle.getMeta().setLastUpdated(new Date());
		bundle.setType(BundleTypeEnum.COLLECTION);

		Deque<Entry> nextBundleList = myIdToBundleVersions.get(theId.getIdPart());
		if(nextBundleList != null) {
			Entry entry = nextBundleList.getLast();
			bundle.setEntry(Arrays.asList(new Entry[] { entry }));
			bundle.setTotal(1);
		} else {
			bundle.setTotal(0);
		}

		return bundle;
	}
}

//@Read(version = true)
//public CarePlanBundle readCarePlanBundle(@IdParam IdDt theId) {
//	Deque<CarePlanBundle> retVal;
//	try {
//		retVal = myIdToBundleVersions.get(theId.getIdPartAsLong());
//	} catch (NumberFormatException e) {
//		throw new ResourceNotFoundException(theId);
//	}
//
//	if (theId.hasVersionIdPart() == false) {
//		return retVal.getLast();
//	} else {
//		for (CarePlanBundle nextVersion : retVal) {
//			String nextVersionId = nextVersion.getId().getVersionIdPart();
//			if (theId.getVersionIdPart().equals(nextVersionId)) {
//				return nextVersion;
//			}
//		}
//		// No matching version
//		throw new ResourceNotFoundException("Unknown version: " + theId.getValue());
//	}
//
//}