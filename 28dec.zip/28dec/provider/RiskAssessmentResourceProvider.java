package ca.uhn.example.provider;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.Deque;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import ca.uhn.example.model.CarePlanBundle;
import ca.uhn.example.model.RiskAssessmentBundle;
import ca.uhn.fhir.model.api.IDatatype;
import ca.uhn.fhir.model.dstu2.composite.CodeableConceptDt;
import ca.uhn.fhir.model.dstu2.composite.CodingDt;
import ca.uhn.fhir.model.dstu2.resource.Bundle;
import ca.uhn.fhir.model.dstu2.resource.CarePlan;
import ca.uhn.fhir.model.dstu2.resource.Bundle.Entry;
import ca.uhn.fhir.model.dstu2.resource.Goal.Outcome;
import ca.uhn.fhir.model.dstu2.resource.RiskAssessment;
import ca.uhn.fhir.model.dstu2.valueset.BundleTypeEnum;
import ca.uhn.fhir.model.primitive.CodeDt;
import ca.uhn.fhir.model.primitive.DecimalDt;
import ca.uhn.fhir.model.primitive.IdDt;
import ca.uhn.fhir.rest.annotation.IdParam;
import ca.uhn.fhir.rest.annotation.Read;
import ca.uhn.fhir.rest.annotation.Search;
import ca.uhn.fhir.rest.server.IResourceProvider;

public class RiskAssessmentResourceProvider implements IResourceProvider {
	private Map<String, Deque<Entry>> myIdToBundleVersions = new HashMap<String, Deque<Entry>>();

	public RiskAssessmentResourceProvider() {
		Connection conn = null;
		Statement statement = null;
		ResultSet rs = null;
		try {
			String db_connect_string = "jdbc:sqlserver://smd-HYD-sql1:1433;databaseName=Analytics_v830_interfaces";
			String db_userid = "devuser";
			String db_password = "Spectramd1234";
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(db_connect_string, db_userid, db_password);
			statement = conn.createStatement();
			String queryString = "Select commpid.ValueDetails AS CommunityId, gsipid.ValueDetails AS GSIPatientId, patient.RecordId AS PatientId, ra.Code As RiskScoreCode,\n"
					+ "		ra.CodesystemName AS RiskScoreDescription, rap.probabilityDecimial AS Score, 'N/A' AS ReasonCode, rap.SysLastUpdateddatetime AS CalculationDate\n"
					+ "		from Clinical.RiskAssessment ra\n"
					+ "		JOIN Clinical.RiskAssessmentPrediction rap ON rap.RiskAssessmentRecordId = ra.RecordId\n"
					+ "		JOIN Administration.Patient patient ON patient.RecordId = rap.PatientRecordId\n"
					+ "		JOIN Administration.PatientIdentifier commpid ON patient.RecordId = commpid.PatientRecordId AND commpid.IdentifieruseCode = 'CommunityID'\n"
					+ "		JOIN Administration.PatientIdentifier gsipid ON patient.RecordId = gsipid.PatientRecordId AND gsipid.IdentifieruseCode = 'GSIPatientID'\n";
			rs = statement.executeQuery(queryString);
			
			Map<String, List<RiskAssessment>> map = new HashMap<>();
			while (rs.next()) {
				String gsiId = rs.getString("PatientId");
				List<RiskAssessment> list = map.get(gsiId);
				if (list == null) {
					list = new ArrayList<>();
					map.put(gsiId, list);
				}
			
//			bundle = new RiskAssessmentBundle();
//			bundle.setId(UUID.randomUUID().toString());
//			bundle.getMeta().setLastUpdated(new Date());
//			bundle.setType(BundleTypeEnum.COLLECTION);

//				Bundle.Entry entry = new Bundle.Entry();
//				List<Bundle.Entry> entries = new ArrayList<Entry>();
//				entries.add(entry);
//				bundle.setEntry(entries);
//				bundle.setTotal(entries.size());
//				entry.setElementSpecificId("RiskAssessmentelement");
				RiskAssessment riskAssessment = new RiskAssessment();
//				entry.setResource(riskAssessment);
				riskAssessment.setId(UUID.randomUUID().toString());
				riskAssessment.getSubject().setReference("Patient/" + rs.getString("PatientId"));
				riskAssessment.addPrediction();
				IDatatype data = null;
				riskAssessment.getPrediction().get(0).setProbability(new DecimalDt(0.83));
				CodeableConceptDt obj = new CodeableConceptDt();
				obj.addCoding();
				obj.getCodingFirstRep().setCode(rs.getString("RiskScoreCode"));
				obj.setText(rs.getString("RiskScoreDescription"));
				riskAssessment.getPrediction().get(0).setOutcome(obj);
				list.add(riskAssessment);
			} // end of while
			// Merge Activities of the same patient across all CareGaps
			for (Map.Entry<String, List<RiskAssessment>> mapEntry : map.entrySet()) {
				Deque<Entry> entryList = myIdToBundleVersions.get(mapEntry.getKey());
				if (entryList == null) {
					entryList = new LinkedList<Entry>();
					myIdToBundleVersions.put(mapEntry.getKey(), entryList);
				}

				Entry entry = null;
				if(!entryList.isEmpty()) {
					entry = entryList.getLast();
				} else {
					entry = new Entry();
					entryList.add(entry);
				}
				
//				for (RiskAssessment carePlan : mapEntry.getValue()) {
//					if (entry.getResource() == null) {
//						entry.setResource(carePlan);
//					} else {
//						((CarePlan) entry.getResource()).getActivity().addAll(carePlan.getActivity());
//					}
//				}
			}
		} // end of try
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				statement.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
//		LinkedList<RiskAssessmentBundle> list = new LinkedList<RiskAssessmentBundle>();
//		list.add(bundle);
//		myIdToBundleVersions.put(bundle.getId().getValue(), list);
	}

	@Override
	public Class<RiskAssessmentBundle> getResourceType() {
		return RiskAssessmentBundle.class;
	}

	@Search
	public RiskAssessmentBundle findBundlesUsingArbitraryCtriteria() {
		RiskAssessmentBundle bundle = new RiskAssessmentBundle();
		bundle.setId(UUID.randomUUID().toString()); // Need to fix
		bundle.getMeta().setLastUpdated(new Date());
		bundle.setType(BundleTypeEnum.COLLECTION);

		List<Entry> entries = new ArrayList<>();
		for (Deque<Entry> nextBundleList : myIdToBundleVersions.values()) {
			Entry entry = nextBundleList.getLast();
			entries.add(entry);
		}
		bundle.setEntry(entries);
		bundle.setTotal(entries.size());

		return bundle;
	}

//	@Read(version = true)
//	public RiskAssessmentBundle readRiskAssessmentBundle(@IdParam IdDt theId) {
//		Deque<RiskAssessmentBundle> retVal;
//		try {
//			retVal = myIdToBundleVersions.get(theId.getIdPartAsLong());
//		} catch (NumberFormatException e) {
//			throw new ResourceNotFoundException(theId);
//		}
//
//		if (theId.hasVersionIdPart() == false) {
//			return retVal.getLast();
//		} else {
//			for (RiskAssessmentBundle nextVersion : retVal) {
//				String nextVersionId = nextVersion.getId().getVersionIdPart();
//				if (theId.getVersionIdPart().equals(nextVersionId)) {
//					return nextVersion;
//				}
//			}
//			// No matching version
//			throw new ResourceNotFoundException("Unknown version: " + theId.getValue());
//		}
//
//	}

	@Read()
	public RiskAssessmentBundle getResourceById(@IdParam IdDt theId) {
		RiskAssessmentBundle bundle = null;
		Connection conn = null;
		Statement statement = null;
		ResultSet rs = null;
		try {
			String db_connect_string = "jdbc:sqlserver://smd-HYD-sql1:1433;databaseName=Analytics_v830_interfaces";
			String db_userid = "devuser";
			String db_password = "Spectramd1234";
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			conn = DriverManager.getConnection(db_connect_string, db_userid, db_password);
			statement = conn.createStatement();
			String queryString = "Select commpid.ValueDetails AS CommunityId, gsipid.ValueDetails AS GSIPatientId, patient.RecordId AS PatientId, ra.Code As RiskScoreCode,\n"
					+ "		ra.CodesystemName AS RiskScoreDescription, rap.probabilityDecimial AS Score, 'N/A' AS ReasonCode, rap.SysLastUpdateddatetime AS CalculationDate\n"
					+ "		from Clinical.RiskAssessment ra\n"
					+ "		JOIN Clinical.RiskAssessmentPrediction rap ON rap.RiskAssessmentRecordId = ra.RecordId\n"
					+ "		JOIN Administration.Patient patient ON patient.RecordId = rap.PatientRecordId\n"
					+ "		JOIN Administration.PatientIdentifier commpid ON patient.RecordId = commpid.PatientRecordId AND commpid.IdentifieruseCode = 'CommunityID'\n"
					+ "		JOIN Administration.PatientIdentifier gsipid ON patient.RecordId = gsipid.PatientRecordId AND gsipid.IdentifieruseCode = 'GSIPatientID'\n"
					+ "       where patient.RecordId=" + theId.getIdPartAsLong();
			rs = statement.executeQuery(queryString);
			bundle = new RiskAssessmentBundle();
			bundle.setId(UUID.randomUUID().toString());
			bundle.getMeta().setLastUpdated(new Date());
			bundle.setType(BundleTypeEnum.COLLECTION);
			while (rs.next()) {
				Bundle.Entry entry = new Bundle.Entry();
				List<Bundle.Entry> entries = new ArrayList<Entry>();
				entries.add(entry);
				bundle.setEntry(entries);
				bundle.setTotal(entries.size());
				entry.setElementSpecificId("RiskAssessmentelement");
				RiskAssessment riskAssessment = new RiskAssessment();
				entry.setResource(riskAssessment);
				riskAssessment.setId(UUID.randomUUID().toString());
				riskAssessment.getSubject().setReference("Patient/" + rs.getString("PatientId"));
				riskAssessment.addPrediction();
				IDatatype data = null;
				riskAssessment.getPrediction().get(0).setProbability(new DecimalDt(0.83));
				CodeableConceptDt obj = new CodeableConceptDt();
				obj.addCoding();
				obj.getCodingFirstRep().setCode(rs.getString("RiskScoreCode"));
				obj.setText(rs.getString("RiskScoreDescription"));
				riskAssessment.getPrediction().get(0).setOutcome(obj);
			} // end of while
		} // end of try
		catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				rs.close();
				statement.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		LinkedList<RiskAssessmentBundle> list = new LinkedList<RiskAssessmentBundle>();
		list.add(bundle);
		return bundle;
	}

}
//END SNIPPET: provider