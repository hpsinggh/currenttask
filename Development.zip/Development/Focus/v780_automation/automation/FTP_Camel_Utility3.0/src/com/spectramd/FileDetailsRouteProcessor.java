package com.spectramd;

import com.spectramd.products.focus.common.FocusConfig;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.BasicFileAttributeView;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.text.SimpleDateFormat;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 *
 * @author heerendra.singh
 */
public class FileDetailsRouteProcessor implements Processor {
    private FileDAO fileDAO;
    private FileDetails fileDetails;
    private String srcPath;
    private String destPath;
    private String createTime;
    private String modifiedTime;

    public void setFileDetails(FileDetails fileDetails) {
        this.fileDetails = fileDetails;
    }

    public FileDetails getFileDetails() {
        return fileDetails;
    }

    public void setFileDAO(FileDAO fileDAO) {
        this.fileDAO = fileDAO;
    }

    public void setSrcPath(String srcPath) {
        srcPath = srcPath.substring(5, srcPath.indexOf('?'));
        this.srcPath = srcPath;
    }

    public void setDestPath(String destPath) {
        destPath = destPath.substring(5, destPath.length());
        this.destPath = destPath;
    }
    
    public FileDAO getFileDAO() {
        return fileDAO;
    }
    
    public static String getFileSizeBytes(File file) {
		return file.length() + " bytes";
	}
    @Override
    public void process(Exchange exchange) throws IOException {
        FocusConfig.getCurrentLogger().writeDebug("Start: Camel File Details Route Process");
        File file = exchange.getIn().getBody(File.class);
        Path p = Paths.get(file.getAbsolutePath());
        BasicFileAttributes view
                = Files.getFileAttributeView(p, BasicFileAttributeView.class).readAttributes();
        FileTime fileTime = view.creationTime();
        FileTime fileModifiedTime = view.lastModifiedTime();
        createTime = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(fileTime.toMillis());
        modifiedTime = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(fileModifiedTime.toMillis());
        fileDetails.setFileName(file.getName());
        fileDetails.setCeateTime(createTime);
        fileDetails.setModifiedTime(modifiedTime);
        fileDetails.setSrcPath(srcPath);
        fileDetails.setDestPath(destPath);
        fileDetails.setFileSize(getFileSizeBytes(file));
        System.out.println(fileDetails);
        fileDAO.createInstance();
        System.out.println("Getting file details of :"+file.getName());
        FocusConfig.getCurrentLogger().writeDebug("End: Camel File Details Route Process");
    }
}