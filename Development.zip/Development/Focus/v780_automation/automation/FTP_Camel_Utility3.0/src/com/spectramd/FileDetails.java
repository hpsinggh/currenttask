package com.spectramd;

/**
 *
 * @author heerendra.singh
 */
public class FileDetails {

    private String fileName;
    private String srcPath;
    private String destPath;
    private String ceateTime;
    private String modifiedTime;
    private long execution_ID;
    private String fileSize;

    public void setFileSize(String fileSize) {
        this.fileSize = fileSize;
    }

    public String getFileSize() {
        return fileSize;
    }
    

    public void setExecution_ID(long execution_ID) {
        this.execution_ID = execution_ID;
    }

    public long getExecution_ID() {
        return execution_ID;
    }
    
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public void setSrcPath(String srcPath) {
        this.srcPath = srcPath;
    }

    public void setDestPath(String destPath) {
        this.destPath = destPath;
    }

    public void setCeateTime(String ceateTime) {
        this.ceateTime = ceateTime;
    }

    public void setModifiedTime(String modifiedTime) {
        this.modifiedTime = modifiedTime;
    }

    public String getFileName() {
        return fileName;
    }

    public String getSrcPath() {
        return srcPath;
    }

    public String getDestPath() {
        return destPath;
    }

    public String getCeateTime() {
        return ceateTime;
    }

    public String getModifiedTime() {
        return modifiedTime;
    }

    @Override
    public String toString() {
        return "FileDetails{" + "fileName=" + fileName + ", srcPath=" + srcPath + ", destPath=" + destPath + ", ceateTime=" + ceateTime + ", modifiedTime=" + modifiedTime + ", execution_ID=" + execution_ID + ", fileSize=" + fileSize + '}';
    }
}
