/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd;

import com.spectramd.products.focus.common.FocusConfig;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.List;
import org.apache.camel.Exchange;
import org.apache.camel.Processor;

/**
 *
 * @author heerendra.singh
 */
public class ExceptionHandler implements Processor {

    private FileDAO fileDAO;

    public ExceptionHandler(FileDAO fileDAO) {
        this.fileDAO = fileDAO;
    }

    @Override
    public void process(Exchange exchange) throws Exception {
        FocusConfig.getCurrentLogger().writeDebug("Start: alternate path for exception: ExceptionProcessor method: process(..)");
        Exception e = (Exception) exchange.getProperty("CamelExceptionCaught");
        StringWriter errors = new StringWriter();
        e.printStackTrace(new PrintWriter(errors));
        FocusConfig.getCurrentLogger().writeDebug(errors);
        List<FileDetails> list = fileDAO.getFnameAndExecutionIDQuery();
        System.out.println("\n\n\n\n" + list + "\n\n\n\n\n");
        Iterator i = list.iterator();
        FileDetails fileDetails;
        String s1, s2;
        while (i.hasNext()) {
            fileDetails = (FileDetails) i.next();
//          System.out.println("\n\n\n"+fileDetails+"\n\n\n");
            s1 = fileDetails.getFileName();
            s2 = RouteProcessor.fileName;
//          System.out.println("\n"+fileDetails.getFileName()+": saved file name is "+RouteProcessor.fileName);
//          System.out.println("\n"+fileDetails.getExecution_ID()+"\n\n\n");
            if (s1.equals(s2)) {
                fileDAO.jobFailed(errors,fileDetails.getExecution_ID());
            }
        }
        FocusConfig.getCurrentLogger().writeDebug("End: alternate path for exception: ExceptionProcessor method: process(..)");
    }
}
