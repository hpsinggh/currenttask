/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 *
 * @author sathyaji.raja
 */
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

public final class PropertyFileUtils {
    
    private PropertyFileUtils() {
        
    }
    
    public static Properties readPropertyFile(String propertyFileName) {
         Properties propertyValues = null;
         try{   
               InputStream is = PropertyFileUtils.class.getResourceAsStream(propertyFileName); 
               propertyValues = new Properties();   
               propertyValues.load(is);   

         } catch (Exception ex) {
             // do nothing
             //System.out.println(ex.getMessage());
         }
         
         return propertyValues;
    }
    
     public static Properties readPropertyFromFile(String propertyFileName) {
         
         InputStream is = null;
         Properties propertyValues = null;
         try{   
               is = new FileInputStream(propertyFileName); 
               propertyValues = new Properties();   
               propertyValues.load(is);   

         } catch (Exception ex) {
             // do nothing
             System.out.println(ex.getMessage());
         } finally  {
             try  {
                if (is != null) {
                    is.close();
                }
             } catch (Exception ex) {
                 //System.out.println(ex.getMessage());
             }
         }
         
         return propertyValues;
    }
}
