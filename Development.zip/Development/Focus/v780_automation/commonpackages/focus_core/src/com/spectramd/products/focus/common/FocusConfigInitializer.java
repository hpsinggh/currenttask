/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.utils.ThreadUtils;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Properties;

/**
 *
 * @author sathyaji.raja
 */
public class FocusConfigInitializer {
    
    private static ClientInfo currentClientInfo = null;
    
    
    public static ClientInfo getCurrentClientInfo() {
        return currentClientInfo;
    }
    
    public static void initialize(String configPath) { 
        
       ClientInfo clientInfo = getClientConfig(configPath, null);
       String clientId = clientInfo.getClientCode();
       
       FocusConfig.initialize(clientId, clientInfo.getMapConfig());
       
       ThreadUtils.set("FOCUS_CLIENTID", clientId);
       ThreadUtils.set("FOCUS_CLIENTPATH", clientInfo.getPath());
       currentClientInfo = clientInfo;
    }
    
    public static void initialize(String configPath, String rootPath) {

        ClientInfo clientInfo = getClientConfig(configPath, rootPath);
        String clientId = clientInfo.getClientCode();

        FocusConfig.initialize(clientId, clientInfo.getMapConfig());

        ThreadUtils.set("FOCUS_CLIENTID", clientId);
        ThreadUtils.set("FOCUS_CLIENTPATH", rootPath);
        currentClientInfo = clientInfo;
    }
    
    public static ClientInfo getClientConfig(String configPath, String rootPath) { 
        
        ClientInfo clInfo = new ClientInfo();
        
        // 1. Load the property file
        Properties config = PropertyFileUtils.readPropertyFromFile(configPath);
        FocusLogger.debug("config file loaded");
       
       // 2. Read each property in the config file
       String clientId = "";
       String clientpath = "";
       boolean headerRequired = true;
       Date feedReceiveDate = null;
       OrderedInsensitiveMap mapConfigInfo = new OrderedInsensitiveMap();
       Iterator configKeys = config.keySet().iterator();
       FocusLogger.debug("count of keys in property file =" + config.keySet().size());
       while (configKeys.hasNext()) {
           Object key = configKeys.next();
           String value = config.get(key).toString();
           FocusLogger.debug("config key =" + key + ", value=" + value);
           
           // 2a. parse the value
           String[] splittedValues = value.split(";");
           if (splittedValues != null && splittedValues.length > 1) {
               String configType = splittedValues[0];
               FocusLogger.debug("config type ="+configType +",info =" + splittedValues[1]);
               if (configType.equalsIgnoreCase("datasource")) {
                   mapConfigInfo.put(key, parseDataSourceConfig(splittedValues[1], rootPath));
                   
               } else if (configType.equalsIgnoreCase("logger")) {
                   mapConfigInfo.put(key, splittedValues[1]);//parseLoggerConfig( splittedValues[1]));
               } else if (configType.equalsIgnoreCase("client")) {
                   clientId = splittedValues[1];
               } else if (configType.equalsIgnoreCase("clientpath")) {
                   clientpath = splittedValues[1];
               } // Sathya: Note needed 
               /*else if (configType.equalsIgnoreCase("folderpath")) {
                   String folderpath = splittedValues[1];
                   mapConfigInfo.put(key, folderpath);
               }*/
               else if (configType.equalsIgnoreCase("clientheader")) {
                   headerRequired = (splittedValues[1].equalsIgnoreCase("true"));
               } else if (configType.equalsIgnoreCase("query")) {
                   String query = splittedValues[1];
                   mapConfigInfo.put(key, query);
               } else if (configType.equalsIgnoreCase("jndi")) {
                   mapConfigInfo.put(key, splittedValues[1]);
                   FocusLogger.debug("config key=" + key + ",value=" + splittedValues[1]);
               }
               else if (configType.equalsIgnoreCase("app_type")) {
                   mapConfigInfo.put(key,  splittedValues[1]);
                   FocusLogger.debug("config key=" + key + ",value=" + value);
               }
               else if (configType.equalsIgnoreCase("propertyfile")) {
                   
                   String filePath =splittedValues[1].toUpperCase();
                   //System.out.println("property file path ="+ filePath);
                   
                    if (rootPath != null && rootPath.length() > 0) {
                       filePath = rootPath+ filePath;
                       //System.out.println("updated property file path ="+ filePath);
                   }
                   
                   mapConfigInfo.put(key, parsePropertyFile(filePath));
                   FocusLogger.debug("config key=" + key + ",value=" + splittedValues[1]);
               } else if(configType.equalsIgnoreCase("date")){
//                   Date date1=new SimpleDateFormat("dd/MM/yyyy").parse((splittedValues[1].toString()); 
                   clInfo.setFeedReceiveDateStr(splittedValues[1]);
               }
           }
       }
       
       //3. Do the initialization
       FocusLogger.debug("clientid =" + clientId + ",size =" + mapConfigInfo.keySet().size());
       clInfo.setClientCode(clientId);
       clInfo.setPath(clientpath);
       clInfo.setHeaderRequired(headerRequired);
//       clInfo.setFeedReceiveDate(feedReceiveDate);
       clInfo.setMapConfig(mapConfigInfo);
       
       return clInfo;
    }
    
    
    private static ConfigInfo parseDataSourceConfig(String value, String rootPath) {
        DBConfigInfo dataSourceConfig = new DBConfigInfo();
        dataSourceConfig.setType("DATASOURCE");
        
        if (rootPath != null && rootPath.length() > 0) {
            value = rootPath + value;
        }
        
        //System.out.println("data source path = " + value);
        Properties dbConfig = PropertyFileUtils.readPropertyFromFile(value);
        FocusLogger.debug("count of properties in datasource =" + dbConfig.keySet().size() );
        dataSourceConfig.setDBProperties(dbConfig);
        
        return dataSourceConfig;
    }
    
    private static ConfigInfo parseLoggerConfig( String value) {
     
        ValueConfigInfo logInfo = new ValueConfigInfo();
        logInfo.setType("VALUE");
        logInfo.setValue(value);
        
        return logInfo;
    }

    private static ConfigInfo parsePropertyFile(String value) {

        PropertyConfigInfo propertyInfo = new PropertyConfigInfo();
        propertyInfo.setPropertyMap(PropertyFileUtils.readPropertyFromFile(value));
        
//        Properties prop = propertyInfo.getPropertyMap();
//        Enumeration<Object> keys = prop.keys();
//        while (keys.hasMoreElements()) {
//            System.out.println("key = " + keys.nextElement());
//        }
        
        return propertyInfo;
    }
}
