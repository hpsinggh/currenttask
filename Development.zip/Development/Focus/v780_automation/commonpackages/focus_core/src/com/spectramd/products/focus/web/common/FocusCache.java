/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.web.common;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author sathyaji.raja
 */
public class FocusCache {
  
   private static Map<String, Object> cacheMap = new HashMap<String, Object>();
   
   public FocusCache()  {
       
   }
   
   public void putObject(String objectKey, Object data,CacheScope scope)   {
      cacheMap.put(objectKey, data);
   }
   
   public Object getObject(String objectKey, CacheScope scope)   {
       return cacheMap.get(objectKey);
   }
   
   public void invalidate(CacheScope scope)   {
       clearObjects(scope);
   }
   
   public void clearObjects(CacheScope scope)   {
       
       cacheMap.clear();
   }
}

