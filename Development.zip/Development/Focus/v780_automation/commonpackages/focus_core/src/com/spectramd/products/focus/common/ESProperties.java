/*
 * To change this license header; choose License Headers in Project Properties.
 * To change this template file; choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import java.util.Map;

/**
 *
 * @author pratap.konakala
 */
public class ESProperties {
    private String index;
    private String type;
    private String ipAddress;
    private int port;
    private String templateName;
    private String clusterName;
    private Map<String,Object> templateParams;
    private String sortField;
    
    public ESProperties(String clusterName,String index, String type, 
            String sortField, String sortDirection,String ipAddress, int port) {
        this.clusterName = clusterName;
        this.index = index;
        this.type = type;
        this.ipAddress = ipAddress;
        this.port = port;
        this.sortField = sortField;
    }
    
    public String getIndex() {
        return index;
    }

    public String getType() {
        return type;
    }

    public String getIpAddress() {
        return ipAddress;
    }

    public int getPort() {
        return port;
    }

    public String getTemplateName() {
        return templateName;
    }
    
    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }
    
    public Map<String, Object> getTemplateParams() {
        return templateParams;
    }
    
    public void setTemplateParams(Map<String, Object> templateParams) {
        this.templateParams = templateParams;
    }
    
    public String getSortField() {
        return sortField;
    }
    
    public String getClusterName() {
        return clusterName;
    }
}
