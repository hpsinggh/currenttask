/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

/**
 *
 * @author sathyaji.raja
 */
public class WebServiceUtils {
    
    public static  <T> T getService(String address, String serviceNamespace, String serviceName, 
                                        String servicePort, Class<T> serviceEndpointInterface) throws MalformedURLException {
  
            URL wsdlURL = new URL(address);
            QName SERVICE_NAME = new QName(serviceNamespace, serviceName);
            
            Service service = Service.create(wsdlURL, SERVICE_NAME);
            return service.getPort(new QName(serviceNamespace, servicePort), serviceEndpointInterface);
   
    }
    
}
