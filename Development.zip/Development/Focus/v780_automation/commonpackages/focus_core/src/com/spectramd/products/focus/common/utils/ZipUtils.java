/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import java.util.zip.ZipOutputStream;
import org.apache.commons.io.IOUtils;

/**
 *
 * @author sathyaji.raja
 */
public class ZipUtils {
    
    private ZipUtils() {
        
    }
    
    public static void addFileToZip(ZipOutputStream zipOutputStream, File file) throws Exception {
        
        InputStream is = null;
        try {
            is = new FileInputStream(file);
            
            ZipEntry zipEntry = new ZipEntry(file.getName());
            zipEntry.setTime(file.lastModified());
            zipOutputStream.putNextEntry(zipEntry);
            
            byte[] buffer = new byte[1024];
            int len = 0;
            while ((len = is.read(buffer)) > 0) {
                zipOutputStream.write(buffer,0, len);
            }
            
        } finally {
            if(zipOutputStream != null){
                zipOutputStream.closeEntry();
            }          
            if (is != null) {
                is.close();
            }
        }
    }
    
    public static void compressFolder(String sourceFolderPath, String zipName) throws Exception {
        ZipOutputStream zipOutputStream = null;
        FileOutputStream fileOutputStream = null;

        try {
           
            fileOutputStream = new FileOutputStream(zipName);
            zipOutputStream = new ZipOutputStream(fileOutputStream);

            File files = new File(sourceFolderPath);
            for (File file : files.listFiles()) {
                if (file.isFile()) {
                    ZipUtils.addFileToZip(zipOutputStream, file);
                }
            }
      
        } finally {
            
            if (zipOutputStream != null) {
                zipOutputStream.close();
            }
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }
            
        }
    }   
        

    public static void compressFiles(List<File> fileNames, String zipName) throws Exception {
        ZipOutputStream zipOutputStream = null;
        FileOutputStream fileOutputStream = null;

        try {

            fileOutputStream = new FileOutputStream(zipName);
            zipOutputStream = new ZipOutputStream(fileOutputStream);

            for (File file : fileNames) {
                ZipUtils.addFileToZip(zipOutputStream, file);
            }

         } finally {

            if (zipOutputStream != null) {
                zipOutputStream.close();
            }
            if (fileOutputStream != null) {
                fileOutputStream.close();
            }

        }
    }
    
   
    /**
     * Reads zip files from the sourcePath and extracts to sourcepath
     *
     * @param sourcePath
     * @throws Exception
     */
    public static void unCompressFiles(String sourcePath) throws Exception {
        
       
        //List<File> deleteFileList = new ArrayList<File>();
        try {
            //1. Create folder if not created
            IOUtil.createFolder(sourcePath);
            
            //2. Create inputFolder from given source path
            File inputFolder = new File(sourcePath);
            
            //3. Check whether files are available in the folder
            if (inputFolder.listFiles() != null) {
                
                //4. Iterate through the files
                for (File inputFile : inputFolder.listFiles()) {
                    
                    //5. Check whether file is directory ,if yes invoke uncompress on the same folder, otherwise check whether file ext is "zip" or "rar"
                    if(inputFile.isDirectory()){
                        unCompressFiles(inputFile.getAbsolutePath());
                    }else if (inputFile.isFile() && (inputFile.getName().endsWith(".zip") 
                                                    || inputFile.getName().endsWith(".rar"))) {
                        
                        ZipInputStream zipInputStream = null;
                        BufferedOutputStream bos = null;
                        try {
                        //6. Create ZipInputStream
                        zipInputStream = new ZipInputStream(new FileInputStream(inputFile));
                        
                        //7. Get ZipEntry from the ZipInputStream
                        ZipEntry entry = zipInputStream.getNextEntry();
                        
                        //8. Check ZipEntry is not null
                        while (entry != null) {
                            
                            String filePath = sourcePath + File.separator + entry.getName();
                            
                            //9. Check whether entry is directory if yes create directory otherwise copy the file 
                            if (entry.isDirectory()) {
                                File dir = new File(filePath);
                                dir.mkdir();
                            } else {
                                bos = new BufferedOutputStream(new FileOutputStream(filePath));
                                IOUtils.copy(zipInputStream, bos);
                                
                                //10.Add the file to deleteFileList
                                //deleteFileList.add(inputFile);
                                //bos.close();
                            }
                            zipInputStream.closeEntry();
                            entry = zipInputStream.getNextEntry();
                        }
                        } finally {
                            
                            if (bos != null) {
                                 bos.close();
                            }
                            if (zipInputStream != null) {
                                zipInputStream.close();
                            }
                        }
                    }
                }
                
                //11. Delete the files
//                for(File file : deleteFileList){
//                    file.delete();
//                }
                
            }
        }catch(Exception e){
            throw e;
        }
        
    }
    
    /**
     * Reads zip file and extracts to outputFolder
     *
     * @param zipFile
     * @param outputFolder
     * @throws Exception
     */
    public static void unCompressFile(String zipFile, String outputFolder) throws Exception {
        
        ZipInputStream zipInputStream = null;
        BufferedOutputStream bos = null;
        try {
            //6. Create ZipInputStream
            zipInputStream = new ZipInputStream(new FileInputStream(zipFile));

            //7. Get ZipEntry from the ZipInputStream
            ZipEntry entry = zipInputStream.getNextEntry();

            //8. Check ZipEntry is not null
            while (entry != null) {

                String filePath = outputFolder + File.separator + entry.getName();

                //9. Check whether entry is directory if yes create directory otherwise copy the file 
                if (entry.isDirectory()) {
                    File dir = new File(filePath);
                    dir.mkdir();
                } else {
                    bos = new BufferedOutputStream(new FileOutputStream(filePath),512);
                    IOUtils.copy(zipInputStream, bos);

                    //10.Add the file to deleteFileList
                    //deleteFileList.add(inputFile);
                    //bos.close();
                }
                zipInputStream.closeEntry();
                entry = zipInputStream.getNextEntry();
            }
        } finally {

            if (bos != null) {
                 bos.close();
            }
            if (zipInputStream != null) {
                zipInputStream.close();
            }
        }
 
    }
    
}
