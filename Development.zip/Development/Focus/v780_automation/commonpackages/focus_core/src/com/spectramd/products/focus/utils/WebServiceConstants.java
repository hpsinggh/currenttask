/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

/**
 *
 * @author sathyaji.raja
 */
public class WebServiceConstants {
    
    public static final String ADDRESS = "address";
    public static final String NAMESPACE = "namespace";
}
