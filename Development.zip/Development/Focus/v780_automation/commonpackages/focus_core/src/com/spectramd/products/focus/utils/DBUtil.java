
package com.spectramd.products.focus.utils;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.ListIterator;
import java.util.Map;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sathyaji.raja
 */
public final class DBUtil {
    
    public static String Error_failedtoclosedbresources = "Failed to close DB resources";
	public static String Error_failedtocommitdbconnection = "Failed to commit DB connection";
	public static String Error_failedtorollbackdbconnection = "Failed to rollback DB connection";
    
    private DBUtil() {
    }
    
    public static Connection getConnection(String jndiDataSource) 
                                throws ClassNotFoundException, SQLException, NamingException {
        
        // Declare the JDBC objects.
	Context initContext = new InitialContext();
        // this is for tomcat
        String dataSourceString = "java:comp/env/jdbc/" + jndiDataSource;
        
        // this is for jboss
        //String dataSourceString = "java:jdbc/" + jndiDataSource;
        DataSource datasource = (DataSource)initContext.lookup(dataSourceString);
        
        // Get the connection
        Connection con = datasource.getConnection();
        //FocusConfig.getCurrentLogger().writeInfo("Database Connection to " + jndiDataSource + " is successful");

        return con;
    }
    
     public static Connection getConnection(String jdbcDriverName, String jdbcURL, Properties props) 
                                                        throws ClassNotFoundException, SQLException {

        // Establish the connection.
        Class.forName(jdbcDriverName);
        return DriverManager.getConnection(jdbcURL, props);

    }
    
    public static Statement getStatement(Connection con, int fetchSize) throws SQLException {
        
        Statement stmt = con.createStatement();
        stmt.setFetchSize(fetchSize);
        stmt.setFetchDirection(ResultSet.FETCH_FORWARD);
        return stmt;
    }
    
    public static OrderedInsensitiveMap getResulSetAsMap(ResultSet rs, 
                                                    ResultSetMetaData rsMetaData) throws SQLException {
        OrderedInsensitiveMap mapRow = new OrderedInsensitiveMap();
        UpdateResultSetInMap(mapRow, rs, rsMetaData);
        return mapRow;
    }
    
	/**
	 * Sumit: Return null if DB value is also null (rather than default values of 0 for Integer / Long / Double / etc.)
	 *
	 * @param rs
	 * @param rsMetaData
	 * @param index
	 * @return
	 * @throws SQLException
	 */
    public static Object getColumnValue(ResultSet rs, ResultSetMetaData rsMetaData, 
                                                        int index) throws SQLException {
        
        Object returnValue = null;
            switch (rsMetaData.getColumnType(index)){
                case Types.BIGINT:
                    returnValue = rs.getLong(index);
                    break;
                case Types.INTEGER:
                    returnValue = rs.getInt(index);
                    break;
                case Types.DATE:
                    returnValue = rs.getDate(index);
                    break;
                 case Types.NUMERIC:
                    returnValue = rs.getDouble(index);
                    break;
                default:
                case Types.VARCHAR:
                case Types.NVARCHAR:
                    returnValue = rs.getString(index);
                    break;
            }
        return rs.wasNull() ? null : returnValue;
    }
    
    public static void UpdateResultSetInMap(OrderedInsensitiveMap mapRow, ResultSet rs, 
                                                ResultSetMetaData rsMetaData) throws SQLException {
        
        int columns = rsMetaData.getColumnCount();
        //System.out.println("no. of columns =" + columns);
        for (int index = 1; index <= columns; index++){
            String colName = rsMetaData.getColumnLabel(index);
            //System.out.println(" column name for index" + index + " is " + colName);
            Object colValue = getColumnValue(rs, rsMetaData, index);
            //System.out.println("key = " + colName + "value =" + (colValue == null? "null" : colValue));
            mapRow.put(colName, colValue);
        }
    }
    
    public static void BatchUpdate(Connection con, String destTable, ArrayList<OrderedInsensitiveMap> resultMapList) 
                                  throws SQLException,ClassNotFoundException, NamingException {
        
        //Connection con = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            // Create the query and set the filter
            //con = DBUtil.getConnection();
            stmt = con.createStatement();
            
            // add the list to statment
            ListIterator<OrderedInsensitiveMap> iterator = resultMapList.listIterator();
            while (iterator.hasNext()) {
                OrderedInsensitiveMap mapRow = iterator.next();
                
                boolean isFirstRow = true;
                String colNames = "(";
                String colValues = "(";
                Iterator rowKeys = mapRow.keySet().iterator();
                while (rowKeys.hasNext()) {
                    String rowKey = rowKeys.next().toString();
                    if (!isFirstRow) {
                        colNames += ",";
                        colValues += ",";
                    }

                    // Update colname
                    colNames += rowKey;
                   
                    // Update column Value
                    Object colValue = mapRow.get(rowKey);
					if (colValue.getClass() == String.class) {
                        colValues += "\""+ colValue.toString() +"\" ";
					} else {
                        colValues += colValue.toString();
					}
                    isFirstRow = false;
                }
                colNames += ")";
                colValues += ")";
                
                // Build Query
                String query = DBUtil.buildPreparedStatement(destTable, colNames, colValues);
                //System.out.println("Batch update query = "+ query);
                
                stmt.addBatch(query);
            }
             
		} finally {
			if (rs != null) {
				rs.close();
			}
			if (stmt != null) {
				stmt.close();
        } 
	    	//if (con != null) con.close();
        }
        
    }
    
    public static String buildPreparedStatement(String destTable, String colNames, String colValues) {
        StringBuilder preparedStmt = new StringBuilder(200);
        
        preparedStmt.append("INSERT INTO ");
        preparedStmt.append(destTable);
        preparedStmt.append(" ");
                
        // add to the statement
        preparedStmt.append(colNames);
        preparedStmt.append(" VALUES ");
        preparedStmt.append(colValues);
        preparedStmt.append(";");
        
        return preparedStmt.toString();
    }
    
    public static ResultSet getResults(String customQuery, Connection conn, 
                                                            Statement stmt) throws SQLException {
        stmt = conn.createStatement();
        return stmt.executeQuery(customQuery);
    }
    
    public static void closeAllObjects(Connection conn, Statement stmt, ResultSet rs) throws SQLException{
		if (rs != null) {
			rs.close();
		}
		if (stmt != null) {
			stmt.close();
		}
		if (conn != null) {
			conn.close();
		}
    }
    
    public static void closeAllObjects(Connection conn, PreparedStatement pstmt, 
                                                            ResultSet rs) throws SQLException{
		if (rs != null) {
			rs.close();
		}
		if (pstmt != null) {
			pstmt.close();
		}
		if (conn != null) {
			conn.close();
		}
    }
    
    public static void closeAllObjects(Connection conn, CallableStatement cstmt, 
                                                        ResultSet rs) throws SQLException {
		if (rs != null) {
			rs.close();
		}
		if (cstmt != null) {
			cstmt.close();
		}
		if (conn != null) {
			conn.close();
		}
    }
    
	/**
	 * Closes all ResultSets.
	 * @param rsList ResultSet[]
	 * @throws SQLException on error
	 */
	public static void closeAllObjects(final ResultSet... rsList) throws SQLException {
		if (rsList != null && rsList.length > 0) {
			for (ResultSet rs : rsList) {
				if (rs != null) {
					rs.close();
				}
			}
		}
	}

	/**
	 * Closes all Statements.
	 * @param stmtList Statement[]
	 * @throws SQLException on error
	 */
	public static void closeAllObjects(final Statement... stmtList) throws SQLException {
		if (stmtList != null && stmtList.length > 0) {
			for (Statement stmt : stmtList) {
				if (stmt != null) {
					stmt.close();
				}
			}
		}
	}

     public static long executeDML(PreparedStatement pstmt) throws SQLException {

        
        long returnFlag = pstmt.executeUpdate();
        
        ResultSet generatedId = pstmt.getGeneratedKeys();
		if (generatedId.next()) {
            returnFlag = generatedId.getLong(1);
		}
           
        return returnFlag;
     }
     
     public static long execute(PreparedStatement pstmt) throws SQLException {

        long returnValue = -1;
        
        if (pstmt.execute() )   {
            ResultSet generatedId = pstmt.getResultSet();
			if (generatedId.next()) {
                returnValue = generatedId.getLong(1);
        }
		}
           
        return returnValue;
    }
     
    public static String constructInsertStatement(String tableName, 
                                                    Collection<String> columnNames) throws SQLException {
       
       //FocusConfig.getCurrentLogger().writeDebug("Entering into DBUtils::constructInsertStatement");
       
       StringBuilder insertQuery = new StringBuilder("INSERT INTO ");
       insertQuery.append(tableName);
       
       if(columnNames != null && !columnNames.isEmpty())    {
           int index = 1;
           StringBuilder parameters = new StringBuilder();
           insertQuery.append(" (");
           for(String columnName : columnNames) {
              if(index != 1){
                  insertQuery.append(",");
                  parameters.append(",");
              }
              
              insertQuery.append(columnName);
              parameters.append("?");
              index++;
           }
           insertQuery.append(") VALUES (");
           insertQuery.append(parameters);
           insertQuery.append(")");
         }
      
        //FocusConfig.getCurrentLogger().writeDebug("Exit of DBUtils::constructInsertStatement");
        return insertQuery.toString();
    }
    
    public static void populatePrepareStatement(PreparedStatement preparedStatement,
                                                        Collection<Object> columnValues) throws SQLException    {
 
        //FocusConfig.getCurrentLogger().writeDebug("Entering into DBUtils::constructInsertStatement");
        
        int parameterIndex = 1;
        for(Object columnValue : columnValues)  {
            if(columnValue instanceof Long){
                preparedStatement.setLong(parameterIndex,(Long)columnValue);
            }else if(columnValue instanceof String){
                preparedStatement.setString(parameterIndex,(String)columnValue);
            }else if(columnValue instanceof Integer){
                preparedStatement.setInt(parameterIndex,(Integer)columnValue);
            }else if(columnValue instanceof Float){
                preparedStatement.setFloat(parameterIndex,(Float)columnValue);
            }else if(columnValue instanceof Double){
                preparedStatement.setDouble(parameterIndex,(Double)columnValue);
            }else if(columnValue == null){
                preparedStatement.setObject(parameterIndex, null);
            }
            
            parameterIndex++;
        }
     
        //FocusConfig.getCurrentLogger().writeDebug("Exit of DBUtils::constructInsertStatement");
    }
    
    public static Map getColumnIndexAsMap( ResultSet rs, 
                                       ResultSetMetaData rsMetaData,
                                       String excludeColumnName) throws SQLException {
        
        Map mapColumns = new LinkedHashMap();
        int columns = rsMetaData.getColumnCount();
        
        
        for (int index = 1, mapIndex=1; index <= columns; index++){
            String colName = rsMetaData.getColumnName(index);
            
            if (!colName.equalsIgnoreCase(excludeColumnName)) {
                Object colValue = getColumnValue(rs, rsMetaData, index);
                mapColumns.put(String.valueOf(mapIndex), colValue);
                mapIndex++;
            }
        }
        
        return mapColumns;
    }
    
     public static Map getResulSetColumnsAsMap(ResultSet rs, 
                                                    ResultSetMetaData rsMetaData,
                                                    String excludeColumnName) throws SQLException {
        Map mapColumns = new HashMap();
        
        int columns = rsMetaData.getColumnCount();
        for (int index = 1; index <= columns; index++){
            String colName = rsMetaData.getColumnName(index).toUpperCase();
            
            if (!colName.equalsIgnoreCase(excludeColumnName)) {
                Object colValue = getColumnValue(rs, rsMetaData, index);
                mapColumns.put(colName, colValue);
              }
        }
        
        return mapColumns;
    }
}
