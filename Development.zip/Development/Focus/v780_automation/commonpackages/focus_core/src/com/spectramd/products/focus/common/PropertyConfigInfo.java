/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import java.io.Serializable;
import java.util.Properties;

/**
 *
 * @author ramya.khasnis
 */
public class PropertyConfigInfo  extends ConfigInfo implements Serializable{
    
    private Properties propertyMap;

    public Properties getPropertyMap() {
        return propertyMap;
    }

   
    public void setPropertyMap(Properties propertyMap) {
        this.propertyMap = propertyMap;
    }
}
