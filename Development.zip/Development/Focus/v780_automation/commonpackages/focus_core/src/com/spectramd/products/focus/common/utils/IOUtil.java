/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.common.FocusConfig;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;

/**
 *
 * @author smujtab
 */
/******************************************************************************************
*  Change Made: added method getLatestFile
*  Author: Ramya
*  Date of Change: 08/19/2013
******************************************************************************************/
public class IOUtil {

    private static String DATETIME_FORMAT = "yyyy-MM-dd HH-mm-ss";
    public static String ERROR_CLOSE_RESOURCES = "Failed to close resources";
    
    private IOUtil() {
        
    }
    
    public static void moveOverrideFile(File filename, File destFile) throws IOException {
        FileUtils.copyFile(filename, destFile);
        filename.delete();
    }

    public static String getDateTime() {
        DateFormat dateFormat = new SimpleDateFormat(DATETIME_FORMAT);
        return (dateFormat.format(new Date()));
    }

    public static boolean createFolder(String folderName) {
        boolean result = false;
        File folder = new File(folderName);
        if (!folder.exists()) {
            folder.mkdirs();
            result = true;
        }
        return result;
    }

    /**
     *
     * @param filePath File Path of the file
     * @param data Data to be written to file
     * @throws Exception
     */
    public static void writeToFile(String filePath, String data) throws Exception {
        File file = new File(filePath);
        FileUtils.writeStringToFile(file, data);
    }

    public static void writeBytesToFile(String filePath, byte[] data) throws Exception {
        
        OutputStream output = null;
        try {
            output = new FileOutputStream(filePath);
            IOUtils.write(data, output);
        } finally {
            if (output != null) {
                output.close();
            }
        }
    }
    
    public static List<File> getFiles(String path) {
         File directory = new File(path);
         
         List<File> files = new ArrayList<File>();
         File[] tempList = directory.listFiles();
         if (tempList != null) {
             for (File tempFile : tempList) {
                 if (tempFile.isFile()) {
                     files.add(tempFile);
                 }
             }
         }
         
         return files;
    }
    
    public static List<File> getFiles(String path, String extn) {
         File directory = new File(path);
         
         List<File> files = new ArrayList<File>();
         
         File[] tempList = directory.listFiles();
         if (tempList != null) {
             for (File tempFile : tempList) {
                 if (tempFile.isFile() && tempFile.getName().endsWith(extn)) {
                     files.add(tempFile);
                 }
             }
         }
         
         return files;
    }
    
    public static void deleteFile(String filePath) {
        File file = new File(filePath);
        if(file.exists()){
            file.delete();
        }
    }
    
    /**
     * getLatestFile - gets the file from sourceFolder with name starting with "filenamePrefix" and lasted modified date
     * @param sourceFolder the folder to search for files
     * @param filenamePrefix the prefix pattern of the file to check for
     * @return File Latest file that matches the given prefix pattern in the folder supplied
     * @throws IOException 
     */
    public static File getLatestFile(String sourceFolder, String filenamePrefix) throws IOException {

        File latestFile = null;
        
        // 1. get the list of files from source folder
        long lastModifiedDateOfSource = 0;
        filenamePrefix = filenamePrefix.toLowerCase();
        List<File> sourceFiles = IOUtil.getFiles(sourceFolder);
        for (File sourceFile : sourceFiles) {

            //check if filename starts with given prefix
            String filename = sourceFile.getName().toLowerCase();
            if (filename.startsWith(filenamePrefix)) {

                //check if previous lastmodified date is less than current file's last modified date
                if (lastModifiedDateOfSource <= sourceFile.lastModified()) {
                    lastModifiedDateOfSource = sourceFile.lastModified();
                    latestFile = sourceFile;
                }
            }
        }

        return latestFile;
    }
    
    public static void moveFiles(String sourceDir, String destinationDir) throws Exception {
        
        System.out.println("Source directory =" + sourceDir);
        File inputFolder = new File(sourceDir);
      
        List<File> fileList = new ArrayList<File>();
        for (File inputFile : inputFolder.listFiles()) {
            if (inputFile.isFile()) {
                File destFile = new File(destinationDir+"//" + inputFile.getName());
                IOUtil.moveOverrideFile(inputFile, destFile);
            }
        } 
    }
    
     public static long moveFiles2(File inputFolder, File destPath, List<String> errorFiles) {
        long fileCount = 0;
        
        if (inputFolder.exists() && inputFolder.listFiles() != null) {
            for (File inputFile : inputFolder.listFiles()) {
                if (inputFile.isFile()) {
                    try {
                        File destFile = new File(destPath.getAbsolutePath() + "//" + inputFile.getName());
                        IOUtil.moveOverrideFile(inputFile, destFile);
                        fileCount++;
                        //sourcePathNotEmpty = true;
                    } catch (IOException ex) {
                        FocusConfig.getCurrentLogger().writeError("Failed to move Files", ex);
                        errorFiles.add(inputFile.getName());
                    }
                }
            }
        } 
        
        return fileCount;
    }
    
     public static long copyFiles(File inputFolder, File destPath, List<String> errorFiles) {
        long fileCount = 0;
        
        if (inputFolder.exists() && inputFolder.listFiles() != null) {
            for (File inputFile : inputFolder.listFiles()) {
                if (inputFile.isFile()) {
                    try {
                        File destFile = new File(destPath.getAbsolutePath() + "//" + inputFile.getName());
                        FileUtils.copyFile(inputFile, destFile);
                        fileCount++;
                        //sourcePathNotEmpty = true;
                    } catch (IOException ex) {
                        FocusConfig.getCurrentLogger().writeError("Failed to move Files", ex);
                        errorFiles.add(inputFile.getName());
                    }
                }
            }
        } 
        
        return fileCount;
    }
}
