/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 *
 * @author sathyaji.raja
 */
public final class StringUtils {

	public static String[] splitBySemiColon(String filterKey) {

		return (filterKey != null ? filterKey.split(";") : null);
	}

	public static String[] splitByComma(String dataToSplit) {

		return (dataToSplit != null ? dataToSplit.split(",") : null);
	}

	public static ArrayList getListFromSplit(String dataToSplit, String separator) {

		ArrayList listSplit = null;
		String[] splitArray = (dataToSplit != null ? dataToSplit.split(separator) : null);
		if (splitArray != null && splitArray.length > 0) {

			listSplit = new ArrayList();
			for (String element : splitArray) {
				listSplit.add(element);
			}
		}

		return listSplit;
	}

	public static <T extends Object> List<T> getGenericListFromSplit(String dataToSplit, String separator, final Class<T> clazz) {

		ArrayList<T> listSplit = new ArrayList<T>();
		if (notEmpty(dataToSplit)) {
			String[] splitArray = (dataToSplit != null ? dataToSplit.split(separator) : null);
			if (splitArray != null && splitArray.length > 0) {

				//listSplit = new ArrayList<T>();
				for (String element : splitArray) {
					if (clazz.equals(Integer.class)) {
						listSplit.add((T) Integer.valueOf(element));
					} else if (clazz.equals(Long.class)) {
						listSplit.add((T) Long.valueOf(element));
					} else if (clazz.equals(Float.class)) {
						listSplit.add((T) Float.valueOf(element));
					} else if (clazz.equals(Double.class)) {
						listSplit.add((T) Double.valueOf(element));
					} else if (clazz.equals(String.class)) {
						listSplit.add((T) String.valueOf(element));
					} else {
						throw new RuntimeException(String.format("Type %s is not supported (yet)", clazz.getName()));
					}
				}
			}
		}
		return listSplit;
	}

	public static String[] splitByColon(String dataToSplit) {

		return (dataToSplit != null ? dataToSplit.split(":") : null);
	}

	public static String convertQuotes(String str) {
		if (str != null) {
			str = str.replace("'", "''");
		}
		return str;
	}

	public static String capitilize(String str, Character delimiter) {

		String changedString = "";
		if (str != null && str.length() > 0) {

			StringBuilder temp = new StringBuilder();
			temp.append(Character.toUpperCase(str.charAt(0)));

			for (int index = 1; index < str.length(); index++) {
				Character letter = str.charAt(index);
				temp.append(Character.toLowerCase(letter));

				// check if we need to capitilize the next letter
				if (letter == delimiter) {
					if (index < (str.length() - 1)) {
						temp.append(Character.toUpperCase(str.charAt(++index)));
					}
				}
			}

			changedString = temp.toString();
		}

		return changedString;
	}

	public static boolean notEmpty(String strValue) {
		return (strValue != null && strValue.trim().length() > 0);
	}

	public static String getWrappedString(String input, int wrapLength) {

		StringBuilder temp = new StringBuilder(512);

		for (int index = 0; index < input.length(); index++) {
			temp.append(input.charAt(index));
		}

		return temp.toString();
	}

	public static String getCommaSeperatedString(Collection<Long> jobIds) {
		return getString(jobIds, ",");
	}

	public static String getString(Collection<Long> jobIds, String seperationChar) {

		StringBuilder commaSepString = new StringBuilder();

		int count = 1;
		for (Long jobId : jobIds) {
			commaSepString.append(jobId);

			if (count != jobIds.size()) {
				commaSepString.append(seperationChar);
			}
			count++;
		}

		return commaSepString.toString();
	}

	public static String getConcatenatedString(List<String> jobIds, String seperationChar) {

		StringBuilder commaSepString = new StringBuilder();

		int count = 1;
		for (String jobId : jobIds) {
			commaSepString.append(jobId);

			if (count != jobIds.size()) {
				commaSepString.append(seperationChar);
			}
			count++;
		}

		return commaSepString.toString();
	}

	public static boolean isEquals(String fieldString, String Value, boolean caseSensitive) {

		if (caseSensitive) {
			return fieldString.equalsIgnoreCase(Value);
		} else {
			return fieldString.equals(Value);
		}
	}

	public static long stringToLong(String value) {
		long returnValue = -1;

		try {
			returnValue = Long.parseLong(value);
		} catch (Exception ex) {
			// Log the exception
		}

		return returnValue;
	}

	public static int stringToInteger(String value) {
		int returnValue = -1;

		try {
			returnValue = Integer.parseInt(value.replace(",", ""));
		} catch (Exception ex) {
			// Log the exception
		}

		return returnValue;
	}

	public static List splitString(String dataToSplit, String separator) {

		return getListFromSplit(dataToSplit, separator);
	}

	public static String getDBCommaSeperatedString(List<String> inputList) {

		StringBuilder commaSepString = new StringBuilder();

		int count = 1;
		for (String input : inputList) {
			commaSepString.append("'");
			commaSepString.append(input);
			commaSepString.append("'");

			if (count != inputList.size()) {
				commaSepString.append(",");
			}
			count++;
		}

		return commaSepString.toString();
	}

	public static String getCommaSeperatedString(String[] input) {

		StringBuilder commaSepString = new StringBuilder();

		int count = 1;
		for (String element : input) {
			commaSepString.append(element);

			if (count != input.length) {
				commaSepString.append(",");
			}
			count++;
		}

		return commaSepString.toString();
	}

//    public static boolean isEquals(String fieldString, String Value, boolean caseSensitive)   {
//
//        if (caseSensitive){
//            return fieldString.equalsIgnoreCase(Value);
//        } else {
//            return fieldString.equals(Value);
//        }
//    }
//
//     public static long stringToLong(String value) {
//        long returnValue = -1;
//
//        try {
//            returnValue = Long.parseLong(value);
//        } catch (Exception ex) {
//            // Log the exception
//        }
//
//        return returnValue;
//    }
	/**
	 * Pad the given string with length of characters
	 * L - LeftPadding
	 * R- RightPadding
	 * B- Left & Right Padding
	 * @param data
	 * @param padChar
	 * @param padType
	 * @param length
	 * @return String
	 */
	public static String padding(String data, char padChar, char padType, int length) {
		StringBuffer paddedString = new StringBuffer();
		for (int index = 0; index < length; index++) {
			paddedString.append(padChar);
		}
		if (padType == 'L') {
			data = paddedString + data;
		} else if (padType == 'R') {
			data = data + paddedString;
		} else if (padType == 'B') {
			data = paddedString + data + paddedString;
		}
		return data;
	}

	/**
	 * This method is used to add  appendString to the prefix of each element
	 * @param input
	 * @param appendString
	 * @return String
	 */
	public static String getCommaandColonSeperatedString(String[] input, String appendString) {

		StringBuilder commaSepString = new StringBuilder();

		int count = 1;
		for (String element : input) {
			commaSepString.append(appendString + element);

			if (count != input.length) {
				commaSepString.append(",");
			}
			count++;
		}

		return commaSepString.toString();
	}

}
