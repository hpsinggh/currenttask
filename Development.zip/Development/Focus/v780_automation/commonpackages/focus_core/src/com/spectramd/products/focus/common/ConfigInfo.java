/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import java.io.Serializable;

/**
 *
 * @author sathyaji.raja
 */
public abstract class ConfigInfo implements Serializable{
    
    private String type;
    
    public String getType() {
        return type;
    }
    
    public void setType(String type) {
        this.type = type;
    }
    
}
