/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.common.FocusLogger;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author sathyaji.raja
 */
public final class ThreadUtils {

	/**
	 * Private Constructor.
	 */
	private ThreadUtils() {
	}
	/**
	 * ThreadLocal.
	 */
	private static ThreadLocal userThreadLocal = new ThreadLocal();

	/**
	 * Creates ThreadLocal as InheritableThreadLocal to provide inheritance of values from parent thread to child
	 * thread.
	 */
	public static void initializeInheritableThread() {
		userThreadLocal = new InheritableThreadLocal();
	}

	/**
	 * Add to ThreadLocal.
	 * @param key String
	 * @param value String
	 */
	public static void set(final String key, final String value) {
		set(key, (Object) value);
	}

	/**
	 * Add to ThreadLocal.
	 * @param key String
	 * @param value Object
	 */
	public static void set(final String key, final Object value) {
		Map threadMap = null;
		if (userThreadLocal.get() == null) {
			FocusLogger.debug("thread name =" + Thread.currentThread().getName() + ":"
					+ Thread.currentThread().getId());
			threadMap = new HashMap();
			userThreadLocal.set(threadMap);
		} else {
			threadMap = (Map) userThreadLocal.get();
		}
		threadMap.put(key, value);
	}

	/**
	 * Get from ThreadLocal.
	 * @param key String
	 * @return String
	 */
	public static String getValue(final String key) {
		Object val = getValueObj(key);
		return val != null ? val.toString() : null;
	}

	/**
	 * Get from ThreadLocal.
	 * @param key String
	 * @return Object
	 */
	public static Object getValueObj(final String key) {
		Object value = null;
		Object threadMap = userThreadLocal.get();
		if (threadMap != null) {
			value = ((Map) threadMap).get(key);
		}
		return value;
	}
}
