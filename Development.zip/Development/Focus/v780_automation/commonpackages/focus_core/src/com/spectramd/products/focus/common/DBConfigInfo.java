/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import java.util.Properties;

/**
 *
 * @author sathyaji.raja
 */
public class DBConfigInfo extends ConfigInfo {
 
    private String driverName;
    private String connectionUrl = "";
    private Properties dBProperties = null;
    
    public void setDBProperties(Properties argProp) {
        
        dBProperties = new Properties();
        
        // Added to support windows authentication mode
        if (argProp.containsKey("user") &&  argProp.containsKey("password") ) {
            dBProperties.put("user", argProp.get("user"));
            dBProperties.put("password", argProp.get("password"));
        }
        
        if (argProp.containsKey("defaultRowPrefetch")) {
            dBProperties.put("defaultRowPrefetch", argProp.get("defaultRowPrefetch"));
        }
        
        if (argProp.containsKey("defaultBatchValue")) {
            dBProperties.put("defaultBatchValue", argProp.get("defaultBatchValue"));
        }
        
        setDriverName((String)argProp.get("jdbcDriverName"));
        setConnectionUrl((String)argProp.get("jdbcURL"));
        
    }
    
    public Properties getDBProperties() {
        return dBProperties;
    }
    
    public String getConnectionUrl()  {
        return connectionUrl;
    }
    
    public void setConnectionUrl(String argConnectionUrl)   {
        connectionUrl = argConnectionUrl;
    }
    
     public String getDriverName()  {
        return driverName;
    }
    
    public void setDriverName(String driverName)   {
        this.driverName = driverName;
    }
}
