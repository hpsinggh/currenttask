/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 *
 * @author sathyaji.raja
 */
public class FocusAccessException extends Exception {   
    
//    public static final String logMsg = "User <Id : %s , Name: %s ,%s > does not have permission "
//                        + "to process this operation ( %s ).";
    
    public FocusAccessException() {
    
    } 
    
    public FocusAccessException(String msg) { 
        super(msg); 
    }
    
    public FocusAccessException(Throwable cause) { 
        super(cause); 
    }
    
    public FocusAccessException(String msg, Throwable cause) { 
        super(msg, cause); 
    }   
    
//    public FocusAccessException(long userId, String lastName, String firstName, CRUDRules operationType) { 
//        super(logMsg.format(logMsg, userId, lastName, firstName, operationType).toString()); 
//    }
}  
