/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.utils.ThreadUtils;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author sathyaji.raja
 */
/******************************************************************************************
*  Change Made: method to get the DBConfig given key from current focus config.
*  Author: Ramya
*  Date of Change: 07/31/2013
******************************************************************************************/
public class FocusConfig {
    
    private static final String ANALYTICS_DS ="analytics_ds";
    private static final String MEASUREVIEW_DS ="measuredef_ds";
    private static final String PORTAL_DS ="portal_ds";
    private static final String ODS_DS ="ods_ds";
    private static final String GLOBAL_DS ="global_ds";
	private static final String AUDIT_DS ="audit_ds";
    
    //private static final String JOB_DS="focusjob_ds";
    private static final String LOGGER ="logger";
    private static final String RESULTS_LOGGER ="ResultsLogger";
    
    private OrderedInsensitiveMap mapConfig = null;
    
    private static Map<String, FocusConfig> mapInstances = new HashMap<String, FocusConfig>();
    
    private Map<String, FocusLogger> mapLoggers = new HashMap<String, FocusLogger>();
    //private FocusLogger logger = null;
    
    //private FocusLogger messageProcesslogger = null;
    
    private FocusConfig(OrderedInsensitiveMap mapConfig) {
        this.mapConfig = mapConfig;
    }
    
    public static void initialize(String clientCode, OrderedInsensitiveMap map) {
        
        String clientCodeUpper = clientCode.toUpperCase();
        
        boolean updateMap = false;
        // if this needs to be reloaded, then check if the map contains reload 
        // key set to 1
        if (!mapInstances.containsKey(clientCodeUpper)) {
            updateMap = true;
        } else {
            if (map.containsKey("RELOAD")) {
                int reload = (Integer)map.get("RELOAD");
                updateMap = reload > 0? true: false;
            }
        }
        
        // refresh or load the map
        if (updateMap) {
            FocusConfig config = new FocusConfig(map);
            mapInstances.put(clientCodeUpper, config);
            //FocusLogger.debug("updating client info in config for " + clientCodeUpper);
            map.displayLog();
        }
    }
    
    public static FocusConfig getInstance(String clientCode) {
        
        //FocusLogger.debug("thread name =" +Thread.currentThread().getName()  + ":" + Thread.currentThread().getId());
        return mapInstances.get(clientCode.toUpperCase());
    }
    
    public String getDataSource() {
        return (String)mapConfig.get(ANALYTICS_DS);
    }
    
    public String getODSDataSource() {
        return (String)mapConfig.get(ODS_DS);
    }
    
    public String getPortalDataSource() {
        return (String)mapConfig.get(PORTAL_DS);
    }
    
    public String getMeasureJobDefDataSource() {
        return (String)mapConfig.get(MEASUREVIEW_DS);
    }
    
    public String getGlobalDataSource() {
        return (String)mapConfig.get(GLOBAL_DS);
    }
    
    public DBConfigInfo getGlobalDataSourceConfig() {
       return (DBConfigInfo)mapConfig.get(GLOBAL_DS);
    }
    
     public DBConfigInfo getMeasureJobDefDataSourceConfig() {
       return (DBConfigInfo)mapConfig.get(MEASUREVIEW_DS);
    }
    
//    public DBConfigInfo getJobDataSource() {
//       return (DBConfigInfo)mapConfig.get(JOB_DS);
//    }
    
    public String getAuditDataSource() {
        return (String)mapConfig.get(AUDIT_DS);
    }
     
     public DBConfigInfo getDataSourceConfig() {
       return (DBConfigInfo)mapConfig.get(ANALYTICS_DS);
    }
    
     public PropertyConfigInfo getPropertyConfig(String property) {
       return (PropertyConfigInfo)mapConfig.get(property.toUpperCase());
    }
    
    public String getLoggerName() {
        String loggerName = "";
        Object loggerValue = mapConfig.get(LOGGER);
        if (loggerValue instanceof LogConfigInfo) {
            loggerName = ((LogConfigInfo)loggerValue).getLoggerName();
        } else {
            loggerName = loggerValue.toString();
        }
        return loggerName;
    }
    
    private String getResultsLoggerName() {
        String loggerName = "";
        Object loggerValue = mapConfig.get(RESULTS_LOGGER);
        if (loggerValue instanceof LogConfigInfo) {
            loggerName = ((LogConfigInfo)loggerValue).getLoggerName();
        } else {
            loggerName = loggerValue.toString();
        }
        return loggerName;
    }
     
    public synchronized FocusLogger getLogger() {
//        if (logger == null) {
//            logger = new FocusLogger(getLoggerName());
//        }
//        return logger;
        return getLoggerInternal(getLoggerName());
    }
    
    private synchronized FocusLogger getLoggerInternal(String loggerName) {
        
        FocusLogger logger = mapLoggers.get(loggerName.toUpperCase());
        if (logger == null) {
            logger = new FocusLogger(loggerName);
            mapLoggers.put(loggerName.toUpperCase(), logger);
        }
        
        return logger;
    }
    
    private synchronized FocusLogger getResultsLogger() {
        return getLoggerInternal(getResultsLoggerName());
    }
    
    public static FocusLogger getCurrentLogger() {
        return getCurrentInstance().getLogger();
    }
    
    public static FocusLogger getCurrentResultsLogger() {
        return getCurrentInstance().getResultsLogger();
    }
    
    public static FocusConfig getCurrentInstance() {
        
        String clientCode = (String)ThreadUtils.getValue("FOCUS_CLIENTID");
        return FocusConfig.getInstance(clientCode);
    }

    public DBConfigInfo getODSDataSourceConfig() {
        return (DBConfigInfo)mapConfig.get(ODS_DS);
    }
    
    //method to get the DBConfig given key from current focus config.
    public DBConfigInfo getDataSourceConfig(String dbConfig) {
        return (DBConfigInfo)mapConfig.get(dbConfig);
    }
}
