/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.spectramd.products.focus.collections;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.apache.commons.collections.MapIterator;
import org.apache.commons.collections.OrderedMap;
import org.apache.commons.collections.OrderedMapIterator;
import org.apache.commons.collections.map.CaseInsensitiveMap;
import org.apache.commons.collections.map.ListOrderedMap;

/**
 *
 * @author sathyaji.raja
 */
public class OrderedInsensitiveMap implements Map { 
 
   // private CaseInsensitiveMap mapInternal = null;
    private OrderedMap map = null;
    
    public OrderedInsensitiveMap() {
        CaseInsensitiveMap mapInternal = new CaseInsensitiveMap();
        map = ListOrderedMap.decorate(mapInternal);
    }
    
    public OrderedInsensitiveMap(Map map) {
        this.map = ListOrderedMap.decorate(new CaseInsensitiveMap(map));
    }
    
    public OrderedMap getMap() {
        return map;
    }

    @Override
    public Object get(Object key) {
        return map.get(key);
    }

    @Override
    public Object put(Object key, Object value) {
        return map.put(key, value);
    }

    @Override
    public boolean containsKey(Object key) {
        return map.containsKey(key);
    }

    @Override
    public Object remove(Object key) {
        return map.remove(key);
    }

    /* Note the need to implement putAll(map) with composition */
    @Override
    public void putAll(Map t) {
        for (Iterator it = t.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            put(entry.getKey(), entry.getValue());
        }
    }

    // --------------------------------------
    // The rest of these are just the standard cruft of composition:
    // --------------------------------------
    @Override
    public void clear() {
        map.clear();
    }

    @Override
    public boolean containsValue(Object value) {
        return map.containsValue(value);
    }

    @Override
    public Set entrySet() {
        return map.entrySet();
    }

    @Override
    public boolean isEmpty() {
        return map.isEmpty();
    }

    @Override
    public Set keySet() {
        return map.keySet();
    }

    @Override
    public int size() {
        return map.size();
    }

    @Override
    public Collection values() {
        return map.values();
        
    }
      
    public MapIterator getMapIterator() {
        return map.mapIterator();
    }
    
    public OrderedMapIterator getOrderedMapIterator() {
        return map.orderedMapIterator();
    }
    
    public List<Long> getSortedIndexBasedonLongKeys()    {
        
        //List<Integer> temp = new ArrayList();
        List<Long> values = new ArrayList();
        
        // get the list of keys
        int index = 0;
        for (Iterator it = this.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            
            long key = Long.parseLong(entry.getKey().toString());
            int indexToInsert = getIndexToInsert(values, key);
			if (indexToInsert > values.size()) {
                values.add(key);
			} else {
                values.add(indexToInsert, key);
			}
            
            //temp.add(indexToInsert);
            
            index++;
        }
        
        
        return values;
    }
    
    private int getIndexToInsert(List<Long> valueList, long key) {
        
        int indexToInsert =0;
        
        int index = 0;
        for (Long value : valueList )   {
            if (key < value) {
                //indexToInsert = index;
                break;
            }
            index++;
            indexToInsert = index;
        }
        
        return indexToInsert;
    }
    
    public String getKeyFromIndex(int indexForKey)   {
     
        String keyForIndex = "";
        
        int index = 0;
        for (Iterator it = this.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            if (indexForKey == index)   {
                keyForIndex = entry.getKey().toString();
                break;
            }
            index++;
        }
        
        return keyForIndex;
    }
    
    public void replaceMap(OrderedInsensitiveMap inputMap) {
        
        CaseInsensitiveMap mapInternal = new CaseInsensitiveMap();
        map = ListOrderedMap.decorate(mapInternal);
        
        for (Iterator it = inputMap.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            
            put(entry.getKey(), entry.getValue());
        }
        
    }
    
    public void displayLog() {
        
        for (Iterator it = this.entrySet().iterator(); it.hasNext();) {
            Map.Entry entry = (Map.Entry) it.next();
            Object value = entry.getKey();
            //FocusConfig.getCurrentLogger().writeDebug("entry key is "+ (value == null? "null": value.toString()));
			System.out.println(" key = " + (entry.getKey() == null ? "" : entry.getKey()) + ", value ="
					+ (entry.getValue() == null ? "" : entry.getValue().toString()));
        }
    }
    
    public static void sort(OrderedInsensitiveMap mapToSort, List<Comparator> listComparators) {
        
        List<String> sortedKeys = new ArrayList<String>();
        List<Object> sortedObjects = new ArrayList();
        
        // enumerate through the map get the sorted keys and sorted values
        MapIterator itrMap = mapToSort.getMapIterator();
        while (itrMap.hasNext()) {
            Object key = itrMap.next();
            Object Value = itrMap.getValue();
            
            sortKeys(key.toString(), Value, sortedKeys, sortedObjects, mapToSort, listComparators);
        }
        
        // clear the given map and add the values from the sorted collection
        mapToSort.clear();
        for (int index=0; index < sortedKeys.size(); index++) {
            mapToSort.put(sortedKeys.get(index), sortedObjects.get(index));
        }
        
    }
    
    private static void sortKeys(String currentKey, Object currentValue, 
                                    List<String> sortedKeys, List<Object> sortedObjects,
                                    OrderedInsensitiveMap mapToSort, List<Comparator> listComparators) {
        
        int indexToInsert = 0;
        int currentIndex = 0;
        for (String sortedKey : sortedKeys) {
            
            boolean continueSorting = true;
            for (Comparator instance: listComparators) {
                int comparisonValue = instance.compare(currentValue, mapToSort.get(sortedKey));
                
                // continue to the next comparator if the value is zero
				if (comparisonValue == 0) {
                    continue;
				}
                
                if (comparisonValue < 0) {
                    indexToInsert = currentIndex;
                    continueSorting = false;
                    break;
                }
            }
            
            // break the loop if the index to insert has been found
			if (!continueSorting) {
                break;
			}
            
            currentIndex++;
            indexToInsert++;
        }
        
        // add to the list collection at the correct index
        //System.out.println("inserting " + currentKey + " at index =" + indexToInsert);
        sortedKeys.add(indexToInsert, currentKey);
        sortedObjects.add(indexToInsert, currentValue);
    }

    public void reOrder(OrderedInsensitiveMap primaryOrder) {
        
        // enumerate through the map get the key, values in a temp map
        HashMap tempMap = new HashMap();
        MapIterator itrMap = getMapIterator();
        while (itrMap.hasNext()) {
            Object key = itrMap.next();
            Object Value = itrMap.getValue();
            
            tempMap.put(key, Value);
        }
        
        // clear the map
        clear();
        
        // add the keys based on the given order
        itrMap = primaryOrder.getMapIterator();
        while (itrMap.hasNext()) {
            Object key = itrMap.next();
            
            put(key, tempMap.get(key));
            // System.out.println("adding keys in sorted order " + key + ", value=" + tempMap.get(key));
        }
    }
}
