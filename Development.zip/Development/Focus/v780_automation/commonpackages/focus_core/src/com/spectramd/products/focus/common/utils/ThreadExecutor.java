/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.common.FocusAppInitializer;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author sathyaji.raja
 */
public class ThreadExecutor implements FocusAppInitializer {
    private static ThreadExecutor manager = new ThreadExecutor();
    private ExecutorService service = null;
    
    private ThreadExecutor() {
        service = Executors.newFixedThreadPool(10);
    }
    
    public static ThreadExecutor getInstance() {
        return manager;
    }
    
    public void UnInitialize() {
        
    }
    
    
    public void execute(Runnable runInstance) {
        service.submit(runInstance);
    }

    @Override
    public void Initialize(Object argument) {
        // don't do anything
    }

    @Override
    public void UnIntialize() {
        try {
            // when no more to submit, call shutdown
            service.shutdown();
        
            // now wait for the jobs to finish
            service.awaitTermination(10, TimeUnit.MINUTES);
            
        } catch (Exception ex) {
            
        }
    }
}
