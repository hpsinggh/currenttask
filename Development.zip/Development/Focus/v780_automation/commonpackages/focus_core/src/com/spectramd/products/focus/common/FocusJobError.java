/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 * 
 * @author pratapkonakala
 */
public class FocusJobError extends Exception {   
    
    public FocusJobError() {
    
    } 
    
    public FocusJobError(String msg) { 
        super(msg); 
    }
    
    public FocusJobError(Throwable cause) { 
        super(cause); 
    }
    
    public FocusJobError(String msg, Throwable cause) { 
        super(msg, cause); 
    }   
}  
