/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 *
 * @author sathyaji.raja
 */
public class FocusException extends Exception {   
    
    public FocusException() {
    
    } 
    
    public FocusException(String msg) { 
        super(msg); 
    }
    
    public FocusException(Throwable cause) { 
        super(cause); 
    }
    
    public FocusException(String msg, Throwable cause) { 
        super(msg, cause); 
    }   
}  
