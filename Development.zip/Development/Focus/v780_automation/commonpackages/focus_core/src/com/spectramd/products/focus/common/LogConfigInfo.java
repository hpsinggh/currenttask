/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 *
 * @author sathyaji.raja
 */
public class LogConfigInfo  extends ConfigInfo  {
   
    private String logFile = "focus_log.xml";
    private String loggerName = "focuslogger";
    
    private long logFileWatchInterval = 60000; //  1 minute
    
    public LogConfigInfo()  {
        
    }
    
    public String getLogFile() {
        return logFile;
    }
    
    public void setLogFile(String appLogFile)  {
        logFile = appLogFile;
    }
    
    public String getLoggerName() {
        return loggerName;
    }
    
    public void setLoggerName(String appLogger) {
        loggerName = appLogger;
    }
    
    public long getLogFileWatchInterval()   {
        return logFileWatchInterval;
    }

}
