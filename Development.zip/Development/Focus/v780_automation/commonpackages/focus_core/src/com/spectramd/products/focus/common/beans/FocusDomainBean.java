/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.beans;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ramya.khasnis
 */
public abstract class FocusDomainBean implements Serializable {
    private List<FocusUpdateAction> focusUpdateActionList = new ArrayList<FocusUpdateAction>();
    private String logicalElement;
    private String id;

    
    
    public FocusDomainBean() {
        
    }
    
    
    @Override
    public abstract FocusDomainBean clone();
    
    protected void cloneInternal(FocusDomainBean focusDomainBean){
        
        focusDomainBean.logicalElement = logicalElement;
        focusDomainBean.id = id;
        
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    public FocusDomainBean(String logicalElement) {
        this.logicalElement = logicalElement;
    }
    
    public List<FocusDomainBean> getFocusDomainBeans(){
        //do nothing...
        return null;
    }
    
    public FocusDomainBean(FocusDomainBean domainBean) {
        this.focusUpdateActionList.addAll(domainBean.getFocusUpdateActionList());
    }
    
    /**
     * @return the focusUpdateActionList
     */
    public List<FocusUpdateAction> getFocusUpdateActionList() {
        return focusUpdateActionList;
    }

    /**
     * @param focusUpdateActionList the focusUpdateActionList to set
     */
    public void setFocusUpdateActionList(List<FocusUpdateAction> focusUpdateActionList) {
        this.focusUpdateActionList = focusUpdateActionList;
    }
    
    public void addFocusUpdateAction(FocusUpdateAction focusUpdateAction){
        focusUpdateActionList.add(focusUpdateAction);
    }

    public String getLogicalElement() {
        return logicalElement;
    }

    public void setLogicalElement(String logicalElement) {
        this.logicalElement = logicalElement;
    }
    
}
