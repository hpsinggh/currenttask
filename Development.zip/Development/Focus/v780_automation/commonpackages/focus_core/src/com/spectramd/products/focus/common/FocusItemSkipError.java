/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 * 
 * @author pratapkonakala
 */
public class FocusItemSkipError extends Exception {   
    
    private String errorSource;
    private Long errorId;

    public Long getErrorId() {
        return errorId;
    }

    public void setErrorId(Long errorId) {
        this.errorId = errorId;
    }

    public String getErrorSource() {
        return errorSource;
    }

    public void setErrorSource(String errorSource) {
        this.errorSource = errorSource;
    }
    
    public FocusItemSkipError() {
    
    } 
    
    public FocusItemSkipError(String errSource,Long errId,Throwable throwable){
        super(throwable);
        this.errorSource = errSource;
        this.errorId = errId;
    }
    
    public FocusItemSkipError(String msg) { 
        super(msg); 
    }
    
    public FocusItemSkipError(Throwable cause) { 
        super(cause); 
    }
    
    public FocusItemSkipError(String msg, Throwable cause) { 
        super(msg, cause); 
    }   
}  
