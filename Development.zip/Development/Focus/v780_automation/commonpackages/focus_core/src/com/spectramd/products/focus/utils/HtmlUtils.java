/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import org.apache.commons.lang.text.StrBuilder;

/**
 *
 * @author sathyaji.raja
 */
public final class HtmlUtils {

    private HtmlUtils() {
        
    }
    
    public static String wrap(String textToWrap, int length) {
        StrBuilder temp = new StrBuilder();
        
        if (textToWrap.length() > length) {
            
            int index = -1;
            int lastIndex = -1;
            do {
                index=textToWrap.indexOf(" ", index+1);
                //System.out.println("current index =" + index);
                if (index > length || index == -1) {
                    break;
                } else
                    lastIndex=index;
            } while (index != -1);
            
            if (lastIndex != -1) {
                temp.append(textToWrap.substring(0, lastIndex) );
                temp.append("<br/>");
                temp.append(textToWrap.substring(lastIndex));
            } else
                return textToWrap;
            
        } else 
            return textToWrap;
        
        return temp.toString();
    }
    
    
    public static String encode(String string) {
	  
        StringBuilder sb = new StringBuilder(string.length());
	    int len = string.length();
	    char c;

        for (int i = 0; i < len; i++) {
            c = string.charAt(i);

        // HTML Special Chars
        if (c == '"')
            sb.append("&quot;");
        else if (c == '&')
            sb.append("&amp;");
        else if (c == '<')
            sb.append("&lt;");
        else if (c == '>')
            sb.append("&gt;");
        else if (c == '\n')
            // Handle Newline
            sb.append("&lt;br/&gt;");
        else {
            int ci = 0xffff & c;
            if (ci < 160 )
                // nothing special only 7 Bit
                sb.append(c);
            else {
                // Not 7 Bit use the unicode system
                sb.append("&#");
                sb.append(Integer.toString(ci));
                sb.append(';');
                }
            }
        }
	return sb.toString();
    }
    
    /**
     * To eliminate the Junk characters with the HTML key strokes in a given string.
     * @param s
     * @return String
     */
    public static String escapeHTML(String s){
           StringBuilder sb = new StringBuilder();
           int n = s.length();
           for (int i = 0; i < n; i++) {
              char c = s.charAt(i);
              switch (c) {
                 case '<': sb.append("&lt;"); break;
                 case '>': sb.append("&gt;"); break;
                 case '&': sb.append("&amp;"); break;
                 case '"': sb.append("&quot;"); break;
                 case 'à': sb.append("&agrave;");break;
                 case 'À': sb.append("&Agrave;");break;
                 case 'â': sb.append("&acirc;");break;
                 case 'Â': sb.append("&Acirc;");break;
                 case 'ä': sb.append("&auml;");break;
                 case 'Ä': sb.append("&Auml;");break;
                 case 'å': sb.append("&aring;");break;
                 case 'Å': sb.append("&Aring;");break;
                 case 'æ': sb.append("&aelig;");break;
                 case 'Æ': sb.append("&AElig;");break;
                 case 'ç': sb.append("&ccedil;");break;
                 case 'Ç': sb.append("&Ccedil;");break;
                 case 'é': sb.append("&eacute;");break;
                 case 'É': sb.append("&Eacute;");break;
                 case 'è': sb.append("&egrave;");break;
                 case 'È': sb.append("&Egrave;");break;
                 case 'ê': sb.append("&ecirc;");break;
                 case 'Ê': sb.append("&Ecirc;");break;
                 case 'ë': sb.append("&euml;");break;
                 case 'Ë': sb.append("&Euml;");break;
                 case 'ï': sb.append("&iuml;");break;
                 case 'Ï': sb.append("&Iuml;");break;
                 case 'ô': sb.append("&ocirc;");break;
                 case 'Ô': sb.append("&Ocirc;");break;
                 case 'ö': sb.append("&ouml;");break;
                 case 'Ö': sb.append("&Ouml;");break;
                 case 'ø': sb.append("&oslash;");break;
                 case 'Ø': sb.append("&Oslash;");break;
                 case 'ß': sb.append("&szlig;");break;
                 case 'ù': sb.append("&ugrave;");break;
                 case 'Ù': sb.append("&Ugrave;");break;        
                 case 'û': sb.append("&ucirc;");break;        
                 case 'Û': sb.append("&Ucirc;");break;
                 case 'ü': sb.append("&uuml;");break;
                 case 'Ü': sb.append("&Uuml;");break;
                 case '®': sb.append("&reg;");break;        
                 case '©': sb.append("&copy;");break;  
                 case '€': sb.append("&euro;"); break;
                 // be carefull with this one (non-breaking whitee space)
                case ' ': sb.append("&nbsp;");break;        
                
                 default:  sb.append(c); break;
              }
           }
           return escapeSpecialCharacters(sb.toString());
        }
    
    /**
     * To replace the HTML key strokes with the actual values.
     * @param s
     * @return String
     */
    public static String escapeSpecialCharacters(String s){
       
        //&#34; or &quot;    -  " or "
       
       
        s = s.replaceAll("&#34;", ""+'"');
        s = s.replaceAll("&quot;", ""+'"');
       
       
        //&#8220;  - “
       
        s = s.replaceAll("&#8220;", "“");
        //&#8221; - ”
        s = s.replaceAll("&#8221;", "”");

        //&#38; or &amp;     -    & or &

        s = s.replaceAll("&#38;", "&");
        s = s.replaceAll("&amp;", "&");


        //&#32;             -    Space

        s = s.replaceAll("&#32;", " ");

        //&#33;            -    !

        s = s.replaceAll("&#33;", "!");

        //&#35;            -    #

        s = s.replaceAll("&#35;", "#");

        //&#36;            -    $

        s = s.replaceAll("&#36;", "$");

        //&#37;            -    %

        s = s.replaceAll("&#37;", "%");

        //&#39;            -    Apostrophe '

        s = s.replaceAll("&#39;", "'");

        //&#40;    Left parenthesis    (

        //s = s.replaceAll("&#40;", "(");

        //&#41;    Right parenthesis    )

        s = s.replaceAll("&#41;", ")");

        //&#42;    Asterisk    *

        s = s.replaceAll("&#42;", "*");


        //&#43;    Plus sign    +

        s = s.replaceAll("&#43;", "+");

        //&#44;    Comma    ,

        s = s.replaceAll("&#44;", ",");

        //&#45;    Hyphen    -

        s = s.replaceAll("&#45;", "-");

        //&#46;    Period (fullstop)    .

        s = s.replaceAll("&#46;", ".");

        //&#47;    Solidus (slash)    /

        s = s.replaceAll("&#47;", "/");


        //&#58;    Colon    :

        s = s.replaceAll("&#58;", ":");

        //&#59;    Semi-colon    ;

        s = s.replaceAll("&#59;", ";");


        //&#60; or &lt;    Less than    < or <

        s = s.replaceAll("&#60;", "<");


        //&#61;    Equals sign    =

        s = s.replaceAll("&#61;", "=");

        //&#62; or &gt;    Greater than    > or >

        s = s.replaceAll("&#62;", ">");



        //&#63;    Question mark    ?

        s = s.replaceAll("&#63;", "?");

        //&#64;    Commercial at    @

        s = s.replaceAll("&#64;", "@");

        //&#91;    Left square bracket    [

        s = s.replaceAll("&#91;", "[");


        //&#92;    Reverse solidus (backslash)    \

        //s = s.replaceAll("&#92;", "\");

        //&#93;    Right square bracket    ]

        s = s.replaceAll("&#93;", "]");

        //&#94;    Caret    ^

        s = s.replaceAll("&#94;", "^");

        //&#95;    Horizontal bar (underscore)    _

        s = s.replaceAll("&#95;", "_");


        //&#96;    Acute accent    `

        s = s.replaceAll("&#96;", "`");


        //&#123;    Left curly brace    {

        s = s.replaceAll("&#123;", "{");

        //&#124;    Vertical bar    |

        s = s.replaceAll("&#124;", "|");



        //&#125;    Right curly brace    }


        s = s.replaceAll("&#125;", "}");

        //&#126;    Tilde    ~


        s = s.replaceAll("&#126;", "~");


        //&#146 is non-standard! use &#8217; instead!

        s = s.replaceAll("&#146;", "'");
        s = s.replaceAll("&#8217;", "'");

        //&endash; or &#150; are non-standard! use &#8211; instead!  –
        s = s.replaceAll("&endash;", "–");
        s = s.replaceAll("&#150;", "–");
        s = s.replaceAll("&#8211;", "–");


        //&emdash; or &#151; are non-standard! use &#8212; instead!

        s = s.replaceAll("&#151;", "–");
        s = s.replaceAll("&emdash;", "–");
        s = s.replaceAll("&#8212;", "–");


        //&#160; or &nbsp;    no-break space = non-breaking space      or 

        s = s.replaceAll("&#160;", " ");
        s = s.replaceAll("&nbsp;", " ");

        //&#161; or &iexcl;    inverted exclamation mark    ¡ or ¡

        s = s.replaceAll("&#161;", "i");
        s = s.replaceAll("&iexcl;", "i");


        //&#162; or &cent;    Cent sign    ¢ or ¢

        s = s.replaceAll("&#162;", "¢");
        s = s.replaceAll("&cent;", "¢");

        //&#163; or &pound;    Pound sterling    £ or £

        s = s.replaceAll("&#163;", "£");
        s = s.replaceAll("&pound;", "£");

        //&#164; or &curren;    General currency sign    ¤ or ¤

        s = s.replaceAll("&#164;", "¤");
        s = s.replaceAll("&curren;", "¤");



        //&#165; or &yen;    yen sign = yuan sign    ¥ or ¥

        s = s.replaceAll("&#165;", "¥");
        s = s.replaceAll("&yen;", "¥");


        //&#166; or &brvbar;    pipe or broken bar = broken vertical bar    ¦ or ¦

        s = s.replaceAll("&#166;", "¦");
        s = s.replaceAll("&#166;", "¦");

        //&#167; or &sect;    Section sign    § or §

        s = s.replaceAll("&#167;", "§");
        s = s.replaceAll("&sect;", "§");


        //&#168; or &uml;    diaeresis = spacing diaeresis    ¨ or ¨

        s = s.replaceAll("&#168;", "¨");
        s = s.replaceAll("&uml;", "¨");

        //&#169; or &copy;    copyright sign    © or ©

        s = s.replaceAll("&#169;", "©");
        s = s.replaceAll("&copy;", "©");

        //&#170; or &ordf;    feminine ordinal indicator    ª or ª

        s = s.replaceAll("&#170;", "ª");
        s = s.replaceAll("&ordf;", "ª");


        //&#171; or &laquo;    left-pointing double angle quotation mark = left pointing guillemet    « or «

        s = s.replaceAll("&#171;", "«");
        s = s.replaceAll("&laquo;", "«");
       
        //http://tntluoma.com/sidebars/codes/
       
       
        //&#153;  -  ™
        s = s.replaceAll("&#153;", "™");
       
       
//        &#172; or &not;    not sign    ¬ or ¬
        s = s.replaceAll("&#172;", "¬");
        s = s.replaceAll("&not;", "¬");

//            &#173; or &shy;    soft hyphen = discretionary hyphen    ­ or ­

        s = s.replaceAll("&#173;", "-");
        s = s.replaceAll("&shy;", "-");

        //&#174; or &reg;    registered sign = registered trade mark sign    ® or ®

        s = s.replaceAll("&#174;", "®");
        s = s.replaceAll("&reg;", "®");


        //&#175; or &macr;    macron = spacing macron = overline = APL overbar    ¯ or ¯

        s = s.replaceAll("&#175;", "¯");
        s = s.replaceAll("&macr;", "¯");



        //&#176; or &deg;    degree sign    ° or °

        s = s.replaceAll("&#176;", "°");
        s = s.replaceAll("&deg;", "°");


        //&#177; or &plusmn;    plus-minus sign = plus-or-minus sign    ± or ±

        s = s.replaceAll("&#177;", "±");
        s = s.replaceAll("&plusmn;", "±");


        //&#178; or &sup2;    superscript two = superscript digit two = squared    ² or ²

        s = s.replaceAll("&#178;", "²");
        s = s.replaceAll("&sup2;", "²");



        //&#179; or &sup3;    superscript three = superscript digit three = cubed    ³ or ³

        s = s.replaceAll("&#179;", "³");
        s = s.replaceAll("&sup3;", "³");



        //&#180; or &acute;    acute accent = spacing acute    ´ or ´

        s = s.replaceAll("&#180;", "´");
        s = s.replaceAll("&acute;", "´");


        //&#181; or &micro;    micro sign    µ or µ

        s = s.replaceAll("&#181;", "µ");
        s = s.replaceAll("&micro;", "µ");

        //&#182; or &para;    pilcrow sign = paragraph sign    ¶ or ¶

        s = s.replaceAll("&#182;", "¶");
        s = s.replaceAll("&para;", "¶");



        //&#183; or &middot;    middle dot = Georgian comma = Greek middle dot    · or ·

        s = s.replaceAll("&#183;", "·");
        s = s.replaceAll("&middot;", "·");



        //&#184; or &cedil;    cedilla = spacing cedilla    ¸ or ¸

        s = s.replaceAll("&#184;", "¸");
        s = s.replaceAll("&cedil;", "¸");



        //&#185; or &sup1;    superscript one = superscript digit one    ¹ or ¹

        s = s.replaceAll("&#185;", "¹");
        s = s.replaceAll("&sup1;", "¹");

        //&#186; or &ordm;    masculine ordinal indicator    º or º

        s = s.replaceAll("&#186;", "º");
        s = s.replaceAll("&ordm;", "º");


        //&#187; or &raquo;    right-pointing double angle quotation mark = right pointing guillemet    » or »

        s = s.replaceAll("&#187;", "»");
        s = s.replaceAll("&raquo;", "»");


        //&#188; or &frac14;    vulgar fraction one quarter = fraction one quarter    ¼ or ¼

        s = s.replaceAll("&#188;", "¼");
        s = s.replaceAll("&frac14;", "¼");
       
        s = s.replaceAll("¼", "");
        // To Releace HTML Tags
        s = s.replaceAll("\\<.*?>","");
        //s = s.replaceAll("\\<.*?\\>","");
        //s = s.replaceAll("\\&#??[0-9]{0,5}?\\;"," ");
       
        return s.toString();
    }
}
