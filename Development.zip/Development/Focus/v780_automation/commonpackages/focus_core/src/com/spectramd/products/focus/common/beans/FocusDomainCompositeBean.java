/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.beans;

import java.util.ArrayList;
import java.util.List;

/**
 * @author siraj.moghal
 */
public class FocusDomainCompositeBean extends FocusDomainBean {
    
    private List<FocusDomainBean> focusDomainBeans = new ArrayList<FocusDomainBean>();

    @Override
    public List<FocusDomainBean> getFocusDomainBeans() {
        return focusDomainBeans;
    }

    public void setFocusDomainBeans(List<FocusDomainBean> focusDomainBeans) {
        this.focusDomainBeans = focusDomainBeans;
    }

    @Override
    public FocusDomainBean clone() {
    
        FocusDomainCompositeBean focusDomainCompositeBean = new FocusDomainCompositeBean();
        for (FocusDomainBean focusDomainBean: focusDomainBeans) {
            focusDomainCompositeBean.focusDomainBeans.add(focusDomainBean.clone());
        }
        return focusDomainCompositeBean;
    }
}
