/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.beans;

/**
 *
 * @author ramya.khasnis
 */
public enum FocusUpdateAction {
    DISCHARGEINFO, LOCATION, PATIENT, VISITINFO, CHIEFCOMPLAINT
}
