/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 *
 * @author sathyaji.raja
 */
public final class FocusDefaultLogInitializer implements FocusAppInitializer {
    
    @Override
    public void Initialize(Object argument) {
        
        LogConfigInfo logConfig = new LogConfigInfo();
        logConfig.setLogFile("focus_log.xml");
        logConfig.setLoggerName("focuslogger");
        FocusLogger.Initialize(logConfig);
    }

    @Override
    public void UnIntialize() {
        
    }
}
