/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 *
 * @author sathyaji.raja
 */
public interface FocusAppInitializer {
    
    void Initialize(Object argument);
    void UnIntialize();
}
