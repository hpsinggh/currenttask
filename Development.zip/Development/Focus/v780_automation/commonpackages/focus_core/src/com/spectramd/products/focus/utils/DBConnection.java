/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import com.spectramd.products.focus.common.DBConfigInfo;
import java.sql.Connection;
import java.sql.SQLException;

/**
 *
 * @author sathyaji.raja
 */
public class DBConnection {
    

    public static Connection getConnection(DBConfigInfo config) 
                                    throws ClassNotFoundException, SQLException {
        return DBUtil.getConnection(config.getDriverName(), 
                        config.getConnectionUrl(), config.getDBProperties());
    }
}
