/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import com.spectramd.products.focus.utils.DBUtil;
import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.NamingException;
import javax.sql.DataSource;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

/**
 *
 * @author sathyaji.raja
 */
public class FocusResource {
    
    private FocusResource() {
        
    }
    
    private static Connection getConnection(String dataSource) throws ClassNotFoundException, 
                                                        NamingException, SQLException {
        Connection con = DBUtil.getConnection(dataSource);
        con.setAutoCommit(false); 
        con.setTransactionIsolation(Connection.TRANSACTION_NONE);
        return con;
    }
    
//    public static Connection getDefaultConnection() throws ClassNotFoundException, 
//                                                        NamingException, SQLException {
//        
//        // Declare the JDBC objects.
//	return getConnection("focus310");
//        //return getConnection("focus303");
//        
//    }
    
    public static Connection getPortalConnection() throws ClassNotFoundException, 
                                                        NamingException, SQLException {
        
        // Declare the JDBC objects.
	String portalSource = FocusConfig.getCurrentInstance().getPortalDataSource();
        return getConnection(portalSource);
        
    }
    
    public static Connection getAnalyticsConnection() throws ClassNotFoundException, 
                                                        NamingException, SQLException {
        
        // Declare the JDBC objects.
	String analyticsSource = FocusConfig.getCurrentInstance().getDataSource();
        FocusConfig.getCurrentLogger().writeDebug("Analytics ds =" + analyticsSource);
        return getConnection(analyticsSource);
    }
    
    public static Connection getAuditConnection() throws ClassNotFoundException, 
                                                        NamingException, SQLException {

        // Declare the JDBC objects.
		String auditSource = FocusConfig.getCurrentInstance().getAuditDataSource();
        FocusConfig.getCurrentLogger().writeDebug("Audit ds =" + auditSource);
        return getConnection(auditSource);
    }
    
     public static Connection getMeasureJobDefConnection() throws ClassNotFoundException, 
                                                        NamingException, SQLException {
        
        // Declare the JDBC objects.
	String measureViewSource = FocusConfig.getCurrentInstance().getMeasureJobDefDataSource();
        return getConnection(measureViewSource);
    }
     /**
      * This method is used to created DataSource
      * @return DataSource
      */
     public static DataSource getAnalyticsDataSource(){
         //getting DBConfigInfo object
         DBConfigInfo DATA_SOURCE_CONFIG = FocusConfig.getCurrentInstance().getDataSourceConfig();
         //Creating dataSource object
         DriverManagerDataSource dataSource = new DriverManagerDataSource();
         //setting driverName,url,UserName and password
         dataSource.setDriverClassName(DATA_SOURCE_CONFIG.getDriverName());
         dataSource.setUrl(DATA_SOURCE_CONFIG.getConnectionUrl());
         dataSource.setUsername(DATA_SOURCE_CONFIG.getDBProperties().getProperty("user"));
         dataSource.setPassword(DATA_SOURCE_CONFIG.getDBProperties().getProperty("password"));
         return dataSource;
     }
}
