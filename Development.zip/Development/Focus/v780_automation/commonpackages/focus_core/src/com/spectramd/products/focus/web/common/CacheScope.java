package com.spectramd.products.focus.web.common;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sathyaji.raja
 */
public enum CacheScope { NONE, APPLICATION, SESSION, REQUEST };
