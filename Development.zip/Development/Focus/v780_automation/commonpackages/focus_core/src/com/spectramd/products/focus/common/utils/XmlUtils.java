/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.utils.StringUtils;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.stream.XMLEventFactory;
import javax.xml.stream.XMLEventWriter;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.events.EndDocument;
import javax.xml.stream.events.EndElement;
import javax.xml.stream.events.StartElement;
import javax.xml.stream.events.XMLEvent;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.apache.commons.lang.StringEscapeUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;

/**
 *
 * @author sathyaji.raja
 */
public class XmlUtils {
    
     private static final String EMPTY = "";
    
    public static Document getXmlDocument(String xmlFilename) 
                                throws ParserConfigurationException, SAXException, IOException 
    {
       
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            factory.setIgnoringComments(true);
        
            DocumentBuilder dom = factory.newDocumentBuilder();
            File xmlFile = new File(xmlFilename);
            Document document = dom.parse(xmlFile);
            return document;
       
    }
    
     /**
     * This method is used to handle special characters.
     * @param value the string to escape characters
     * @return String
     */
    public static String escapeXml(String value){
        String attrValue = "";
        if (StringUtils.notEmpty(value)){
            attrValue = StringEscapeUtils.escapeXml(value);
        }
        return attrValue;
    }
    
     /**
     * Returns the node's attribute value if no value return null
     *
     * @param node
     * @param attributeName
     * @return node value
     */
    public static String getAttributeValue(Attributes attributes, String attributeName) {
        if (attributes.getValue(attributeName) != null) {
            return attributes.getValue(attributeName);
        }
        return "";
    }

    /**
     * This method is used to print all child names.
     *
     * @param nodeList
     */
    public static void printNonParsingTags(NodeList nodeList) throws TransformerException {
        for (int pdIndex = 0; pdIndex < nodeList.getLength(); pdIndex++) {
            Node notParsingNode = nodeList.item(pdIndex);
            printNonParsingTag(notParsingNode.getNodeName());
            FocusConfig.getCurrentLogger().writeDebug(XmlUtils.convertNodeToHtml(notParsingNode));
        }
    }

    /**
     * This method is used to print Unparsed node name.
     *
     * @param notParsingNodeName
     */
    public static void printNonParsingTag(String notParsingNodeName) {
        List<String> unparsedNodeNames = new ArrayList<String>();
        unparsedNodeNames.add("#text");
        unparsedNodeNames.add("text");
        unparsedNodeNames.add("name");
        unparsedNodeNames.add("id");
        unparsedNodeNames.add("templateId");
        unparsedNodeNames.add("reference");

        if (!unparsedNodeNames.contains(notParsingNodeName)) {
            FocusConfig.getCurrentLogger().writeDebug("Not Parsing tags: " + notParsingNodeName);
        }

    }
    
    /**
     * 
     * @param node
     * @return Stirng
     * @throws TransformerException 
     */
    public static String convertNodeToHtml(Node node) throws TransformerException {
        Transformer t = TransformerFactory.newInstance().newTransformer();
        t.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
        StringWriter sw = new StringWriter();
        t.transform(new DOMSource(node), new StreamResult(sw));
        return sw.toString();
    }
    
   

    public static byte[] createXMLString(List<OrderedInsensitiveMap> listResults,
            String rootElement, String childElement) throws Exception {
        byte[] xmlBytes = null;
        XMLOutputFactory factory = XMLOutputFactory.newInstance();
        XMLEventFactory eventFactory = XMLEventFactory.newInstance();
        XMLEventWriter writer = null;
        ByteArrayOutputStream bos = null;

        try {
            bos = new ByteArrayOutputStream();
            writer = factory.createXMLEventWriter(bos);

            XMLEvent event = eventFactory.createStartDocument("UTF-8", "1.0");
            writer.add(event);
            //writer.add(eventFactory.createAttribute("timestamp",String.valueOf(Calendar.getInstance().getTime())));
            
            StartElement startElement = eventFactory.createStartElement(EMPTY, EMPTY, rootElement);
            writer.add(startElement);
            writer.add(eventFactory.createAttribute("timestamp",String.valueOf(new Date().getTime())));
            writer.add(eventFactory.createAttribute("version","1.0"));
            
            for (OrderedInsensitiveMap map : listResults) {
                event = eventFactory.createStartElement(EMPTY, EMPTY, childElement);
                writer.add(event);

                for (Object key : map.keySet()) {
                    
                    if(key != null) {
                        Object mapValue = map.get(key);
                        //System.out.println("Map key " + key+", Value is " + mapValue);
                        if (mapValue instanceof OrderedInsensitiveMap) {
                            OrderedInsensitiveMap data = (OrderedInsensitiveMap) mapValue;
                            writer.add(eventFactory.createStartElement(EMPTY, EMPTY, key.toString()));
                            for (Object subKey : data.keySet()) {
                                writeAttribute(writer, eventFactory, subKey, data.get(subKey));
                            }
                            writer.add(eventFactory.createEndElement(EMPTY, EMPTY, key.toString()));
                        } else if (mapValue instanceof Map) {
                            Map data = (Map) mapValue;
                            writer.add(eventFactory.createStartElement(EMPTY, EMPTY, key.toString()));
                            for (Object subKey : data.keySet()) {
                                writeAttribute(writer, eventFactory, subKey, data.get(subKey));
                            }
                            writer.add(eventFactory.createEndElement(EMPTY, EMPTY, key.toString()));
                        } else if ((mapValue instanceof List)) {
                              List dimensionList = (List)mapValue;
                              for (Map dimensionMap : (List<Map>)dimensionList) {
                                writer.add(eventFactory.createStartElement("", "", key.toString()));

                                for (Object subKey : dimensionMap.keySet()) {
                                    writeAttribute(writer, eventFactory, subKey, dimensionMap.get(subKey));
                                }   

                                writer.add(eventFactory.createEndElement("", "", key.toString()));
                              }
                        } else {
                            //writer.add(eventFactory.createAttribute(String.valueOf(key), String.valueOf(map.get(key)) ));
                            writeAttribute(writer, eventFactory, key, map.get(key) );
                        }
                    
                    }
                }

                EndElement providerEndElement = eventFactory.createEndElement(EMPTY, EMPTY, childElement);
                writer.add(providerEndElement);
            }
            
            EndDocument endDocument = eventFactory.createEndDocument();
            writer.add(endDocument);
            writer.flush();
            xmlBytes = bos.toByteArray();
        } finally {
            if (writer != null) {
                writer.close();
            }
            if (bos != null) {
                bos.close();
            }
        }
        return xmlBytes;
    }


    private static void writeAttribute(XMLEventWriter writer, XMLEventFactory eventFactory, 
                                                            Object key, Object value) throws XMLStreamException {
        if (key != null) {
            
            if (value != null) {
                String stringValue = value.toString();
                if (stringValue.length() > 0) {
                    //Ramya -07/31 - the xml attribute key is always lower case
                    //writer.add(eventFactory.createAttribute(key.toString().toLowerCase(),  stringValue));
                    writer.add(eventFactory.createAttribute(key.toString(),  stringValue));
                } else {
                    //writer.add(eventFactory.createAttribute(key.toString().toLowerCase(),  "_UTD_"));
                    writer.add(eventFactory.createAttribute(key.toString(),  stringValue));
                }
           } else {
  //              writer.add(eventFactory.createAttribute(key.toString(),  "_UTD_"));
            }
        }
    }
    
    
}
