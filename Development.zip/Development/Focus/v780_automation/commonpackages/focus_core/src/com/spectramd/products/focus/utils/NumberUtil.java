/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;
import org.apache.commons.lang.math.NumberUtils;

/**
 *
 * @author sathyaji.raja
 */
public class NumberUtil {
    
    private NumberUtil() {
        
    }
    
    public static boolean isNumber(String input) {
        return NumberUtils.isNumber(input);
    }
}
