/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author sathyaji.raja
 */
public class ClientInfo implements Serializable {
    
    private String clientCode;
    private String path = "centrastate";
    private boolean headerRequired = false;
    private String feedReceiveDateStr;
    private OrderedInsensitiveMap mapConfig = new OrderedInsensitiveMap();
    
    public void add(String name, String value) {
        mapConfig.put(name, value);
    }
    
    public OrderedInsensitiveMap getMapConfig() {
        return mapConfig;
    }
    
    public void setMapConfig(OrderedInsensitiveMap mapConfig) {
        this.mapConfig = mapConfig;
    }
    
    public String getClientCode() {
        return clientCode;
    }
        
    public void setClientCode(String code) {
        clientCode = code;
    }
    
    public String getPath() {
        return path;
    }
        
    public void setPath(String path) {
        this.path = path;
    }

    public boolean isHeaderRequired() {
        return headerRequired;
    }

    public void setHeaderRequired(boolean headerRequired) {
        this.headerRequired = headerRequired;
    }

    public String getFeedReceiveDateStr() {
        return feedReceiveDateStr;
    }

    public void setFeedReceiveDateStr(String feedReceiveDate) {
        this.feedReceiveDateStr = feedReceiveDate;
    }
}
