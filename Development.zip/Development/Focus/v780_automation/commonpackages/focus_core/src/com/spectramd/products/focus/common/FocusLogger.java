/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import org.apache.log4j.Logger;
import org.apache.log4j.xml.DOMConfigurator;

/**
 *
 * @author sathyaji.raja
 */
public class FocusLogger {
   
    private static char LogOutputFieldSeperator ='\t';
    
    private static Logger AppLogger;
    private Logger instanceLogger;
    
    public FocusLogger(String loggerName) {
        instanceLogger = Logger.getLogger(loggerName);
    }

    public static void Initialize(LogConfigInfo argConfig) {
        
        // read the app config file and get the logger
        long watchFileInterval = argConfig.getLogFileWatchInterval();
        if (watchFileInterval != -1) {   
            DOMConfigurator.configure(argConfig.getLogFile());
        }
        else {
            DOMConfigurator.configure(argConfig.getLogFile());
        }
        AppLogger = Logger.getLogger(argConfig.getLoggerName());
    }
    
        
    public static void debug(Object message)   {
        if (AppLogger.isDebugEnabled()) {
            
            String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
            AppLogger.debug(detailedMessage);
        }
    }
    
     public static void debug(String argument , Object... messages)   {
        if (AppLogger.isDebugEnabled()) {
         
            StringBuilder sbMessage = new StringBuilder();
            sbMessage.append(argument);
            
            for ( Object msg : messages ) {
                sbMessage.append(", ");
                sbMessage.append(msg);
            }
            
            String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + sbMessage.toString();
            AppLogger.debug(detailedMessage);
        }
    }
    
    public static void debug(Object message, Throwable t)   {
        if (AppLogger.isDebugEnabled()) {
            String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
            AppLogger.debug(detailedMessage, t);
        }
    }
    
    public static void info(Object message) {
        String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
        AppLogger.info(detailedMessage);
    }
    
    public static void info(Object message, Throwable t) {
        String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
        AppLogger.info(detailedMessage, t);
    }
    
    public static void error(Object message) {
        String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
        AppLogger.error(detailedMessage);
    }
    
    public static void error(Object message, Throwable t) {
        String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
        AppLogger.error(detailedMessage, t);
    }
    
    private static String getSourceInfo() {
        
        Thread currentThread = Thread.currentThread();
        StackTraceElement[] caller = currentThread.getStackTrace();
        if (caller.length > 3) {
            StackTraceElement element = caller[3];
            StringBuilder sourceBuilder = new StringBuilder(200);
            // Add thread id
            sourceBuilder.append(currentThread.getName());
            sourceBuilder.append(":");
            sourceBuilder.append(currentThread.getId());
            sourceBuilder.append(LogOutputFieldSeperator);
            
            // add class, method and line number
            sourceBuilder.append("(");
            sourceBuilder.append(element.getClassName());
            sourceBuilder.append(":");
            sourceBuilder.append(element.getMethodName());
            sourceBuilder.append(":");
            sourceBuilder.append(element.getLineNumber());
            sourceBuilder.append(")");
            
            return sourceBuilder.toString();
        }
        
        return "";
    }
    
    // instance methods
   public void writeDebug(Object message)   {
        if (instanceLogger.isDebugEnabled()) {
            
            String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
            instanceLogger.debug(detailedMessage);
        }
    }
    
     public void writeDebug(String argument , Object... messages)   {
        if (instanceLogger.isDebugEnabled()) {
         
            StringBuilder sbMessage = new StringBuilder();
            sbMessage.append(argument);
            
            for ( Object msg : messages ) {
                sbMessage.append(", ");
                sbMessage.append(msg);
            }
            
            String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + sbMessage.toString();
            instanceLogger.debug(detailedMessage);
        }
    }
    
    public void writedebug(Object message, Throwable t)   {
        if (instanceLogger.isDebugEnabled()) {
            String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
            instanceLogger.debug(detailedMessage, t);
        }
    }
    
    public void writeInfo(Object message) {
        String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
        instanceLogger.info(detailedMessage);
    }
    
    public void writeInfo(Object message, Throwable t) {
        String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
        instanceLogger.info(detailedMessage, t);
    }
    
    public void writeError(Object message) {
        String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
        instanceLogger.error(detailedMessage);
    }
    
    public void writeError(Object message, Throwable t) {
        String detailedMessage = getSourceInfo() + LogOutputFieldSeperator + message.toString();
        instanceLogger.error(detailedMessage, t);
    }
   
}
