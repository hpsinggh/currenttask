/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 *
 * @author sathyaji.raja
 */
public class ValueConfigInfo extends ConfigInfo {
    
    private String value;
    
    public String getValue() {
        return value;
    }
    
    public void setValue(String configValue) {
        this.value = configValue;
    }
    
}
