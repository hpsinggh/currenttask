/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 *
 * @author smoghul
 */
public class ThreadPoolManager {
    
    private static ThreadPoolManager manager = new ThreadPoolManager();
    private ThreadPoolExecutor executor = null;
    
    private ThreadPoolManager() {
        
        BlockingQueue<Runnable> worksQueue = new ArrayBlockingQueue<Runnable>(20);
        executor = new ThreadPoolExecutor(6, 15, 30,TimeUnit.MINUTES, worksQueue);
        executor.allowCoreThreadTimeOut(true);
    }
    
    public static ThreadPoolManager getInstance() {
      
      return manager;
    }
    
    
    public void execute(Runnable runInstance) {
        executor.execute(runInstance);
    }
    
    
}
