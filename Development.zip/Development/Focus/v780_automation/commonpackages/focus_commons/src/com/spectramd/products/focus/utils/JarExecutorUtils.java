/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import com.spectramd.products.focus.common.FocusConfig;
import java.io.*;

/**
 *
 * @author Siraj.M
 */
public class JarExecutorUtils {
    
    /**
     * This method will execute the jar file
     * @param String[] args
     */
    public static int execute(String jarName, String workingDirectory, 
                                String[] args)  throws IOException, InterruptedException {

        //1. create the command statement
        String command[] = new String[args.length + 3];
        command[0] = "java";
        command[1] = "-jar";
        command[2] = jarName;
        
        System.arraycopy(args, 0, command, 3, args.length);
        
        //String command[] = {"java","-jar",args[0],"-client",args[2],args[3],args[4],args[5],args[6],args[7]};

        //2. Create process working directory
        return ProcessUtils.execute(jarName, workingDirectory, command);
     }
    
    public static int executeClassPath(String classPathName, String workingDirectory, 
                                String[] args)  throws IOException, InterruptedException {

        //1. create the command statement
        String command[] = new String[args.length + 3];
        command[0] = "java";
        command[1] = "-cp";
        command[2] = classPathName;
        
        System.arraycopy(args, 0, command, 3, args.length);
        
        //String command[] = {"java","-jar",args[0],"-client",args[2],args[3],args[4],args[5],args[6],args[7]};

        //2. Create process working directory
        return ProcessUtils.execute(classPathName, workingDirectory, command);
     }
    
  
    
}
