/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import com.spectramd.products.focus.common.dimensions.DimensionParamBean;
import com.spectramd.products.focus.common.dimensions.DimensionQueryBean;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author sathyaji.raja
 */
public final class DBResultSet {
    
	/**
	 * DB Connection.
	 */
    private Connection dbConnection;
    
	/**
	 * Constructor.
	 * @param argConnection Connection
	 */
	public DBResultSet(final Connection argConnection) {
        dbConnection = argConnection;
    }
    
	/**
	 * Executes the provided SQL Query.
	 * @param queryString String
	 * @param eventListener ResultSetEvent
	 * @param errorString String
	 * @throws Exception on error
	 */
	public void execute(final String queryString, final ResultSetEvent eventListener, final String errorString)
			throws Exception {
      
        Statement statement = null;
        ResultSet rs = null;
        
        try {
			// execute the statement
            statement = dbConnection.createStatement(); 
            rs = statement.executeQuery(queryString);
            while (rs.next())  {
                ResultSetEventObject newObject = new ResultSetEventObject(rs);
				eventListener.resultSetMoved(newObject);
            }

        } finally  {
            DBUtil.closeAllObjects(null, statement, null);
        }
    }

	/**
	 * This method will execute the stored procedure.
	 *
	 * @param dimensionBean DimensionQueryBean
	 * @param eventListener ResultSetEvent
	 * @param errorString String
	 * @throws Exception on error
	 */
	public void executeStoredProcedure(final DimensionQueryBean dimensionBean, final ResultSetEvent eventListener,
			final String errorString) throws Exception {

		CallableStatement callableStmt = null;
		ResultSet rs = null;
		try {
                    DimensionParamBean paramBean = (DimensionParamBean) dimensionBean;

                    // Execute the stored procedure
                    callableStmt = dbConnection.prepareCall(paramBean.getQuery());
                    int paramIndex = 0;

                    // set the parameters to the stored procedure
                    if (paramBean.getProcedureParamsList() != null && 
                            !paramBean.getProcedureParamsList().isEmpty()) {
                        for (int index = 0; index < paramBean.getProcedureParamsList().size(); index++) {
                                Object paramValue = paramBean.getProcedureParamsList().get(index);

                                //check the paramvalue type and set the corresponding type
                                if (paramValue != null) {
                                    if (paramValue instanceof Integer) {
                                        callableStmt.setInt(++paramIndex, (Integer) paramValue);
                                    } else if (paramValue instanceof Float) {
                                        callableStmt.setFloat(++paramIndex, (Float) paramValue);
                                    } else if (paramValue instanceof Long) {
                                        callableStmt.setLong(++paramIndex, (Long) paramValue);
                                    } else if (paramValue instanceof String) {
                                        callableStmt.setString(++paramIndex, paramValue.toString());
                                    } else if (paramValue instanceof Boolean) {
                                        callableStmt.setBoolean(++paramIndex, (Boolean) paramValue);
                                    }
                                }
                        }
                    }
                    
                    callableStmt.execute();
                    rs = (ResultSet) callableStmt.getResultSet();
                    while (rs.next()) {
                            ResultSetEventObject newObject = new ResultSetEventObject(rs);
                            eventListener.resultSetMoved(newObject);
                    }
		} finally {
                    DBUtil.closeAllObjects(null, callableStmt, null);
		}
	}
}
