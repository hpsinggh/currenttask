/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

//import com.spectramd.products.focus.utils.HtmlUtils;

/**
 *
 * @author sathyaji.raja
 */
public class FieldDetails {
    
    //Ramya 02/26: changed the default to 0, an id of -1 represents an empty expression
    private long id= 0;
    public String ResultFieldName = "";
    public FieldQualifier Qualifier = FieldQualifier.NONE;
    public FieldType Type = FieldType.NONE;
    public FieldCategory Category = FieldCategory.NONE;
    public String Value = ""; // either expression, value or field based on category
    private long templateId = -1;
    private int aggregate = 0;
    private long additionalValue = -1;
    private String constraintType;

    private long exprBrgId = -1;

    public String getConstraintType() {
        return constraintType;
    }

    public void setConstraintType(String constraintType) {
        this.constraintType = constraintType;
    }
    
    //adding sequence number and operator
    
    private double sequenceNumber;
    private String operator;
    
    
    public FieldDetails() {
        
    }
    
    public FieldDetails(FieldDetails argFieldDetails) {
        this.id = argFieldDetails.id;
        this.ResultFieldName = argFieldDetails.ResultFieldName;
        this.Value = argFieldDetails.Value;
        this.Qualifier = argFieldDetails.Qualifier;
        this.Type = argFieldDetails.Type;
        this.Category = argFieldDetails.Category;
        this.templateId = argFieldDetails.templateId;
        this.aggregate = argFieldDetails.aggregate;
        this.operator = argFieldDetails.operator;
        this.sequenceNumber = argFieldDetails.sequenceNumber;
        this.constraintType = argFieldDetails.constraintType;
    }
    
    public FieldDetails(long id, String ResultFieldName,String Value,FieldQualifier Qualifier,
                                                    FieldType Type,FieldCategory Category) {
        this.id = id;
        this.ResultFieldName = ResultFieldName;
        this.Value = Value;
        this.Qualifier = Qualifier;
        this.Type = Type;
        this.Category = Category;
    }

    public FieldDetails(long id, String ResultFieldName,String Value,
                            FieldQualifier Qualifier,FieldType Type,
                            FieldCategory Category, long argTemplateId, int argAggregate)     {
        this.id = id;
        this.ResultFieldName = ResultFieldName;
        this.Value = Value;
        this.Qualifier = Qualifier;
        this.Type = Type;
        this.Category = Category;
        this.templateId = argTemplateId;
        this.aggregate = argAggregate;
    }

    public FieldDetails(long id, String ResultFieldName,String Value,
                            FieldQualifier Qualifier,FieldType Type,
                            FieldCategory Category, long argTemplateId, int argAggregate,
                            long AdditionalValue)     {
        this.id = id;
        this.ResultFieldName = ResultFieldName;
        this.Value = Value;
        this.Qualifier = Qualifier;
        this.Type = Type;
        this.Category = Category;
        this.templateId = argTemplateId;
        this.aggregate = argAggregate;
        this.additionalValue = AdditionalValue;
    }
    
    
    public FieldDetails(String ResultFieldName,String Value,FieldQualifier Qualifier,
                                                    FieldType Type,FieldCategory Category) {
        this.ResultFieldName = ResultFieldName;
        this.Value = Value;
        this.Qualifier = Qualifier;
        this.Type = Type;
        this.Category = Category;
    }
     
    public long getId() {
        return id;
    }
    
    public void setId(long measureId) {
        id = measureId;
    }
    
     public FieldCategory getCategory() {
        return Category;
    }

    public void setCategory(FieldCategory category) {
        this.Category = category;
    }

    public FieldQualifier getQualifier() {
        return Qualifier;
    }

    public void setQualifier(FieldQualifier qualifier) {
        this.Qualifier = qualifier;
    }

    public String getResultFieldName() {
        return ResultFieldName;
    }

    public void setResultFieldName(String resultFieldName) {
        this.ResultFieldName = resultFieldName;
    }

    public FieldType getType() {
        return Type;
    }

    public void setType(FieldType type) {
        this.Type = type;
    }

    public String getValue() {
        return Value;
    }

    public void setValue(String value) {
        this.Value = value;
    }
    
//    public String getHtmlValue() {
//        return HtmlUtils.encode(Value);
//    }
    
    public long getTemplateId() {
        return templateId;
    }
    
    public void setTemplateId(long argTemplateId)   {
        templateId = argTemplateId;
    }
    
    public int getAggregate() {
        return aggregate;
    }
    
    public void setAggregate(int argAggregate)   {
        aggregate = argAggregate;
    }
    
    public long getAdditionalValue() {
        return additionalValue;
    }

    public void setAdditionalValue(long additionalValue) {
        this.additionalValue = additionalValue;
    }

    /**
     * @return the sequenceNumber
     */
    public double getSequenceNumber() {
        return sequenceNumber;
    }

    /**
     * @param sequenceNumber the sequenceNumber to set
     */
    public void setSequenceNumber(double sequenceNumber) {
        this.sequenceNumber = sequenceNumber;
    }

    /**
     * @return the operator
     */
    public String getOperator() {
        if(operator == null){
            return "";
        }else{
        return operator;
        }
        
    }

    /**
     * @param operator the operator to set
     */
    public void setOperator(String operator) {
        this.operator = operator;
    }

    /**
     * @return the exprBrgId
     */
    public long getExprBrgId() {
        return exprBrgId;
    }

    /**
     * @param exprBrgId the exprBrgId to set
     */
    public void setExprBrgId(long exprBrgId) {
        this.exprBrgId = exprBrgId;
    }
    
}
