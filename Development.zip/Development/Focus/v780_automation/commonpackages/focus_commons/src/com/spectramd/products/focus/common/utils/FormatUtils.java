/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

/**
 *
 * @author sathyaji.raja
 */
public final class FormatUtils {

	/**
	 * Private Default Constructor.
	 */
	private FormatUtils() {
	}

	/**
	 * Quarter String for the provided CAL_QUARTER_KEY.
	 * @param quarterKey Long
	 * @return String
	 */
	public static String getQuarterString(final Long quarterKey) {
		String quarterKeyValue = String.valueOf(quarterKey);
		String quarterString = "Q" + quarterKeyValue.substring(4) + " " + quarterKeyValue.substring(0, 4);
		return quarterString;
	}
}
