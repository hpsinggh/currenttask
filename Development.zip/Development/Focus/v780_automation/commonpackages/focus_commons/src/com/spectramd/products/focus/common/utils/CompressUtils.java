/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import java.io.ByteArrayOutputStream;
import java.util.zip.Deflater;
import java.util.zip.Inflater;

/**
 *
 * @author sathyaji.raja
 */
public final class CompressUtils {

    public static byte[] compress(byte[] input) throws Exception {
        byte[] output = null;
        ByteArrayOutputStream baos = null;
        try {
            Deflater df = new Deflater();
            df.setInput(input);
            baos = new ByteArrayOutputStream(input.length);
            df.finish();

            // Compressed output stream may be bigger than the input stream
            byte[] buff = new byte[1024];
            while (!df.finished()) {
                int count = df.deflate(buff);
                baos.write(buff, 0, count);
            }
            output = baos.toByteArray();
        } finally {

            if (baos != null) {
                baos.close();
            }

        }
        return output;
    }

    public static byte[] decompress(byte[] input) throws Exception {
        ByteArrayOutputStream baos = null;
        byte[] output = null;

        try {
            Inflater ifl = new Inflater();
            ifl.setInput(input);

            baos = new ByteArrayOutputStream(input.length);
            byte[] buff = new byte[1024];
            while (!ifl.finished()) {
                int count = ifl.inflate(buff);
                baos.write(buff, 0, count);
            }
            output = baos.toByteArray();
        } finally {
            if (baos != null) {
                baos.close();
            }
        }
        return output;
    }
}
