/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.DBConfigInfo;
import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusException;
import com.spectramd.products.focus.common.FocusLogger;
import com.spectramd.products.focus.measure.logic.core.utils.QueryBuilder;
import com.spectramd.products.focus.measure.logic.core.utils.QueryBuilderFactory;
import com.spectramd.products.focus.measure.logic.core.utils.QueryBuilderInterface;
import com.spectramd.products.focus.measures.common.AbstractView;
import com.spectramd.products.focus.measures.common.DatabaseField;
import com.spectramd.products.focus.measures.common.jobdata.MeasureJobData;
import com.spectramd.products.focus.utils.DBConnection;
import com.spectramd.products.focus.utils.DBUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

/**
 *
 * @author sathyaji.raja
 */
public class DatabaseBatchInputProcessor implements InputProcessor {

    private AbstractView viewDetails;
    private String primaryField;
    private String[] formatValues;
    private ArrayList<DatabaseField> defaultValues;
    
            
    Connection con = null;
    Statement stmt = null;
    ResultSet rs = null;
    ResultSetMetaData rsMetaData = null;
    
    private int batchSize = 100;
    private List<OrderedInsensitiveMap> currentDataMapList = null;
    
    public DatabaseBatchInputProcessor(AbstractView argViewDetails, String primaryField,
                                            ArrayList<DatabaseField> argDefaultFieldValues, 
                                            String [] input, int batchSize) {
            
                                            /*List<String> columnsToCreateList,
                                            AbstractView dimensionViewDetails,
                                            String dimensionDetailString, int batchSize)   {*/
        viewDetails = argViewDetails;
        this.primaryField = primaryField;
        formatValues = input;
        defaultValues = argDefaultFieldValues;
        this.batchSize = batchSize;
     }
    
    @Override
    public void start(MeasureJobData measureJobData) throws FocusException {
        
        try {
            // 1. Create the connection and execute the query
            DBConfigInfo configInfo = FocusConfig.getCurrentInstance().getDataSourceConfig();
            con = DBConnection.getConnection(configInfo);
            stmt = DBUtil.getStatement(con, (int)(batchSize/20));
            
            // 2. Build the query
            QueryBuilderFactory factory = QueryBuilderFactory.getInstance();
            QueryBuilderInterface queryBuilder = factory.getQueryBuilderFromClassName(viewDetails.getClass().getName());
            String query = queryBuilder.getQuery(viewDetails, defaultValues, formatValues);
            FocusConfig.getCurrentLogger().writeDebug("Starting to fetch rows for query "+ query);
            
            // 3. Execute the query
            rs = stmt.executeQuery(query);
            rsMetaData = rs.getMetaData();
            
        } catch (Exception ex)  {
            FocusConfig.getCurrentLogger().writeError("", ex);
            throw new FocusException("", ex);
        } 

    }
    
    @Override
    public long getCurrentRecordCount() {
        return currentDataMapList != null? currentDataMapList.size() : 0;
    }
    
    @Override
    public boolean next()  throws FocusException {
        
        boolean result = false;
        try {
            currentDataMapList = new ArrayList<OrderedInsensitiveMap>();
            for (int index=0; index < batchSize; index++) {
                
                boolean rsResult = rs.next();
                if (!result) {
                    result = rsResult;
                }
                
                // Get the input
                if (rsResult) {
                    OrderedInsensitiveMap mapInput =  DBUtil.getResulSetAsMap(rs, rsMetaData);
                    currentDataMapList.add(mapInput);
                } else {
                    break;
                }
            }
            
        } catch (SQLException ex)  {
            FocusConfig.getCurrentLogger().writeError("", ex);
            throw new FocusException("", ex);
        }
        
        return result;
        
    }

    @Override
    public List<OrderedInsensitiveMap> getCurrentData() throws FocusException {
        return currentDataMapList;
//        OrderedInsensitiveMap mapInput =  null;
//        try {
//            
////            ArrayList<AbstractView> childViews = viewDetails.getChildViews();
////            if (childViews != null && childViews.size() > 0  && primaryField != null)
////                updateInputForChildViews(mapInput);
//        } catch (SQLException ex)  {
//            FocusConfig.getCurrentLogger().writeError("", ex);
//            throw new FocusException("", ex);
//        }
//        
//        return mapInput;
    }
    
    private void updateInputForChildViews(OrderedInsensitiveMap mapInput) throws FocusException {
     
        try {
            // 3. Create the connection and execute the query
            Statement stmt2 = DBUtil.getStatement(con, 50);
            
            String primaryFieldValue = mapInput.get(primaryField).toString();
            ArrayList inputValues = new ArrayList();
            ArrayList inputValuesList = new ArrayList();
            inputValuesList.add(primaryFieldValue);
            inputValues.add(inputValuesList);
            FocusConfig.getCurrentLogger().writeDebug("Fetching records for primary field value" + primaryFieldValue);
            
            ArrayList<AbstractView> childViews = viewDetails.getChildViews();
            for (int index = 0; index < childViews.size(); index++) {
                
                // Execute the query
                String query = QueryBuilder.getComplexQuery(childViews.get(index), null, inputValues);
                FocusConfig.getCurrentLogger().writeDebug("Starting to fetch rows for query "+ query);
                ResultSet childSet = stmt2.executeQuery(query);
                ResultSetMetaData childMetaData = childSet.getMetaData();
                
                // Create an arrayList for each of the columns
                OrderedInsensitiveMap mapTemp = new OrderedInsensitiveMap();
                for (int colCount=1; colCount<=childMetaData.getColumnCount(); colCount++)   {
                    String colName = childMetaData.getColumnLabel(colCount);
                    mapTemp.put(colName, new ArrayList());
                }
                
                // Iterate and the add the column Values to the column list
                while (childSet.next()) {
                   OrderedInsensitiveMap mapChildInput =  DBUtil.getResulSetAsMap(childSet, childMetaData);
                   
                   Iterator keys = mapChildInput.keySet().iterator();
                   while (keys.hasNext())   {
                       String keyName = keys.next().toString();
                       ArrayList colValueList = (ArrayList)mapTemp.get(keyName);
                       
                       Object colValue = mapChildInput.get(keyName);
                       colValueList.add(colValue);
                       FocusConfig.getCurrentLogger().writeDebug("adding key , value for child view -" + keyName + " " + colValue);
                   }
               }
                
               // Update the input map
               Iterator colkeys = mapTemp.keySet().iterator();
               while (colkeys.hasNext())   {
                
                   String colName = colkeys.next().toString();
                   ArrayList colValueList = (ArrayList)mapTemp.get(colName);
                   
                   String mapInputColName = colName + "_LIST";
                   mapInput.put(mapInputColName, colValueList);
                   FocusConfig.getCurrentLogger().writeDebug("count of values for " + colName + " is " + colValueList.size());
               }
               
               
            }
            
        } catch (Exception ex)  {
            FocusConfig.getCurrentLogger().writeError("", ex);
            throw new FocusException("", ex);
        } 
    }

    
    @Override
    public void stop()  throws FocusException {
        try  {
            DBUtil.closeAllObjects(con, stmt, rs);
        }   catch (SQLException ex){
            FocusConfig.getCurrentLogger().writeError(DBUtil.Error_failedtoclosedbresources, ex);
            throw new FocusException(DBUtil.Error_failedtoclosedbresources, ex);
        }
    }

    
}
