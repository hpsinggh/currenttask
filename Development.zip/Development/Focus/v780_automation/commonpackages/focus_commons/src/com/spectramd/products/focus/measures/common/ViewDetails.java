/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

/**
 *
 * @author sathyaji.raja
 */
public class ViewDetails extends AbstractView {
    
 
    private TableDetails primaryTableDetails;
     
    
    public ViewDetails() {
        super("VIEW");
    }
   

    public TableDetails getPrimaryTableDetails() {
        return primaryTableDetails;
    }

    public void setPrimaryTableDetails(TableDetails primaryTableDetails) {
        this.primaryTableDetails = primaryTableDetails;
    }

}
