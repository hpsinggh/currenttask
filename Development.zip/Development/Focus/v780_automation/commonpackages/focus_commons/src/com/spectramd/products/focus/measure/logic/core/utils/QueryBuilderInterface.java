/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.measures.common.AbstractView;
import com.spectramd.products.focus.measures.common.DatabaseField;
import java.util.ArrayList;

/**
 *
 * @author sathyaji.raja
 */
public interface QueryBuilderInterface {
 
    String getQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    String[] inputValues); 
    String getComplexQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    ArrayList inputValues) ;
    String getComplexQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    String inputType,ArrayList inputValues) ;
     
     
}
