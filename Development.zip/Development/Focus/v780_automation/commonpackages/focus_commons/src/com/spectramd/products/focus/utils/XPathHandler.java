/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;

/**
 *
 * @author ramya.khasnis
 */
public class XPathHandler {

    private XPathFactory xpathFactory = null;
    private XPath xpath = null;

    public XPathHandler() {
        xpathFactory = XPathFactory.newInstance();
        xpath = xpathFactory.newXPath();
    }

    public String getXPathValue(Document document, String expression) throws XPathExpressionException {
        XPathExpression xpathExpr = xpath.compile(expression);
        String value = (String) xpathExpr.evaluate(document, XPathConstants.STRING);
        return value;

    }
}
