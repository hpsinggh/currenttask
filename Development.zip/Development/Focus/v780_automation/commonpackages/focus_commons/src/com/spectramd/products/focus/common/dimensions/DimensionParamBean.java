/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.dimensions;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author siraj.m
 */
public class DimensionParamBean extends DimensionQueryBean {

	/**
	 * Parameters list for the Stored Procedure.
	 */
	private List procedureParamsList = new ArrayList();

	/**
	 *
	 * @return List.
	 */
	public List getProcedureParamsList() {
		return procedureParamsList;
	}

	/**
	 *
	 * @param procedureParamsList List.
	 */
	public void setProcedureParamsList(final List procedureParamsList) {
		this.procedureParamsList = procedureParamsList;
	}
}
