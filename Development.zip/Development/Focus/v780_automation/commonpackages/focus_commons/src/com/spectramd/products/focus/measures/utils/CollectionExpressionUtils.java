package com.spectramd.products.focus.measures.utils;

import com.spectramd.products.focus.measure.logic.core.utils.SpelUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

public class CollectionExpressionUtils
{
    
  public static boolean evaluateAny(List elementValues, String operator, Object value)   {
      boolean result = false;
      
      if (elementValues != null) {
          for (Object element : elementValues) {
              
 //             System.out.println()
             if (element instanceof Double) {
                 Double listValue = (Double)element;
                 Double valueAsLong = (Double)value;
                 
                 //System.out.println("list value =" + listValue);
                 if (operator.equalsIgnoreCase("GREATERTHANOREQUALTO")) {
                     if (listValue >= valueAsLong) {
                         result = true;
                         break;
                     }
                 }
                 
                 
             }
          }
          
      }
      
      return result;
  }
  public static void evaluate(List mapRowList, String expression)   {
      
    EvaluationContext context = null;
    ExpressionParser parser = null;
    
    try
    {
        context = SpelUtils.CreateEvaluationContext();
        parser = new SpelExpressionParser();
      
        for (Object dimMap : mapRowList) {
            context.setVariable("value", dimMap);

            Expression exp1 = parser.parseExpression(expression);
            exp1.getValue(context, Object.class); }
        }
        catch (NoSuchMethodException ex) {
        }
  }

  public static void evaluate(List mapRowList, String expression, String tempType, String tempValue) {
   
        try {
        EvaluationContext newContext = SpelUtils.CreateEvaluationContext();
        ExpressionParser parser = new SpelExpressionParser();

        Object tempValueResult = getTempValue(tempType, tempValue);
        newContext.setVariable("tempvalue", tempValueResult);

        //System.out.println("expression = " + expression);
        for (Object dimMap : mapRowList) {
            newContext.setVariable("value", dimMap);

            //System.out.println("key set count in map = " + ((Map)dimMap).keySet().size());
            Expression exp1 = parser.parseExpression(expression);
            exp1.getValue(newContext, Object.class);
        }
    } catch (NoSuchMethodException ex) {
        // do nothing...
    }
  }

  private static Object getTempValue(String tempType, String tempValue) {
      
    Object result = null;
    if (tempType.equalsIgnoreCase("MAP"))
    {
        Map resultMap = new HashMap();
        String[] listElements = tempValue.split(";");
        for (String element : listElements) {
            String[] mapElements = element.split("=");
            resultMap.put(mapElements[0].trim(), mapElements[1].trim());
        }

        result = resultMap;
    }
    return result;
    
  }
  
  // Sathya: Added for Centrastate to split into row and columns for visit abstracted attributes
  public static List splitRowColumn(String value, String rowSeperator, String columnSeperator,
          String attributeString, String defaultElementType, String defaultElementValue){
        List result = null;
      
      // 1. Get the default map elements to be added to the each of the element split
        Map defaultValuesMap = (Map)getTempValue(defaultElementType, defaultElementValue);
	  
	  // 2. Get the column names for each of the row element in the input string
	String[] attributes = attributeString.split(";");
	  
        // 3. Split each row
        if(value != null && value.trim().length() >0 && attributes != null && attributes.length > 0) {
	  
            String[] rows = value.split(rowSeperator);
            result = new ArrayList<Map>();
            for (String row : rows) {

                // 4. Split each column in the row
                String[] columns = row.split(columnSeperator);
                if(columns.length == attributes.length) {
                    Map columnMap = new HashMap();
                    for(int index=0; index < columns.length; index++) {
                        columnMap.put(attributes[index], columns[index]);
                    }

                    // 5. Add the default elements to the map
                    columnMap.putAll(defaultValuesMap);

                    // 6. add the map to the output result
                    result.add(columnMap);
                }
            }
         }
      
        return result;
    }

   
    
    public static Map getValueFromListMap(List codeList,String key,String value){
        
        for (Object object : codeList) {
            Map codeMap = (Map) object;
            String codeName = (String) codeMap.get(key);
            if(codeName.equalsIgnoreCase(value)){
                return codeMap;
            }
        }
        return null;
    } 
    
    public static void removeFromListMap(List dataElement,String key,String value){
        
        Iterator listIterator = dataElement.iterator();
        while(listIterator.hasNext()){
            Map elementMap = (Map) listIterator.next();
            String elementValue = (String)elementMap.get(key);
			
            if(elementValue.equalsIgnoreCase(value))	{
                listIterator.remove();
                return;
            }
        }
    }

    public static String getKeyValue(List dataElement, String key, String value, String resultKey) {
        //check if the key:value pair is present in the list of maps
        String resultValue = "";
        Iterator listIterator = dataElement.iterator();
        while (listIterator.hasNext()) {
            Map elementMap = (Map) listIterator.next();
            String elementValue = (String) elementMap.get(key);
            if (elementValue.equalsIgnoreCase(value)) {
                //if present return the value of resultKey
                resultValue = (String) elementMap.get(resultKey);
                break;
            }
        }
        return resultValue;
    }
    
    /**
     * 
     * @param map
     * @param size
     * @return List of Map's
     */
    // Sathya: This method needs to be removed....
    public static List getObservationCodes(TreeMap map){

        List codeMapList = null;

        if(map != null){
            codeMapList = new ArrayList();
            
            Object object = map.firstEntry().getValue();
            
            if(object instanceof List){
                int size = ((List)map.firstEntry().getValue()).size();

                for(int index=0; index<size; index++){
                    Map codeMap = new TreeMap();
                    Iterator iterator = map.keySet().iterator();
                    while(iterator.hasNext()){
                        String key = iterator.next().toString();
                        codeMap.put(key,((List)map.get(key)).get(index));
                    }

                    codeMapList.add(codeMap);
                }
            }else if(object instanceof String){
                codeMapList.add(map);
            }
        }

        return codeMapList;
    }
    
    public static boolean compareListValues(List dataList, String operator, 
                                                            String dataType, String conditionValue) {
        boolean returnFlag = false;

        for (Object listVal : dataList) {
            String tempString = (listVal != null) ? String.valueOf(listVal) : "0";
            if (dataType.equalsIgnoreCase("STRING")) {
                returnFlag = tempString.equalsIgnoreCase(tempString);
            } else if (dataType.equalsIgnoreCase("INT")) {
                returnFlag = compareIntValues(operator, Integer.parseInt(conditionValue), Integer.parseInt(tempString));
            } else if (dataType.equalsIgnoreCase("DOUBLE")) {
                returnFlag = compareDoubleValues(operator, Double.parseDouble(conditionValue), Double.parseDouble(tempString));
            } else if (dataType.equalsIgnoreCase("LONG")) {
                returnFlag = compareLongValues(operator, Long.parseLong(conditionValue), Long.parseLong(tempString));
            }

            if (returnFlag) {
                break;
            }
        }
        return returnFlag;
    }

    private static boolean compareIntValues(String operator, int conditionValue, int actualValue) {
        boolean returnFlag = false;
        if (operator.equalsIgnoreCase(">")) {
            returnFlag = actualValue > conditionValue;
        } else if (operator.equalsIgnoreCase(">=")) {
            returnFlag = actualValue >= conditionValue;
        } else if (operator.equalsIgnoreCase("<")) {
            returnFlag = actualValue < conditionValue;
        } else if (operator.equalsIgnoreCase("<=")) {
            returnFlag = actualValue <= conditionValue;
        } else if (operator.equalsIgnoreCase("==")) {
            returnFlag = (actualValue == conditionValue);
        } else if (operator.equalsIgnoreCase("!=")) {
            returnFlag = (actualValue != conditionValue);
        }

        return returnFlag;
    }
    
    private static boolean compareDoubleValues(String operator, double conditionValue, double actualValue) {
        boolean returnFlag = false;
        if (operator.equalsIgnoreCase(">")) {
            returnFlag = actualValue > conditionValue;
        } else if (operator.equalsIgnoreCase(">=")) {
            returnFlag = actualValue >= conditionValue;
        } else if (operator.equalsIgnoreCase("<")) {
            returnFlag = actualValue < conditionValue;
        } else if (operator.equalsIgnoreCase("<=")) {
            returnFlag = actualValue <= conditionValue;
        } else if (operator.equalsIgnoreCase("==")) {
            returnFlag = (actualValue == conditionValue);
        } else if (operator.equalsIgnoreCase("!=")) {
            returnFlag = (actualValue != conditionValue);
        }

        return returnFlag;
    }
    
    private static boolean compareLongValues(String operator, long conditionValue, long actualValue) {
        boolean returnFlag = false;
        if (operator.equalsIgnoreCase(">")) {
            returnFlag = actualValue > conditionValue;
        } else if (operator.equalsIgnoreCase(">=")) {
            returnFlag = actualValue >= conditionValue;
        } else if (operator.equalsIgnoreCase("<")) {
            returnFlag = actualValue < conditionValue;
        } else if (operator.equalsIgnoreCase("<=")) {
            returnFlag = actualValue <= conditionValue;
        } else if (operator.equalsIgnoreCase("==")) {
            returnFlag = (actualValue == conditionValue);
        } else if (operator.equalsIgnoreCase("!=")) {
            returnFlag = (actualValue != conditionValue);
        }

        return returnFlag;
    }
   
    /**
     * This method will add name and value to the map.
     * name=pad_edu or suborhome value=obs_code value. Also it will check the existing value and concat to the map value
     * @param map
     * @param values
     * @param category 
     */
    public static void insertIntoMap(Map map, String values,String category) {
        
        // iterate through the values containing name=value and value=value
        String[] listElements = values.split(";");
        for (String element : listElements) {
            String[] mapElements = element.split("=");
            map.put(mapElements[0].trim(), (map.get(category) != null && mapElements[0].trim().equalsIgnoreCase(category)) ? map.get(category)+","+mapElements[1].trim():mapElements[1].trim());
        }
    }
    
}