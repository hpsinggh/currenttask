/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.UUID;

/**
 *
 * @author sathyaji.raja
 */
public class StreamGobbler extends Thread
{
    private InputStream is;
    String type;
    
    public StreamGobbler(InputStream is, String type)
    {
        this.is = is;
        this.type = type;
    }
    
    public void run()
    {
        BufferedReader reader = null;
        FileOutputStream fileOutputStream = null;
        BufferedWriter writer = null;
        try
        {
//            InputStreamReader isr = new InputStreamReader(is);
//            BufferedReader br = new BufferedReader(isr);
//            String line=null;
//            while ( (line = br.readLine()) != null)
//                System.out.println(type + ">" + line);    
               
                reader = new BufferedReader(new InputStreamReader(is));
                String outputFileName =  UUID.randomUUID().toString();
                fileOutputStream = new FileOutputStream(outputFileName);
                writer = new BufferedWriter(new OutputStreamWriter(fileOutputStream));
                
                //reader.rea
                String str = null;
                long count = 0;
                //StringBuilder sb = new StringBuilder(8192);
                while ((str = reader.readLine()) != null) {
                    writer.write(str);
                    count++;
                    if (count%10 == 0) {
                        writer.flush();
                    }
                }
                writer.flush();
        
            } catch (IOException ioe) {
                ioe.printStackTrace();  
            } finally {
                try {
                 if(writer != null){
                    writer.close();
                }            
                if(fileOutputStream != null){
                    fileOutputStream.flush();
                    fileOutputStream.close();
                }
                if(reader != null){
                    reader.close();
                }
                } catch (Exception ex) {
                    ex.printStackTrace();
                }
           
            }
        
            
    }
}
