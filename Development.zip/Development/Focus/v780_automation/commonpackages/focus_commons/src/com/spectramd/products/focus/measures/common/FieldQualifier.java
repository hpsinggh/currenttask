/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

/**
 *
 * @author sathyaji.raja
 */
public enum FieldQualifier {
    NONE, TEMP, PERM, FILTER;
    
    
    public static FieldQualifier getQualifier(String qualifier) {
        
        if (qualifier.equalsIgnoreCase("PERM"))
            return FieldQualifier.PERM;
        else if (qualifier.equalsIgnoreCase("TEMP"))
            return FieldQualifier.TEMP;
        else if (qualifier.equalsIgnoreCase("FILTER"))
            return FieldQualifier.FILTER;
        else 
            return FieldQualifier.NONE;
    }
}
