/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

/**
 *
 * @author sathyaji.raja
 */
public class DBTableDetails {
    private long tableId;
    private String name;
    
    public long getTableId() {
        return tableId;
    }
    
    public void setTableId(long tableId) {
        this.tableId = tableId;
    }
    
      public String getName() {
        return name;
    }

    public void setName(String Name) {
        this.name = Name;
    }
}
