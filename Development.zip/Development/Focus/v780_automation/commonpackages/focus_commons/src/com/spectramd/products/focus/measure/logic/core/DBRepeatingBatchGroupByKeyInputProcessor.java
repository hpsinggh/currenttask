/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.DBConfigInfo;
import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusException;
import com.spectramd.products.focus.measure.logic.core.utils.QueryBuilderFactory;
import com.spectramd.products.focus.measure.logic.core.utils.QueryBuilderInterface;
import com.spectramd.products.focus.measures.common.AbstractView;
import com.spectramd.products.focus.measures.common.DatabaseField;
import com.spectramd.products.focus.measures.common.jobdata.MeasureJobData;
import com.spectramd.products.focus.utils.DBUtil;
import java.sql.*;
import java.util.*;
import javax.sql.DataSource;
import org.apache.commons.collections.MapIterator;

/**
 *
 * @author anmol.gupta
 */
/******************************************************************************************
*  Change Made: added functionality to configure the data source for input processor
*  Author: Ramya
*  Date of Change: 07/31/2013
******************************************************************************************/
/******************************************************************************************
*  Change Made: added dataSource argument to the constructor to get connection
*  Author: larvilla
*  Date of Change: 02/13/2015
******************************************************************************************/
public class DBRepeatingBatchGroupByKeyInputProcessor implements InputProcessor {

    private AbstractView viewDetails;
    private String primaryField;
    private String[] formatValues;
    private ArrayList<DatabaseField> defaultValues;
    
    private List<String> columnsToCreateList = null;
            
    Connection con = null;
    Statement stmt = null;
    ResultSet rs = null;
    ResultSetMetaData rsMetaData = null;
    
    private List<OrderedInsensitiveMap> currentDataMapList = null;
    private OrderedInsensitiveMap previousDataMap = null;
    
    private List<AbstractView> dimensionViewDetails;
    private String[] dimensionDetailString;
    private String[] connectFields;
    private String[] connectFieldType;
    private String[] dimensionCount;
    
    private String dbConfig;
    private int batchSize = 100;
    private DataSource dataSource;
    private  String GroupByKey;
        
    
    public DBRepeatingBatchGroupByKeyInputProcessor(AbstractView argViewDetails, String primaryField,
                                            ArrayList<DatabaseField> argDefaultFieldValues, 
                                            String [] input, List<String> columnsToCreateList,
                                            List<AbstractView> dimensionViewDetails,
                                            String[] dimensionDetailString, String[] connectFields, String[] fieldType)   {
        initialize(argViewDetails, primaryField, argDefaultFieldValues, input, columnsToCreateList,
                    dimensionViewDetails, dimensionDetailString, connectFields, fieldType);
    }
    
    public DBRepeatingBatchGroupByKeyInputProcessor(AbstractView argViewDetails, String primaryField,
                                            ArrayList<DatabaseField> argDefaultFieldValues, 
                                            String [] input, List<String> columnsToCreateList,
                                            List<AbstractView> dimensionViewDetails,
                                            String[] dimensionDetailString, 
                                            String[] connectFields, String[] fieldType,
                                             String[] dimensionCount,int batchSize)   {
        initialize(argViewDetails, primaryField, argDefaultFieldValues, input, columnsToCreateList,
                    dimensionViewDetails, dimensionDetailString, connectFields, fieldType);
        this.dimensionCount = dimensionCount;
        this.batchSize = batchSize;
    }
    
    public DBRepeatingBatchGroupByKeyInputProcessor(AbstractView argViewDetails, String primaryField,
                                            ArrayList<DatabaseField> argDefaultFieldValues, 
                                            String [] input, List<String> columnsToCreateList,
                                            List<AbstractView> dimensionViewDetails,
                                            String[] dimensionDetailString, 
                                            String[] connectFields, String[] fieldType,
                                             String[] dimensionCount,int batchSize, String dbConfig)   {
        initialize(argViewDetails, primaryField, argDefaultFieldValues, input, columnsToCreateList,
                    dimensionViewDetails, dimensionDetailString, connectFields, fieldType);
        this.dimensionCount = dimensionCount;
        this.batchSize = batchSize;
        this.dbConfig = dbConfig;
    }
    
    
    public DBRepeatingBatchGroupByKeyInputProcessor(AbstractView argViewDetails, String primaryField,
                                            ArrayList<DatabaseField> argDefaultFieldValues, 
                                            String [] input, List<String> columnsToCreateList,
                                            List<AbstractView> dimensionViewDetails,
                                            String[] dimensionDetailString, 
                                            String[] connectFields, String[] fieldType,
                                             String[] dimensionCount,int batchSize, String dbConfig,DataSource dataSource, String GroupByKey)   {
        initialize(argViewDetails, primaryField, argDefaultFieldValues, input, columnsToCreateList,
                    dimensionViewDetails, dimensionDetailString, connectFields, fieldType);
        this.dimensionCount = dimensionCount;
        this.batchSize = batchSize;
        this.dbConfig = dbConfig;
        this.dataSource = dataSource;
        this.GroupByKey = GroupByKey;
    }
    
    private void initialize(AbstractView argViewDetails, String primaryField,
                                            ArrayList<DatabaseField> argDefaultFieldValues, 
                                            String [] input, List<String> columnsToCreateList,
                                            List<AbstractView> dimensionViewDetails,
                                            String[] dimensionDetailString, String[] connectFields, String[] fieldType)   {
        viewDetails = argViewDetails;
        this.primaryField = primaryField;
        formatValues = input;
        defaultValues = argDefaultFieldValues;
        this.columnsToCreateList = columnsToCreateList;
        this.dimensionViewDetails = dimensionViewDetails;
        this.dimensionDetailString = dimensionDetailString;
        this.connectFields = connectFields;
        this.connectFieldType = fieldType;
    }
    
    
    @Override
    public void start(MeasureJobData measureJobData) throws FocusException {
        
        try {
            // 1. Create the connection and execute the query
//            DBConfigInfo configInfo = getDBConfigInfo(); //FocusConfig.getCurrentInstance().getDataSourceConfig();
//            con = DBConnection.getConnection(configInfo); //DBUtil.getConnectionNew();
//            stmt = DBUtil.getStatement(con, (int)(batchSize/10));
            con = dataSource.getConnection();
            stmt = DBUtil.getStatement(con, (int)(batchSize/10));
            
            // 1. Build the query
            QueryBuilderFactory factory = QueryBuilderFactory.getInstance();
            QueryBuilderInterface queryBuilder = factory.getQueryBuilderFromClassName(viewDetails.getClass().getName());
            String query = queryBuilder.getQuery(viewDetails, defaultValues, formatValues);
            
            FocusConfig.getCurrentLogger().writeDebug("Starting to fetch rows for query "+ query);
            
            // 3. Execute the query
            rs = stmt.executeQuery(query);
            rsMetaData = rs.getMetaData();
            
        } catch (Exception ex)  {
            FocusConfig.getCurrentLogger().writeError("", ex);
            throw new FocusException("", ex);
        } 

    }
    
    @Override
    public long getCurrentRecordCount() {
        return (currentDataMapList != null? currentDataMapList.size() : 0);
    }
    
    @Override
    public boolean next()  throws FocusException {
        
        boolean result = false;
        Set<Long> patientCount = new HashSet<Long>();
        
        
        try {
            
            boolean dynamicDimension = false;
            currentDataMapList = new ArrayList<OrderedInsensitiveMap>();
            Map<Integer, List> dimensionKeyList = new HashMap<Integer, List>();
//            for (int index=0; index <= batchSize; index++) {
            while (patientCount.size() <= batchSize) {
                
                // check if previous data map is null, otherwise get from the recordset
                boolean next = false;
                if (previousDataMap == null) {
                    next = rs.next();
                } else {
                    next = true;
                }

                if (!result) {
                    result = next;
                }

                // Need to check for the next record
                if (next) {

                    // Get the first record
                    OrderedInsensitiveMap primaryMap = null;
                    String primaryKey = "";
                    if (previousDataMap == null) {
                        primaryMap = DBUtil.getResulSetAsMap(rs, rsMetaData);
                        primaryKey = rs.getString(1);
                        long groupByKeyValue = (Integer) rs.getInt(GroupByKey);
                        patientCount.add(groupByKeyValue);
                        //FocusConfig.getCurrentLogger().writeDebug("primary Key = " + primaryKey);
                    } else {
                        primaryMap = previousDataMap;
                        String mapPrimaryKey = primaryMap.getKeyFromIndex(0);
                        primaryKey = primaryMap.get(mapPrimaryKey).toString();
                        FocusConfig.getCurrentLogger().writeDebug("primary key from previous map  = "+ primaryMap);
                    }

                    // check the next record
                    previousDataMap = null;
                    ArrayList<OrderedInsensitiveMap> mapInputList = new ArrayList<OrderedInsensitiveMap>();
                    while (rs.next()) {
                        String nextPrimaryKey = rs.getString(1);
                        long groupByKeyValue = (Integer) rs.getInt(GroupByKey);
                        patientCount.add(groupByKeyValue);
                        //FocusConfig.getCurrentLogger().writeDebug("primary key " + primaryKey + ", next primaryKey =" + nextPrimaryKey);
                        if (!primaryKey.equalsIgnoreCase(nextPrimaryKey)) {
                            previousDataMap = DBUtil.getResulSetAsMap(rs, rsMetaData);
                            //rs.previous();
                            break;
                        } else {
                            mapInputList.add(DBUtil.getResulSetAsMap(rs, rsMetaData));
                        }
                    }

                    OrderedInsensitiveMap currentDataMap = getUpdatedRecord(primaryMap, mapInputList);
                    currentDataMapList.add(currentDataMap);
                    
                    if (connectFields != null && connectFields.length > 0) {
                        //if(primaryField != null && primaryField.length() > 0) {
                        
                        for (int count = 0; count <connectFields.length; count++) {
                            //dimensionKeyList.put((String)currentDataMap.get(primaryField), null);
                            List keyList = dimensionKeyList.get(count+1);
                            if (keyList == null) {
                                keyList = new ArrayList();
                                dimensionKeyList.put(count+1, keyList);
                            }
                            keyList.add(currentDataMap.get(connectFields[count]));
                            dynamicDimension = true;
                        }
                      
                    }
                } else {
                    break;
                }
            }
            
            // Update the dimensions for the given field
//            if (dimensionPrimaryKeyList.size() > 0 && (primaryField != null && primaryField.length() > 0) ) {
//                // System.out.println("Primary field is " + primaryField);
//                updateDimensionDetails(dimensionPrimaryKeyList, currentDataMapList);
//            }
            
            if (dynamicDimension) {
                updateDimensionDetails(dimensionKeyList, currentDataMapList);
            }
                
        } catch (SQLException ex)  {
            FocusConfig.getCurrentLogger().writeError("", ex);
            throw new FocusException("", ex);
        } 
        
        
        return result;
}
    
    
    private OrderedInsensitiveMap getUpdatedRecord(OrderedInsensitiveMap primaryMap, 
                                        ArrayList<OrderedInsensitiveMap> mapInputList) {
        
        OrderedInsensitiveMap updatedRecordMap = null;
        if (mapInputList != null && mapInputList.size() > 0) {
            // create a new map
            FocusConfig.getCurrentLogger().writeDebug("input map size =" + mapInputList.size());
            updatedRecordMap = new OrderedInsensitiveMap();
            
            MapIterator iterator = primaryMap.getMapIterator();
            while (iterator.hasNext()) {
                
                iterator.next();
                Object key = iterator.getKey();
                Object value = null;
                if (iterator.getValue() != null) {
                   // value = iterator.getValue().toString();
                    value = iterator.getValue();
                }
                
                // loop the input list to get an array list of values of columns that differ 
                // from the primary map
                for (int index=0; index < mapInputList.size(); index++) {
                    OrderedInsensitiveMap inputMap = mapInputList.get(index);
                    Object inputMapValue = null;
                    if (inputMap.get(key) != null) {
                        inputMapValue = inputMap.get(key);//.toString();
                    }
                    
                    // check if we need to create an array list
                    String keyString = key.toString();
                    if (columnsToCreateList!= null && columnsToCreateList.contains(keyString)) {
                        ArrayList listValues = null;
                        if (updatedRecordMap.containsKey(key)) {
                            //FocusConfig.getCurrentLogger().writeDebug("previous key =" + key.toString());
                            listValues = (ArrayList)updatedRecordMap.get(key);
                        } else {
                            listValues = new ArrayList();
                            listValues.add(value);
                            
                            // add to the map
                            updatedRecordMap.put(key, listValues);
                        }
                        listValues.add(inputMapValue);
                        //FocusConfig.getCurrentLogger().writeDebug("list keys count =" + listValues.size());
                    } else {
                        if (!updatedRecordMap.containsKey(key)) {
                            updatedRecordMap.put(key, value);
                        }
                    }
                }
            }
            
        } else {
            updatedRecordMap = primaryMap;
        }
        
        return updatedRecordMap;
    }

    @Override
    public List<OrderedInsensitiveMap> getCurrentData() throws FocusException {
        return currentDataMapList;
    }
    
    @Override
    public void stop()  throws FocusException {
        try  {
            DBUtil.closeAllObjects(con, stmt, rs);
        }   catch (SQLException ex){
            FocusConfig.getCurrentLogger().writeError(DBUtil.Error_failedtoclosedbresources, ex);
            throw new FocusException(DBUtil.Error_failedtoclosedbresources, ex);
        }
    }
    
    private void updateDimensionDetails(Map<Integer, List> dimensionKeyList,
                                                List<OrderedInsensitiveMap> listChunks) 
                                                                throws FocusException {
        
        FocusConfig.getCurrentLogger().writeInfo("Starting to update dynamic dimensions...");
        //1. Get the dimension details map for given dimension primary key list
        List<Map<String,String>> listDuplicateKeys = new ArrayList();
        ArrayList<OrderedInsensitiveMap> dimensionMapList = new ArrayList<OrderedInsensitiveMap>();
        for (int index=1; index <= dimensionKeyList.size(); index++ ) {
            List dimensionKeys = dimensionKeyList.get(index);
            OrderedInsensitiveMap dimensionDetailsMap = 
                    getDimensionDetails(dimensionViewDetails.get(index-1), 
                        connectFields[index-1], connectFieldType[index-1],this.dimensionCount[(index - 1)], dimensionKeys );
            dimensionMapList.add(dimensionDetailsMap);
            
            listDuplicateKeys.add(new HashMap<String,String>());
        }
            
        //2. Replace the dimension primary key with dimension details in the map
        for (OrderedInsensitiveMap map : listChunks) {
            
            for (int index = 0; index < dimensionMapList.size(); index++) {
                OrderedInsensitiveMap dimensionDetailsMap = (OrderedInsensitiveMap)dimensionMapList.get(index);
                String connectField = String.valueOf(map.get(this.connectFields[index]));// instanceOf String ? :);

                if (this.dimensionCount[index].equalsIgnoreCase("MULTIPLE")) {
                    List<OrderedInsensitiveMap> modifiedDimensionDetailsMapList = 
                            (List<OrderedInsensitiveMap>)dimensionDetailsMap.get(connectField);

                    if (modifiedDimensionDetailsMapList == null) {
                        modifiedDimensionDetailsMapList = new ArrayList();
                    }

                    for (OrderedInsensitiveMap modifiedDimensionDetailsMap : modifiedDimensionDetailsMapList) {
                        modifiedDimensionDetailsMap.remove(this.connectFields[index]);
                    }
                    
                    map.put(this.dimensionDetailString[index], modifiedDimensionDetailsMapList);
                }  else  {
                      OrderedInsensitiveMap modifiedDimensionDetailsMap = (OrderedInsensitiveMap)dimensionDetailsMap.get(connectField);

                      if (modifiedDimensionDetailsMap == null) {
                        modifiedDimensionDetailsMap = new OrderedInsensitiveMap();
                      }

                      Map mapDuplicateKeys = (Map)listDuplicateKeys.get(index);
                      if (mapDuplicateKeys.containsKey(connectField.toUpperCase())) {
                        OrderedInsensitiveMap tempDimensionDetailsMap = new OrderedInsensitiveMap();
                        tempDimensionDetailsMap.putAll(modifiedDimensionDetailsMap);
                        modifiedDimensionDetailsMap = tempDimensionDetailsMap;
                      }
                      mapDuplicateKeys.put(connectField, null);

                      modifiedDimensionDetailsMap.remove(this.connectFields[index]);
                      map.put(this.dimensionDetailString[index], modifiedDimensionDetailsMap);
                    }

                    map.remove(this.connectFields[index]);
              }
        }
        
        FocusConfig.getCurrentLogger().writeInfo("Completed updating dynamic dimensions");
    }


    private OrderedInsensitiveMap getDimensionDetails(AbstractView dimensionView, 
                                        String connectField, String connectFieldType, 
                                        String dimensionCount, List dimensionKeyList)
                                        throws FocusException   {
        Connection tempConnection = null;
        Statement dimensionStmt = null;
        ResultSet dimensionrs = null;
        OrderedInsensitiveMap dimensionData = new OrderedInsensitiveMap();
        try
        {
          if (dimensionView != null) {
            dimensionData = new OrderedInsensitiveMap();

            QueryBuilderFactory factory = QueryBuilderFactory.getInstance();
            QueryBuilderInterface dimensionQueryBuilder = factory.getQueryBuilderFromClassName(dimensionView.getClass().getName());

            ArrayList inputValues = new ArrayList();
            if(connectFieldType.equalsIgnoreCase("STRING_PROCEDURE")){
                List uniqueDimensionKeys = getUniqueDimensionKeys(dimensionKeyList);
                inputValues.add(uniqueDimensionKeys);
            }else{
            inputValues.add(new ArrayList(dimensionKeyList));
            }
            
            
            String dimensionQuery = dimensionQueryBuilder.getComplexQuery(dimensionView, this.defaultValues, connectFieldType, inputValues);

            FocusConfig.getCurrentLogger().writeDebug("Dimension query =" + dimensionQuery);

//            DBConfigInfo configInfo = getDBConfigInfo(); //FocusConfig.getCurrentInstance().getDataSourceConfig();
//            tempConnection = DBConnection.getConnection(configInfo);
//            dimensionStmt = DBUtil.getStatement(tempConnection, 60);
            tempConnection = dataSource.getConnection();
            dimensionStmt = DBUtil.getStatement(tempConnection, 60);
            dimensionrs = dimensionStmt.executeQuery(dimensionQuery);
            ResultSetMetaData dimensionrsMeta = dimensionrs.getMetaData();
            while (dimensionrs.next())
            {
              OrderedInsensitiveMap mapResultSet = DBUtil.getResulSetAsMap(dimensionrs, dimensionrsMeta);
              String dimensionKey = dimensionrs.getString(connectField);

              if (dimensionCount.equalsIgnoreCase("MULTIPLE")) {
                List mapResults = null;
                if (!dimensionData.containsKey(dimensionKey)) {
                  mapResults = new ArrayList();
                } else {
                  mapResults = (List)dimensionData.get(dimensionKey);
                }
                mapResults.add(mapResultSet);
                dimensionData.put(dimensionKey, mapResults);
                //System.out.println("dimension count for " + dimensionKey + " is " + mapResults.size());
              } else {
                dimensionData.put(dimensionKey, mapResultSet);
              }
            }
          }
        }
        catch (SQLException ex) {
          FocusConfig.getCurrentLogger().writeError("", ex);
          throw new FocusException("", ex);
//        } catch (ClassNotFoundException ex) {
//          FocusConfig.getCurrentLogger().writeError("", ex);
//          throw new FocusException("", ex);
        } finally {
          try {
            DBUtil.closeAllObjects(tempConnection, dimensionStmt, dimensionrs);
          } catch (SQLException ex) {
            FocusConfig.getCurrentLogger().writeError(DBUtil.Error_failedtoclosedbresources, ex);
            throw new FocusException(DBUtil.Error_failedtoclosedbresources, ex);
          }
        }
        return dimensionData;
  }

    protected DBConfigInfo getDBConfigInfo() {
        DBConfigInfo dbConfigInfo = null;
        //if datasource is available the get it else get analytics datasource
        if(dbConfig != null){
            dbConfigInfo = FocusConfig.getCurrentInstance().getDataSourceConfig(dbConfig);
        }else{
              dbConfigInfo = FocusConfig.getCurrentInstance().getDataSourceConfig();
        }
        return dbConfigInfo;
    }

    public static List getUniqueDimensionKeys(List dimensionKeyList) {
        HashMap<String, Integer> map = new HashMap<String, Integer>();
        for (Object key : dimensionKeyList) {
                map.put((String)key, 1);   
        }
        return new ArrayList(map.keySet());
    }
}
