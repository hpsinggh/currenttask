/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.measures.common.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 *
 * @author sathyaji.raja
 */
public class ViewDetailsQueryBuilder implements QueryBuilderInterface {
    
    private static String TableAlias = "TABLE";
    
    public ViewDetailsQueryBuilder() {
        
    }
    
    @Override
    public String getComplexQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    ArrayList inputValues) {
        
        ViewDetails vwDetails = (ViewDetails)argView;
        
        String defaultFields = buildDefaultFieldValues(defaultFieldValues);
        String fields = buildFields(vwDetails.getPrimaryTableDetails());
        FocusConfig.getCurrentLogger().writeDebug("primary table details = " + vwDetails.getPrimaryTableDetails().getName());
        FocusConfig.getCurrentLogger().writeDebug("fields = " + fields);
        if (defaultFields.length() > 0)
            fields = (defaultFields + "," + fields);
        FocusConfig.getCurrentLogger().writeDebug("fields before building query = "+ fields);
        
        String primaryJoin = vwDetails.getPrimaryTableDetails().getJoinCondition();
        String queryCondition = (primaryJoin != null && primaryJoin.length() > 0)? primaryJoin: "";
        FocusConfig.getCurrentLogger().writeDebug("query condition before formatting = "+ queryCondition);
        
        String query  = buildQuery(fields, vwDetails, queryCondition);
        FocusConfig.getCurrentLogger().writeDebug("query before formatting = "+ query);
        
        return QueryBuilderUtils.formatComplexQuery(query, inputValues);
    
       // return query;
    }
    
     @Override
    public String getQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    String[] inputValues) {
        
        ViewDetails vwDetails = (ViewDetails)argView;
        
        String defaultFields = buildDefaultFieldValues(defaultFieldValues);
        String fields = buildFields(vwDetails.getPrimaryTableDetails());
        FocusConfig.getCurrentLogger().writeDebug("primary table details = " + vwDetails.getPrimaryTableDetails().getName());
        FocusConfig.getCurrentLogger().writeDebug("fields = " + fields);
        if (defaultFields.length() > 0)
            fields = (defaultFields + "," + fields);
        FocusConfig.getCurrentLogger().writeDebug("fields before building query = "+ fields);
        
        String primaryJoin = vwDetails.getPrimaryTableDetails().getJoinCondition();
        String queryCondition = (primaryJoin != null && primaryJoin.length() > 0)? primaryJoin: "";
        FocusConfig.getCurrentLogger().writeDebug("query condition before formatting = "+ queryCondition);
        
        String query  = buildQuery(fields, vwDetails, queryCondition);
        FocusConfig.getCurrentLogger().writeDebug("query before formatting = "+ query);
        
        return QueryBuilderUtils.formatQuery(query, inputValues);
    
        //return query;
    }
    
    private static String buildFields(TableDetails primaryTable)    {
                
        StringBuilder sbFields = new StringBuilder(250);
                 
        
        // Get Fields for primary table
        UpdateFields(primaryTable, sbFields);
        
        FocusConfig.getCurrentLogger().writeDebug("primary table fields =  " + sbFields.toString());
        
        // Get fields for related tables
        ArrayList<TableDetails> relatedTables = primaryTable.getRelatedTableDetails();
        for (int index = 0; index < relatedTables.size(); index++)  {
            UpdateFields(relatedTables.get(index), sbFields);
        }

        // delete the last comma
        int count = sbFields.length();
        if (count > 0)
            sbFields.deleteCharAt(count-1);
       
        return sbFields.toString();
    }
    
    private static String buildDefaultFieldValues(ArrayList<DatabaseField> defaultFieldValues)  {
        String fieldValues = "";
        
        if (defaultFieldValues != null && defaultFieldValues.size() > 0)    {
            
            StringBuilder fields = new StringBuilder(512);
            for (int index = 0; index < defaultFieldValues.size(); index++) {
                DatabaseField field = defaultFieldValues.get(index);
                FieldType fieldType = field.getType();
                if (fieldType == FieldType.STRING)  {
                    fields.append("'");
                    fields.append(field.getName());
                    fields.append("'");
                } else  {
                    fields.append(field.getName());
                }
                    fields.append(" AS ");
                    fields.append(field.getAliasName());
                
                fields.append(",");
            }
            
            // delete the last comma
            int length = fields.length();
            if (length > 0)
                fields.deleteCharAt(length-1);
            
            fieldValues = fields.toString();
            FocusConfig.getCurrentLogger().writeDebug("default fields = " + fieldValues);
        }
        
        return fieldValues;
    }
    
    private static void UpdateFields(TableDetails instanceTable, StringBuilder sbFields)    {
        
            HashMap<String, DatabaseField> mapFields = instanceTable.getTableFields();
        
            String tableName = instanceTable.getAliasName();
            Iterator<String> mapKeys = mapFields.keySet().iterator();
            while (mapKeys.hasNext())   {
                DatabaseField instanceField = mapFields.get(mapKeys.next());
                
                // ADD THE DISTINCT CLAUSE IF PRESENT
                String actualFieldName = instanceField.getName();
                if (actualFieldName.startsWith("DISTINCT ")) {
                    actualFieldName = actualFieldName.substring(9);
                    sbFields.append("DISTINCT ");
                }
               
                // ADD THE FIELD NAME
                sbFields.append(tableName);
                sbFields.append(".");
                sbFields.append(actualFieldName.trim());

                // ADD THE ALIAS NAME
                sbFields.append(" AS ");
                sbFields.append(instanceField.getAliasName());
                sbFields.append(",");
            
            }
    }
    
//    public static String getQuery(DimensionDetails dimension) {
//        
//        AbstractView viewDetails = dimension.getViewDetails();
//        return buildQuery(dimension.getFields(), viewDetails, dimension.getQuery());
//    }
    
    private static String buildQuery(String fields, ViewDetails viewDetails, String queryCondition) {
        
        StringBuilder query = new StringBuilder(2000);

        query.append("SELECT ");
        query.append(fields);
        query.append(" FROM ");
        
        // add primary table
        TableDetails primaryTable = viewDetails.getPrimaryTableDetails();
        query.append(primaryTable.getName());
        String tableAliasName = primaryTable.getAliasName();
        if (tableAliasName != null && tableAliasName.length() > 0)
            query.append(" AS ").append(primaryTable.getAliasName());
        
       
        // Add join condition
        ArrayList<TableDetails> relatedTables = primaryTable.getRelatedTableDetails();
        if (relatedTables != null ) {
            for (int index = 0;index < relatedTables.size(); index++ )  {
                query.append(" JOIN ");
            
                TableDetails relatedTable = relatedTables.get(index);
                query.append(relatedTable.getName());

                
                String aliasName = relatedTable.getAliasName();
                if (aliasName != null && aliasName.length() > 0)
                    query.append(" AS ").append(aliasName);
                
                query.append(" ON ");
            
                query.append("(");
                query.append(relatedTable.getJoinCondition());
                query.append(")");
            }
        }
        
        // add where clause
        //String dimQuery  = queryCondition;//
        if (queryCondition != null && queryCondition.length() > 0)  {
            query.append (" WHERE ");
            query.append(queryCondition);
        } 
        
        return query.toString();
     }

    @Override
    public String getComplexQuery(AbstractView argView, ArrayList<DatabaseField> defaultFieldValues, String inputType, ArrayList inputValues) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
    
}
