/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.assessment.report.utility;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.FocusConfig;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.apache.poi.hssf.usermodel.HSSFFont;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.DataValidation;
import org.apache.poi.ss.usermodel.DataValidationConstraint;
import org.apache.poi.ss.usermodel.DataValidationHelper;
import org.apache.poi.ss.usermodel.Font;
import org.apache.poi.ss.usermodel.Name;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddressList;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

/**
 *
 * @author Ankur Gupta
 * @modifiedBy keshav.sharma change the generateHeaderRow method put a for loop
 * to get the header name on the basis of number of values in gridMap
 * @modifiedBy Niranjan[3/9/2018] - using SXSSFWorkbook to  load large datasets without OOM error (tested until 1.1L records, which loaded in 50secs)
 */
public class DataExporter {

    public static String DATA_NOT_AVAILABLE = "DATA IS NOT AVAILABLE";
    private static DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

    public static void createFile(List<OrderedInsensitiveMap> gridRowMap,
	    String outputFileName) throws Exception {
	// Create csv
	Workbook workbook = createWorkBook(gridRowMap);
	createFile(workbook, outputFileName);
    }

    public static void createFile(Workbook workbook, String outputFileName) throws IOException {
	FocusConfig.getCurrentLogger().writeDebug("Start: PQRSCSVDataWriter method: createFile()");

	FileOutputStream fop = null;
	File file;
	try {
	    file = new File(outputFileName);
	    fop = new FileOutputStream(file);
	    // if file doesnt exists, then create it
	    if (!file.exists()) {
		file.createNewFile();
	    } else {
		file.delete();
	    }

	    // Write to the output stream
	    workbook.write(fop);
	    // Flush the stream
	    fop.flush();
	} finally {
	    if (fop != null) {
		fop.close();
	    }
	}
	FocusConfig.getCurrentLogger().writeDebug("End: PQRSCSVDataWriter method: createFile()");
    }

    /**
     * This method will export data to excel
     *
     * @param gridRowMap
     * @param workBook
     *
     * @throws Exception
     */
    public static Workbook createWorkBook(List<OrderedInsensitiveMap> gridRowMap)
	    throws Exception {

	FocusConfig.getCurrentLogger().writeDebug("Start: DataExporter method: exportDataToExcel()");
	Workbook workbook = new SXSSFWorkbook(500); // keep 500 rows in memory, exceeding rows will be flushed to disk
	Sheet sheet = workbook.createSheet();
	if (gridRowMap != null && !gridRowMap.isEmpty()) {
	    generateHeaderRow(sheet, gridRowMap.get(0));
	} else {
	    Map<String, String> defaultRowMap = new HashMap();
	    defaultRowMap.put(DATA_NOT_AVAILABLE, DATA_NOT_AVAILABLE);
	    generateHeaderRow(sheet, defaultRowMap);
	}

	// Map to contain sheet name.
	Map<String, Sheet> hiddenSheetMap = new HashMap<String, Sheet>();
	// Map to contain Sheet and NamedCell
	Map<String, Name> nameCellMap = new HashMap<String, Name>();

	//create the cell style and set alignment of column
	CellStyle style = workbook.createCellStyle();
	style.setAlignment(CellStyle.ALIGN_LEFT);

	int rowNum = 1; // Excluding Header
	if (gridRowMap != null) {
	    for (Map<String, Object> rowObj : gridRowMap) {
		Row row = sheet.createRow(rowNum);

		int colNum = 0;
		for (Map.Entry<String, Object> col : rowObj.entrySet()) {

		    Cell cell = row.createCell(colNum);
		    cell.setCellStyle(style);

		    Object obj = col.getValue();
		    if (obj instanceof Date) {
			cell.setCellValue(dateFormat.format((Date) obj));
		    } else if (obj instanceof Boolean) {
			cell.setCellValue((Boolean) obj);
		    } else if (obj instanceof String) {
			cell.setCellValue((String) obj);
		    } else if (obj instanceof Double) {
			cell.setCellValue((Double) obj);
		    } else if (obj instanceof Integer) {
			cell.setCellValue((Integer) obj);
		    } else if (obj instanceof Float) {
			cell.setCellValue((Float) obj);
		    } else if (obj instanceof Long) {
			cell.setCellValue((Long) obj);
		    } else if (obj instanceof Collection) {
			// If obj is collection type which is arraylist. Create dropdown for that cell.

			// Create hidden sheet with unique name.
			String hiddenSheetName = "hiddenSheet" + colNum;
			Sheet hiddenSheet = null;
			boolean sheetExists = false;
			if (!hiddenSheetMap.isEmpty()) {
			    if (hiddenSheetMap.containsKey(hiddenSheetName)) {
				hiddenSheet = hiddenSheetMap.get(hiddenSheetName);
				sheetExists = true;
			    } else {
				hiddenSheet = workbook.createSheet(hiddenSheetName);
				hiddenSheetMap.put(hiddenSheetName, hiddenSheet);
			    }
			} else {
			    hiddenSheet = workbook.createSheet(hiddenSheetName);
			    hiddenSheetMap.put(hiddenSheetName, hiddenSheet);
			}

			// Create row for all values available in list.
			List<String> list = (ArrayList<String>) obj;
			if (!list.isEmpty()) {
			    if (!sheetExists) {
				for (int i = 0; i < list.size(); i++) {
				    String reason = list.get(i);
				    Row hiddenRow = hiddenSheet.createRow(i);
				    Cell hiddenCell = hiddenRow.createCell(0);
				    hiddenCell.setCellValue(reason);
				}
			    }
			    // Create cell and add hidden sheet to cell and add cell.
			    Name namedCell = null;
			    if (nameCellMap.containsKey(hiddenSheetName)) {
				namedCell = nameCellMap.get(hiddenSheetName);
			    } else {
				namedCell = workbook.createName();
				namedCell.setNameName(hiddenSheetName);
				nameCellMap.put(hiddenSheetName, namedCell);
			    }
			    namedCell.setRefersToFormula(hiddenSheetName + "!$A$1:$A$" + list.size());

			    if (rowNum == gridRowMap.size()) { //add Validation only when the last row is reached
				DataValidationHelper validationHelper = hiddenSheet.getDataValidationHelper();
				DataValidationConstraint dvConstraint = validationHelper.createFormulaListConstraint(hiddenSheetName);
				CellRangeAddressList addressList = new CellRangeAddressList(1, rowNum, colNum, colNum); //The constraint is applicable to all the Rows of the current column
				DataValidation dataValidation = validationHelper.createValidation(dvConstraint, addressList);
				dataValidation.setSuppressDropDownArrow(true);
				// dataValidation.setShowErrorBox(false);
				// Hide hidden sheet

				// workbook.setSheetHidden(1, true);
				sheet.addValidationData(dataValidation);
			    }
			    // Set list 0th index value to cell.
			    cell.setCellValue(list.get(0));
			}

		    }
		    colNum++;
		}
		rowNum++;
	    }
	}

	//hide HiddenSheets
	for (Sheet hiddenSheet : hiddenSheetMap.values()) {
	    workbook.setSheetHidden(workbook.getSheetIndex(hiddenSheet), true);
	}

	// Write to reponse stream
	//writeReportToResponseStream(response, workbook, outputFileName);
	FocusConfig.getCurrentLogger().writeDebug("End: DataExporter method: exportDataToExcel()");
	return workbook;
    }

    /**
     * This method will generate header row
     *
     * @param sheet
     * @param gridRowMap
     */
    private static void generateHeaderRow(Sheet sheet, Map<String, String> gridRowMap) {
	//create the cell style and set alignment of column
	CellStyle style = sheet.getWorkbook().createCellStyle();
	style.setAlignment(CellStyle.ALIGN_CENTER);

	Font boldFont = sheet.getWorkbook().createFont();
	boldFont.setBoldweight(HSSFFont.BOLDWEIGHT_BOLD);
	style.setFont(boldFont);

	int colNum = 0;
	Row headerRow = sheet.createRow(0);

	for (String key : gridRowMap.keySet()) {
	    Cell headerCell = headerRow.createCell(colNum++);

	    //if data is not available changing alignment to Left & autosizing column width
	    //, to make cell value visible
	    if (key.equalsIgnoreCase(DATA_NOT_AVAILABLE)) {
		style.setAlignment(CellStyle.ALIGN_LEFT);
		sheet.autoSizeColumn(headerCell.getColumnIndex());
	    }

	    headerCell.setCellStyle(style);
	    headerCell.setCellValue(key);
	}
    }

}
