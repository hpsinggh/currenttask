/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import org.joda.time.DateMidnight;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.joda.time.Months;
import org.joda.time.Period;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;

/**
 *
 * @author sathyaji.raja
 */
/**
 * Changes made : added getDuration method
 * @author ramya.khasnis
 * Date: 01/07/2014
 */
/**
 * Changes made : added getNumberofMonths & getNumberofWeeks method
 * @author ankur.gupta
 * Date: 10/10/2015
 */
// Sathya: Don't define static funtions in this class. Use DateUtils.
public class DateTimeUtils {

	DateTimeFormatter dateTime24HourFormat = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
	private DateTimeFormatter defaultFormat;
	private SimpleDateFormat smFormat;

	private static double DAYSPERMONTH = 366.0 / (double) 12.0;

	public DateTimeUtils(String dateFormat) {
		defaultFormat = DateTimeFormat.forPattern(dateFormat);
		smFormat = new SimpleDateFormat(dateFormat);
	}

	public long getMonthKey(String startDateString) {

		long monthKey = -1;
		//String startDateString = smFormat.format(startDate);//startDate.toString();
		if (startDateString != null) {
			DateTime tempDate = DateTime.parse(startDateString, defaultFormat);
			int month = tempDate.getMonthOfYear();
			if (month > 9) {
				monthKey = tempDate.getYear() * 100 + month;
			} else {
				String paddedMonthKey = org.apache.commons.lang.StringUtils.leftPad(String.valueOf(month), 2, '0');
				//System.out.println("padded month key =" + paddedMonthKey);
				String monthkeyString = String.valueOf(tempDate.getYear()) + paddedMonthKey;
				monthKey = Long.parseLong(monthkeyString);
			}
		}
		return monthKey;
	}

	public long getFiscalYearKey(String startDateString) {
		if (startDateString != null) {
			DateTime tempDate = DateTime.parse(startDateString, defaultFormat);

			long year = tempDate.getYear();
			if (tempDate.getMonthOfYear() > 9) {
				return year++;
			} else {
				return year;
			}
		}
		return -1;
	}

	public long getQuarterKey(String startDateString) {
		if (startDateString != null) {
			return com.spectramd.products.focus.measures.utils.DateUtils.getQuarterKey(DateTime.parse(startDateString, defaultFormat).toDate());
		}
		return -1;
	}

	public long getWeekKey(String startDateString) {

		if (startDateString != null) {
			DateTime tempDate = DateTime.parse(startDateString, defaultFormat);

			// 1. Get the first date in the year and find the day
			DateTime firstDateofYear = new DateTime(tempDate.getYear(), 1, 1, 0, 1);
			int dayofFirstDayYear = firstDateofYear.getDayOfYear();

			// this is the sunday of the first week
			DateTime lastDateofFirstWeek = new DateTime(tempDate.getYear(), 1, 7 - dayofFirstDayYear + 1, 0, 1);

			int numberOfDays = getDays(lastDateofFirstWeek, tempDate);
			int numberofWeeks = numberOfDays / 7 + ((7 - dayofFirstDayYear + 1) > 0 ? 1 : 0) + (numberOfDays % 7 > 0 ? 1 : 0);
//         System.out.println("number of weeks = " + numberofWeeks + " "+ (numberOfDays%7 > 0 ? 1: 0)
//                                + " " + ((7-dayofFirstDayYear+1) > 0 ?1:0)  );

			long weekKey = -1;
			if (numberofWeeks > 9) {
				weekKey = tempDate.getYear() * 100 + numberofWeeks;
			} else {
				String paddedWeekKey = org.apache.commons.lang.StringUtils.leftPad(String.valueOf(numberofWeeks), 2, '0');
//             System.out.println("padded month key =" + paddedMonthKey);
				String monthkeyString = String.valueOf(tempDate.getYear()) + paddedWeekKey;
				weekKey = Long.parseLong(monthkeyString);
			}

			return weekKey;
		}
		return -1;
	}

	/**
	 * Returns the number of days b/w 2 dates. The 2nd argument should be greater for a positive result.
	 * [SUMIT] Changed from Days.daysBetween to Hours.hoursBetween / 24 to get decimal data
	 *
	 * @param startDateString String
	 * @param endDateString String
	 * @return double
	 */
	public final double getNumberofDays(final String startDateString, final String endDateString) {

		DateTime startDate = DateTime.parse(startDateString, defaultFormat);
		DateTime endDate = DateTime.parse(endDateString, defaultFormat);

		return getHours(startDate.toDateMidnight(), endDate.toDateMidnight()) / (double) 24;
	}

	public long getNumberofHours(String argStartDate, String startTime,
			String argEndDate, String endTime) {
		return (long) (getNumberofMinutes(argStartDate, startTime, argEndDate, endTime) / 60);
	}

	public long getNumberofMinutes(String startDateTime, String endDateTime, String inputformat) {

		if (startDateTime == null || endDateTime == null) {
			return -1;
		}
		DateTimeFormatter format = DateTimeFormat.forPattern(inputformat);
		DateTime startDate = DateTime.parse(startDateTime, format);
		DateTime endDate = DateTime.parse(endDateTime, format);

		return getMinutes(startDate, endDate);
	}

	public long getNumberofMinutes(String argStartDate, String startTime, String argEndDate, String endTime) {

		StringBuilder tempStart = new StringBuilder(argStartDate.trim());
		if (argStartDate.trim().length() == 10) { // it is yyyy-MM-dd
			tempStart.append(" 00:00:00");
		}
		tempStart.replace(11, 16, startTime);

		StringBuilder tempEnd = new StringBuilder(argEndDate.trim());
		if (argEndDate.trim().length() == 10) { // it is yyyy-MM-dd
			tempEnd.append(" 00:00:00");
		}
		tempEnd.replace(11, 16, endTime);
		DateTime startDate = DateTime.parse(tempStart.toString(), dateTime24HourFormat);
		DateTime endDate = DateTime.parse(tempEnd.toString(), dateTime24HourFormat);

		return getMinutes(startDate, endDate);
	}

	/**
	 * Returns the number of years b/w 2 dates. The 2nd argument should be
	 * greater for a positive result. [SUMIT] Changed from Years.yearsBetween to
	 * Months.monthsBetween / 12 to get decimal data
	 *
	 * @param startDateString String
	 * @param endDateString String
	 * @return double
	 */
	public final double getNumberofYears(String startDateString, String endDateString) {
		try {
			//double numberofDays = getNumberofDays(startDateString, endDateString);

			Date first = smFormat.parse(startDateString);
			Date last = smFormat.parse(endDateString);
			return getNumberofYearsGivenDate(first, last);
		} catch (ParseException ex) {
			//nothing
		}
		return -1;
	}
	
	public final double getNumberofYearsGivenDate(Date first, Date last) {

        Calendar a = getCalendar(first);
        Calendar b = getCalendar(last);
        double fractionPart = 0.0;
        double diffYears = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);

        // Reduce years by one
        if (a.get(Calendar.MONTH) > b.get(Calendar.MONTH)
                || (a.get(Calendar.MONTH) == b.get(Calendar.MONTH) && a.get(Calendar.DATE) > b.get(Calendar.DATE))) {
            diffYears--;
        }

        // Calculate Fraction Part DAYSPERMONTH
        if (a.get(Calendar.MONTH) == b.get(Calendar.MONTH)) {
            if (a.get(Calendar.DATE) > b.get(Calendar.DATE)) {
                fractionPart = 366.0 - a.get(Calendar.DATE) - 1;
                // System.out.println("Number of days1 = " + fractionPart );
            } else if (a.get(Calendar.DATE) < b.get(Calendar.DATE)) {
                fractionPart = b.get(Calendar.DATE) - a.get(Calendar.DATE);
                //  System.out.println("Number of days2 = " + fractionPart);
            } else if (a.get(Calendar.DATE) == b.get(Calendar.DATE)) {
                if (a.get(Calendar.HOUR_OF_DAY) > b.get(Calendar.HOUR_OF_DAY)) {
                    fractionPart = (a.get(Calendar.HOUR_OF_DAY) - b.get(Calendar.HOUR_OF_DAY)) / DAYSPERMONTH;
                } else if (a.get(Calendar.HOUR_OF_DAY) < b.get(Calendar.HOUR_OF_DAY)) {
                    fractionPart = (b.get(Calendar.HOUR_OF_DAY) - a.get(Calendar.HOUR_OF_DAY)) / DAYSPERMONTH;
                } else if (a.get(Calendar.HOUR_OF_DAY) == b.get(Calendar.HOUR_OF_DAY)) {
                    if (b.get(Calendar.MINUTE) > a.get(Calendar.MINUTE)) {
                        fractionPart = (((b.get(Calendar.MINUTE) - a.get(Calendar.MINUTE)))) / (DAYSPERMONTH * 60);
                    } else if (b.get(Calendar.MINUTE) < a.get(Calendar.MINUTE)) {
                        fractionPart = (((a.get(Calendar.MINUTE) - b.get(Calendar.MINUTE)))) / (DAYSPERMONTH * 60);
                    } else {
                        if (b.get(Calendar.MINUTE) == a.get(Calendar.MINUTE)) {
                            if (b.get(Calendar.SECOND) > a.get(Calendar.SECOND)) {
                                fractionPart = (((b.get(Calendar.SECOND) - a.get(Calendar.SECOND)))) / (DAYSPERMONTH * 60 * 60);
                            } else {
                                fractionPart = (((a.get(Calendar.SECOND) - b.get(Calendar.SECOND)))) / (DAYSPERMONTH * 60 * 60);
                            }
                        }
                    }
                }
            }
        } else if (a.get(Calendar.MONTH) >= b.get(Calendar.MONTH)) {
            fractionPart = (12 - a.get(Calendar.MONTH) + b.get(Calendar.MONTH) - 1) * DAYSPERMONTH
                    + (DAYSPERMONTH - a.get(Calendar.DATE) + b.get(Calendar.DATE));
            //System.out.println("Number of months1 = " + (12- a.get(Calendar.MONTH) + b.get(Calendar.MONTH) -1));
        } else {
            fractionPart = (b.get(Calendar.MONTH) - a.get(Calendar.MONTH) - 1) * DAYSPERMONTH
                    + DAYSPERMONTH - b.get(Calendar.DATE) + a.get(Calendar.DATE);
            //System.out.println("Number of months2 = " + (b.get(Calendar.MONTH) - a.get(Calendar.MONTH) -1));
        }

        return diffYears + fractionPart / 366.0;
    }

/*
	public final double getNumberofYearsGivenDate(Date first, Date last) {

		Calendar a = getCalendar(first);
		Calendar b = getCalendar(last);
		double fractionPart = 0.0;
		double diffYears = b.get(Calendar.YEAR) - a.get(Calendar.YEAR);

		// Reduce years by one
		if (a.get(Calendar.MONTH) > b.get(Calendar.MONTH)
				|| (a.get(Calendar.MONTH) == b.get(Calendar.MONTH) && a.get(Calendar.DATE) > b.get(Calendar.DATE))) {
			diffYears--;
		}

		// Calculate Fraction Part DAYSPERMONTH
		if (a.get(Calendar.MONTH) == b.get(Calendar.MONTH)) {
			if (a.get(Calendar.DATE) > b.get(Calendar.DATE)) {
				fractionPart = 366.0 - a.get(Calendar.DATE) - 1;
				// System.out.println("Number of days1 = " + fractionPart );
			} else {
				fractionPart = b.get(Calendar.DATE) - a.get(Calendar.DATE);
				//  System.out.println("Number of days2 = " + fractionPart);
			}
		} else if (a.get(Calendar.MONTH) >= b.get(Calendar.MONTH)) {
			fractionPart = (12 - a.get(Calendar.MONTH) + b.get(Calendar.MONTH) - 1) * DAYSPERMONTH
					+ (DAYSPERMONTH - a.get(Calendar.DATE) + b.get(Calendar.DATE));
			//System.out.println("Number of months1 = " + (12- a.get(Calendar.MONTH) + b.get(Calendar.MONTH) -1));
		} else {
			fractionPart = (b.get(Calendar.MONTH) - a.get(Calendar.MONTH) - 1) * DAYSPERMONTH
					+ DAYSPERMONTH - b.get(Calendar.DATE) + a.get(Calendar.DATE);
			//System.out.println("Number of months2 = " + (b.get(Calendar.MONTH) - a.get(Calendar.MONTH) -1));
		}

		return diffYears + fractionPart / 366.0;
	}
	*/

	private static Calendar getCalendar(Date date) {
		Calendar cal = Calendar.getInstance(Locale.US);
		cal.setTime(date);
		return cal;
	}

	/**
	 * Returns the number of months between 2 dates.
	 *
	 * @param endDateString String
	 * @param startDateString String
	 * @return
	 */
	public long getNumberofMonths(final String startDateString, final String endDateString) {

		DateTime startDate = DateTime.parse(startDateString, defaultFormat);
		DateTime endDate = DateTime.parse(endDateString, defaultFormat);

		return Months.monthsBetween(startDate, endDate).getMonths();
	}

	/**
	 * Returns the number of weeks between 2 dates.
	 * @param endDateString String
	 * @param startDateString String
	 * @return
	 */
	public long getNumberofWeeks(String startDateString, String endDateString) {
		DateTime startDate = DateTime.parse(startDateString, defaultFormat);
		DateTime endDate = DateTime.parse(endDateString, defaultFormat);

		return getDays(startDate, endDate) / 7;
	}

	/**
	 * Adds years to the date and returns the new date.
	 *
	 * @param date
	 * @param years
	 * @return
	 */
	public Date addYears(Date date, int years) {
		if (date != null) {
			Calendar calendar = Calendar.getInstance();
			calendar.setTime(date);
			calendar.add(Calendar.YEAR, years);
			return calendar.getTime();
		}
		return null;
	}

	/**
	 * Get year key from the datekey
	 *
	 * @param dateKey - date is in form of yyyyMMdd
	 * @return yearKey
	 */
	public long getYearKey(long dateKey) {
		long year = -1;
		try {
			SimpleDateFormat dateKeyFormat = new SimpleDateFormat("yyyyMMdd");
			Date date = dateKeyFormat.parse(String.valueOf(dateKey));

			SimpleDateFormat yearFormat = new SimpleDateFormat("yyyy");
			year = new Long(yearFormat.format(date));
		} catch (Exception e) {
			year = -1;
		}
		return year;
	}

	public Date getDateWithStartOfDayTimestamp(long dateKey) {
		Calendar calender = Calendar.getInstance();
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		try {
			Date date = df.parse(String.valueOf(dateKey));
			calender.setTime(date);
			//calender.set(Calendar.SECOND, 01);
			//calender.set(Calendar.MILLISECOND, 999);
		} catch (ParseException e) {
			// do nothing
		}
		return calender.getTime();
	}

	public Date getDateWithEndOfDayTimestamp(long dateKey) {
		Calendar calender = Calendar.getInstance();
		DateFormat df = new SimpleDateFormat("yyyyMMdd");
		try {
			Date date = df.parse(String.valueOf(dateKey));
			calender.setTime(date);
			calender.set(Calendar.HOUR_OF_DAY, 23);
			calender.set(Calendar.MINUTE, 59);
			calender.set(Calendar.SECOND, 59);
			calender.set(Calendar.MILLISECOND, 0);
		} catch (ParseException e) {
			// do nothing
		}
		return calender.getTime();
	}

	/**
	 * This method is used to convert String Date to timestamp
	 *
	 * @param date InputDate to convert to Timestamp
	 * @return Timestamp SQLTimestamp of java Date
	 */
	public Timestamp getTimeStamp(Object date) {
		java.sql.Timestamp timestamp = null;
		try {
			if (date != null) {
				timestamp = new java.sql.Timestamp(smFormat.parse((String) date).getTime());
			}
		} catch (Exception e) {
			//do Nothing
		}
		return timestamp;
	}

	public long getDateValue(String startDateString) {

		DateTime startDate = DateTime.parse(startDateString, defaultFormat);

		long result = startDate.getMillis();
		return result;
	}

	/**
	 * Add months to month and days to given date
	 * @param dateString
	 * @param months
	 * @param days
	 * @return date
	 */
	public String addMonths(String dateString, int months, int days) {
		try {
			if (dateString != null) {
				Calendar calendar = Calendar.getInstance();
				Date startDate = smFormat.parse(dateString);
				calendar.setTime(startDate);
				//calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + months, days);
				calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + months, days, 00, 00, 01);
				return smFormat.format(calendar.getTime());
			}
		} catch (Exception e) {
		}
		return null;
	}

	public String addMonthsTillEndofDay(String dateString, int months, int days) {
		try {
			if (dateString != null) {
				Calendar calendar = Calendar.getInstance();
				Date startDate = smFormat.parse(dateString);
				calendar.setTime(startDate);
				calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH) + months, days, 23, 59, 59);
				return smFormat.format(calendar.getTime());
			}
		} catch (Exception e) {
		}
		return null;
	}

	/**
	 * Add days to given date
	 * @param dateString
	 * @param months
	 * @param days
	 * @return date
	 */
	public String addDays(String dateString, int days) {
		try {
			if (dateString != null) {
				Calendar calendar = Calendar.getInstance();
				Date startDate = smFormat.parse(dateString);
				calendar.setTime(startDate);
				calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE) + days, 00, 00, 01);
				return smFormat.format(calendar.getTime());
			}
		} catch (Exception e) {
		}
		return null;
	}

	public String addDaysTillEndofDay(String dateString, int days) {
		try {
			if (dateString != null) {
				Calendar calendar = Calendar.getInstance();
				Date startDate = smFormat.parse(dateString);
				calendar.setTime(startDate);
				calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH),
						calendar.get(Calendar.DATE) + days, 23, 59, 59);
				return smFormat.format(calendar.getTime());
			}
		} catch (Exception e) {
		}
		return null;
	}

	/**
	 * Add seconds to given date
	 * @param dateString
	 * @param months
	 * @param seoonds
	 * @return date
	 */
	public String addSeconds(String dateString, int seconds) {
		try {
			if (dateString != null) {
				Calendar calendar = Calendar.getInstance();
				Date startDate = smFormat.parse(dateString);
				calendar.setTime(startDate);
				calendar.set(calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DATE),
						calendar.get(Calendar.HOUR), calendar.get(Calendar.MINUTE), calendar.get(Calendar.HOUR) + seconds);
				return smFormat.format(calendar.getTime());
			}
		} catch (Exception e) {
		}
		return null;
	}

	/**
	 * Returns the number of days between the 2 dates.
	 * @param startDate DateTime
	 * @param endDate DateTime
	 * @return int
	 */
	private static int getDays(final DateTime startDate, final DateTime endDate) {
		Period period = new Period(startDate, endDate);
		Duration duration = period.toDurationFrom(new DateTime());
		return duration.toStandardDays().getDays();
	}

	/**
	 * Returns the number of hours between the 2 dates.
	 * @param startDate DateMidnight
	 * @param endDate DateMidnight
	 * @return long
	 */
	private static int getHours(final DateMidnight startDate, final DateMidnight endDate) {
		Period period = new Period(startDate, endDate);
		Duration duration = period.toDurationFrom(new DateTime());
		return duration.toStandardHours().getHours();
	}

	/**
	 * Returns the number of minutes between the 2 dates.
	 * @param startDate DateTime
	 * @param endDate DateTime
	 * @return long
	 */
	private static long getMinutes(final DateTime startDate, final DateTime endDate) {
		Period period = new Period(startDate, endDate);
		Duration duration = period.toDurationFrom(new DateTime());
		return duration.toStandardMinutes().getMinutes();
	}
}
