/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.measures.common.FieldDetails;
import com.spectramd.products.focus.measures.common.FieldType;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;

/**
 *
 * @author sathyaji.raja
 */
public class FieldValueEvaluator {

    public FieldValueEvaluator() {
        
    }
    
    public static Object Evaluate(FieldDetails details, 
                                    ExpressionParser PARSER, EvaluationContext tempContext) {
        
        Object returnValue = null;
        
        Expression exp = PARSER.parseExpression(details.Value);
        if (details.Type == FieldType.STRING) {
            returnValue = exp.getValue(tempContext, String.class);
        } else if (details.Type == FieldType.INT) {
            returnValue = exp.getValue(tempContext, Integer.class);
        } else if (details.Type == FieldType.BIGINT) {
            returnValue = exp.getValue(tempContext, Long.class);
		} else if (details.Type == FieldType.DECIMAL) {
			returnValue = exp.getValue(tempContext, Double.class);
        } else if (details.Type == FieldType.BOOLEAN) {
            returnValue = exp.getValue(tempContext, boolean.class);
        } else if (details.Type == FieldType.LIST) {
            returnValue = exp.getValue(tempContext, List.class);
        } else if (details.Type == FieldType.MAP) {
            returnValue = exp.getValue(tempContext, HashMap.class);
        } else if (details.Type == FieldType.DATE) {
            returnValue = exp.getValue(tempContext, Date.class);
        }else if (details.Type == FieldType.VOID) {
            exp.getValue(tempContext, Object.class);
        }
        
        return returnValue;
     }

    
}
