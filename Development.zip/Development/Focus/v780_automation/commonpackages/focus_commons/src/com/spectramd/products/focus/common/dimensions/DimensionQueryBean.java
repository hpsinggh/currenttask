/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.dimensions;

/**
 *
 * @author siraj.m
 */
public class DimensionQueryBean {
 
	/**
	 * Query String.
	 */
    private String query;
    
	/**
	 *
	 * @return String.
	 */
    public String getQuery() {
        return query;
    }

	/**
	 *
	 * @param query String.
	 */
	public void setQuery(final String query) {
        this.query = query;
    }
}
