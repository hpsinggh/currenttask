/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import java.sql.SQLException;
import java.util.EventListener;

/**
 *
 * @author sathyaji.raja
 */
public interface ResultSetEvent extends EventListener   {

    public void resultSetMoved(ResultSetEventObject eventObject) throws SQLException;
}
