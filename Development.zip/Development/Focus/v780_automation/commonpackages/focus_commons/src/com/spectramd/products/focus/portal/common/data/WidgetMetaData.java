/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.portal.common.data;

/**
 *
 * @author sathyaji.raja
 */
public abstract class WidgetMetaData extends WidgetContainerData {
    
}
