/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

/**
 *
 * @author sathyaji.raja
 */
public class GenericUtils {
    
    public static boolean isNotNull(Object[] params) {
       boolean isNotNull = false;
        if (params != null && params.length > 0) {
            //isNotNull = true;

            for (Object param : params) {
                if (param != null ) {
                    isNotNull = true;
                    break;
                }
            }
  
        }
       
       return isNotNull;
    }
    
}
