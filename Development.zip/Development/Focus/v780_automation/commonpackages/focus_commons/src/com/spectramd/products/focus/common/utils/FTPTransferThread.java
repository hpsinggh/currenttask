/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusLogger;
import java.io.File;

/**
 *
 * @author smoghul
 */
public class FTPTransferThread implements Runnable {
    
    private FTPInfo ftpInfo;
    private String inputFile;
    private String encryptFilePath;
    
    public FTPTransferThread(FTPInfo ftpInfo, String inputFile, String encryptFilePath){
        this.ftpInfo = ftpInfo;
        this.inputFile = inputFile;
        this.encryptFilePath = encryptFilePath;
    }
    
    
    @Override
    public void run() {
        
        try{
            //Thread.sleep(1000);
            FTPUtils.uploadFile(ftpInfo, inputFile, encryptFilePath);
            
            File file = new File(encryptFilePath);
            if(file.exists()){
                file.delete();
            }
        }
        catch (Exception e){
            FocusConfig.getCurrentLogger().writeError("Exception in FTPTransferUtil",e);
        }
    }
    

}
