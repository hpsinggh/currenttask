/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.measures.common.FieldDetails;
import com.spectramd.products.focus.measures.common.FieldDetailsList;
import com.spectramd.products.focus.measures.common.FieldQualifier;
import com.spectramd.products.focus.measures.common.FieldType;
import com.spectramd.products.focus.measures.utils.DateUtils;
import java.util.Date;
import java.util.List;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;

/**
 *
 * @author sathyaji.raja
 */
public class ExpressionContext {
    
	/**
	 * Contect to register all functions.
	 */
    private StandardEvaluationContext context = null;
	/**
	 * ExpressionParser.
	 */
	private ExpressionParser parser = new SpelExpressionParser();
    
	/**
	 * Default Constructor.
	 * @throws NoSuchMethodException on error
	 */
    public ExpressionContext()  throws NoSuchMethodException {
        context = new StandardEvaluationContext();
        registerFunctions();
    }
    
	/**
	 * Register all functions to the context for evaluating expressions.
	 * @throws NoSuchMethodException on error
	 */
    private void registerFunctions() throws NoSuchMethodException    {
        context.registerFunction("divide", 
                    MathUtils.class.getMethod("getDivisionResult", long.class, long.class));
        context.registerFunction("round", 
                    MathUtils.class.getMethod("round", double.class));
        
        context.registerFunction("cal_consistency_score", 
                                    ConsistencyScoreCalculator.class.getMethod("getConsistencyScore", 
                                                        List.class,List.class,List.class));
        
        // Added for coremeasure grid header
        context.registerFunction("currentQuarterKey", 
                                    DateUtils.class.getMethod("getCurrentQuarterKeyLong"));
        context.registerFunction("measureQuarterKey", 
                                    ProgramMeasureUtils.class.getMethod("getMeasureQuarterKey", 
                                                        Long.class,Long.class,Long.class));
        context.registerFunction("quarterFormat", 
                                    FormatUtils.class.getMethod("getQuarterString", Long.class));
        
        context.registerFunction("days", 
                DateUtils.class.getDeclaredMethod("getNumberofDays", String.class, String.class, String.class));
        context.registerFunction("format", 
                DateUtils.class.getMethod("format", Date.class,String.class));
         context.registerFunction("calculateMedianValue", 
                MedianMeasureUtils.class.getMethod("calculateMedianValue", List.class));

    }
    
	/**
	 * Used to add dynamic parameters in expressions.
	 * @param valueMap OrderedInsensitiveMap
	 */
	public final void setValue(final OrderedInsensitiveMap valueMap) {
        // Add the value map in the context
        context.setVariable("value", valueMap);
    }
    
	/**
	 * Evaluates the provided expression.
	 * @param expression String
	 * @return String
	 */
	public final String evaluateString(final String expression) {
        return evaluateInternal(expression, FieldType.STRING).toString();
    }
    
	/**
	 * Evaluates the provided expression.
	 * [Sumit] Passed Wrapper classes to getValue function to support NULLs being returned from expressions.
	 *
	 * @param expression String
	 * @param type FieldType
	 * @return String
	 */
	private Object evaluateInternal(final String expression, final FieldType type) {
        Object returnValue = null;
        Expression exp = parser.parseExpression(expression);
        //System.out.println("expression parsed");
        if (type == FieldType.STRING) {
            returnValue = exp.getValue(context, String.class);
            //System.out.println("expression evaluated to"+ returnValue );
        } else if (type == FieldType.INT) {
			returnValue = exp.getValue(context, Integer.class);
        } else if (type == FieldType.BIGINT) {
			returnValue = exp.getValue(context, Long.class);
        } else if (type == FieldType.BOOLEAN) {
			returnValue = exp.getValue(context, Boolean.class);
        } else if (type == FieldType.DECIMAL) {
            Double tempReturnValue = (Double)exp.getValue(context, Double.class);
            if (tempReturnValue.isNaN()) {
                tempReturnValue = null;
            }
            returnValue = tempReturnValue;
        }
        return returnValue;
    }
    
	/**
	 * Evaluates the provided expression.
	 * @param details FieldDetails
	 * @return Object
	 */
	public final Object evaluate(final FieldDetails details) {
        return evaluateInternal(details.getValue(), details.getType());
     }
    
	/**
	 * Evaluates the provided expression.
	 * @param detailsList FieldDetailsList
	 * @return Object
	 */
	public final Object evaluate(final FieldDetailsList detailsList) {
    
        //Evaluating the TEMP FIELDS 
        for(FieldDetails fieldDetails : detailsList){
            if(fieldDetails.Qualifier.equals(FieldQualifier.TEMP)){
                // Evaluate Temp Fields
                evaluateTempFields(fieldDetails);
            }
        }

        //Evaluating the PERM FIELDS 
        Object returnValue = null;
        for(FieldDetails fieldDetails : detailsList){
            if(fieldDetails.Qualifier.equals(FieldQualifier.PERM)){
                returnValue = evaluate(fieldDetails);
                break;
            }
        }
        
        FocusConfig.getCurrentLogger().writeDebug("expr result is " + returnValue);
        return returnValue;
    }
    
	/**
	 * Evaluates the provided expression and adds result to the context.
	 * @param detailsList FieldDetailsList
	 * @return Object
	 */
	public final Object evaluateUpdateContext(final FieldDetailsList detailsList) {
    
        //Evaluating the TEMP FIELDS 
        for(FieldDetails fieldDetails : detailsList){
            if(fieldDetails.Qualifier.equals(FieldQualifier.TEMP)){
                // Evaluate Temp Fields
                evaluateTempFields(fieldDetails);
            }
        }

        //Evaluating the PERM FIELDS 
        OrderedInsensitiveMap mapValue = (OrderedInsensitiveMap)context.lookupVariable("value");
        Object returnValue = null;
        for(FieldDetails fieldDetails : detailsList){
            if(fieldDetails.Qualifier.equals(FieldQualifier.PERM)){
                Object evaluationValue = evaluate(fieldDetails);
                mapValue.put(fieldDetails.getResultFieldName(), evaluationValue);
				FocusConfig.getCurrentLogger().writeDebug("expr result is FOR " + fieldDetails.getResultFieldName()
						+ " IS " + returnValue);
                returnValue = evaluationValue;
            }
        }
        
        FocusConfig.getCurrentLogger().writeDebug("expr result is " + returnValue);
        return returnValue;
    }
    
	/**
	 *
	 * @param fieldDetails FieldDetails.
	 */
	private void evaluateTempFields(final FieldDetails fieldDetails) {
    
        OrderedInsensitiveMap mapValue = (OrderedInsensitiveMap)context.lookupVariable("value");
        if(mapValue == null){
            mapValue = new OrderedInsensitiveMap();
        }
        
        Object resultValue = evaluate(fieldDetails);
        mapValue.put(fieldDetails.ResultFieldName,resultValue);
		FocusConfig.getCurrentLogger().writeDebug("temp expr result for " + fieldDetails.ResultFieldName + " is "
				+ resultValue);
        context.setVariable("value",mapValue);
    }
}
