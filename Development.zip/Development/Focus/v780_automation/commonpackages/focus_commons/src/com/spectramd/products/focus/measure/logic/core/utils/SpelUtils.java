/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import java.lang.reflect.Method;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.spel.support.StandardEvaluationContext;

/**
 *
 * @author sathyaji.raja
 */
public final class SpelUtils {
    
    public static EvaluationContext CreateEvaluationContext(OrderedInsensitiveMap valueMap, OrderedInsensitiveMap tempValueMap) throws NoSuchMethodException {
        StandardEvaluationContext context = new StandardEvaluationContext();
        
        // Add the value map in the context
        context.setVariable("value", valueMap);
        
        registerFunctions(context);
        
        if (tempValueMap != null)
            context.setVariable("tempvalue", tempValueMap);
        
        return context;
    }
    
    public static EvaluationContext CreateEvaluationContext() throws NoSuchMethodException {
        StandardEvaluationContext context = new StandardEvaluationContext();
                       
        // Register generic functions in the context
        registerFunctions(context);
        
        return context;
    }
    
    private static void registerFunctions(StandardEvaluationContext context) throws NoSuchMethodException     {
        Map<String, Method> functions = FocusContextFunctions.getFunctions();
        
        // Iterate through the registered functions and add to the map
        Iterator<Entry<String, Method>> fnIterator = functions.entrySet().iterator();
        while (fnIterator.hasNext()) {
            Entry<String, Method> fnItem = fnIterator.next();
            context.registerFunction(fnItem.getKey(), fnItem.getValue());
            //System.out.println("function =" + fnItem.getKey() + ", value=" + fnItem.getValue());
        }
       
    }
    
//    private static void registerFunctions(StandardEvaluationContext context) throws NoSuchMethodException     {
//        // Register generic functions in the context
//        
//        //context.re
//        context.registerFunction("days", DateUtils.class.getDeclaredMethod("getNumberofDays", String.class, String.class));
//        context.registerFunction("years", DateUtils.class.getMethod("getNumberofYears", String.class, String.class));
//        context.registerFunction("hours", DateUtils.class.getDeclaredMethod("getNumberofHours", String.class, String.class, String.class, String.class));
//        context.registerFunction("minutes", DateUtils.class.getDeclaredMethod("getNumberofMinutes", String.class, String.class, String.class, String.class));
//        context.registerFunction("monthkey", DateUtils.class.getDeclaredMethod("getMonthKey", String.class));
//        context.registerFunction("weekkey", DateUtils.class.getDeclaredMethod("getWeekKey", String.class));
//        
//        context.registerFunction("number", StringUtils.class.getMethod("stringToLong", String.class));
//        context.registerFunction("equals", StringUtils.class.getMethod("isEquals", String.class,String.class, boolean.class));
//        
//        // measure specific functions
////        context.registerFunction("utd", MeasureUtils.class.getMethod("isUTD", String.class));
////        context.registerFunction("missing", MeasureUtils.class.getMethod("isMissing", String.class));
//        
//        // time specific functions
//        context.registerFunction("timevalue", TimeUtils.class.getMethod("getTimeInDouble", String.class));
//        
////         //Satisfaction Measures functions
////        context.registerFunction("stfn_dnr_check", SatisfactionMeasureUtils.class.getMethod("isSatisfactionDnrCheck", 
////                                        List.class, List.class, OrderedInsensitiveMap.class ));
////        context.registerFunction("stfn_nmr_check", SatisfactionMeasureUtils.class.getMethod("isSatisfactionNmrCheck", 
////                                        List.class, List.class, OrderedInsensitiveMap.class));
////        context.registerFunction("stfn_getQuestion_Metric", 
////                    SatisfactionMeasureUtils.class.getMethod("getQuestionCompliance", 
////                    List.class,List.class,OrderedInsensitiveMap.class));
////        
//        context.registerFunction("sum", MathUtils.class.getMethod("sum", List.class));
////        context.registerFunction("getLastEncounterKey", 
////                ReadmissionMeasureUtils.class.getMethod("getLastEncounterKey", Long.class,Long.class,OrderedInsensitiveMap.class));
//        
//        // Register specific functions
//        // Register specific functions
//        Map<String, Method> functions = ContextFactory.getFunctions();
//    }
    
    public static void UpdateContextForTempValues(EvaluationContext context, OrderedInsensitiveMap tempValueMap) {
        context.setVariable("tempvalue", tempValueMap);
    }
    
}
