/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import java.util.List;

/**
 *
 * @author sathyaji.raja
 */
public final class CSVUtils {

    /**
     * 
     * @param listResults
     * @return
     * @throws Exception 
     */
    public static byte[] createCSVString(List<OrderedInsensitiveMap> listResults) throws Exception {
        byte[] csvBytes = null;
        
        StringBuilder byteStr = new StringBuilder();
        
        // 1. Build the header
        for (OrderedInsensitiveMap map : listResults) {
            for (Object mapKey : map.keySet() ) {
                String value = String.valueOf(mapKey);
                byteStr.append("\""+value+"\"");
                byteStr.append(",");
            }
            
            byteStr.deleteCharAt(byteStr.lastIndexOf(","));
            byteStr.append("\n");
            break;
        }
        
        // 2. Build the output 
        for (OrderedInsensitiveMap map : listResults) {
            for (Object mapValue : map.values() ) {
                
                String value = String.valueOf(mapValue);//map.get(key));
                byteStr.append("\""+value+"\"");
                byteStr.append(",");
                
            }
            byteStr.deleteCharAt(byteStr.lastIndexOf(","));
            byteStr.append("\n");
            
        }
        csvBytes = byteStr.toString().getBytes();
        
        return csvBytes;
    }
}
