/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.utils;

import com.spectramd.products.focus.utils.DateTimeUtils;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.joda.time.DateMidnight;
import org.joda.time.DateTime;
import org.joda.time.Duration;
import org.joda.time.Period;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.joda.time.Days;

/**
 *
 * @author sathyaji.raja
 */
/**
 * Changes made : add getDuration method
 * @author ramya.khasnis
 * Date: 01/07/2014
 */
/**
 * Changes made : added getNumberofMonths & getNumberofWeeks method
 * @author ankur.gupta
 * Date: 10/10/2015
 */
public class DateUtils {

	public static SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	private static String TIME24HOURS_PATTERN = "([01]?[0-9]|2[0-3])?(:)?[0-5][0-9]";
	private static String DATEFORMAT = "yyyy-MM-dd HH:mm:ss.S";
	private static DateTimeUtils dateUtils = new DateTimeUtils(DATEFORMAT);

	//Sathya: dayNumber
	public static long getDateValue(String startDateString) {
		return dateUtils.getDateValue(startDateString);
	}

	public static long getFiscalYearKey(String startDateString) {
		return dateUtils.getFiscalYearKey(startDateString);
	}

	public static long getMonthKey(String startDateString) {

		return dateUtils.getMonthKey(startDateString);
	}

	public static long getQuarterKey(String startDateString) {
		return dateUtils.getQuarterKey(startDateString);
	}

	public static long getWeekKey(String startDateString) {

		return dateUtils.getWeekKey(startDateString);
	}

	public static double getNumberofDays(String startDateString, String endDateString) {

		return dateUtils.getNumberofDays(endDateString, startDateString);
	}

	public static long getNumberofHours(String argStartDate, String startTime,
			String argEndDate, String endTime) {
		return dateUtils.getNumberofHours(argEndDate, endTime, argStartDate, startTime);
	}

	public static long getNumberofMinutes(String argStartDate, String startTime, String argEndDate, String endTime) {

		return dateUtils.getNumberofMinutes(argEndDate, endTime, argStartDate, startTime);
	}

	public static double getNumberofYears(String startDateString, String endDateString) {

		return dateUtils.getNumberofYears(endDateString, startDateString);
	}

	/**
	 *
	 * @param startDateString String
	 * @param endDateString String
	 * @return
	 */
	public static long getNumberofMonths(String startDateString, String endDateString) {

		return dateUtils.getNumberofMonths(endDateString, startDateString);
	}

	/**
	 *
	 * @param startDateString String
	 * @param endDateString String
	 * @return
	 */
	public static long getNumberofWeeks(String startDateString, String endDateString) {

		return dateUtils.getNumberofWeeks(endDateString, startDateString);
	}

	public static Date addYears(Date date, int years) {

		return dateUtils.addYears(date, years);
	}

//    public static Date addDays(Date date, int days) {
//
//        return dateUtils.addDays(date, days);
//    }
	public static long getYearKey(long dateKey) {
		return dateUtils.getYearKey(dateKey);
	}

	public static Date getDateWithStartOfDayTimestamp(long dateKey) {
		return dateUtils.getDateWithStartOfDayTimestamp(dateKey);
	}

	public static Date getDateWithEndOfDayTimestamp(long dateKey) {
		return dateUtils.getDateWithEndOfDayTimestamp(dateKey);
	}

	public static long getNumberofMinutes(String startDateTime, String endDateTime, String inputFormat) {

		return dateUtils.getNumberofMinutes(startDateTime, endDateTime, inputFormat);
	}

	public static String format(Date dateToFormat, String formatString) {
		SimpleDateFormat localDateFormat = new SimpleDateFormat(formatString);
		return localDateFormat.format(dateToFormat);
	}

	public static long getCurrentQuarterKeyLong() {
		return Long.parseLong(getCurrentQuarterKey());
	}

	public static Date getDateFormat(String dateString, String format) {
		DateTimeFormatter tempFormat = DateTimeFormat.forPattern(format);
		return DateTime.parse(dateString, tempFormat).toDate();
	}

	public static Date getDateBasedOnMatchingFormat(String dateString, String[] formats) {
		if (dateString != null) {
			for (String format : formats) {
				try {
					SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
					simpleDateFormat.parse(dateString.trim());
					return getDateFormat(dateString, format);
				} catch (Exception e) {
				}
			}
		}
		return null;
	}

	public static DateTime getDateTime(String dateString, String format) {
		DateTimeFormatter tempFormat = DateTimeFormat.forPattern(format);
		return DateTime.parse(dateString, tempFormat);
	}

	public static long getCurrentMonthKey() {
		DateTime dateTime = new DateTime();

		int year = dateTime.getYear();
		int month = dateTime.getMonthOfYear();

		String monthString = month < 10 ? "0" + String.valueOf(month) : String.valueOf(month);
		return Long.parseLong(String.valueOf(year) + monthString);
	}

	public static long getNumberofDays(String startDateString, String endDateString, String format) {

		DateTimeFormatter formatter = DateTimeFormat.forPattern(format);
		DateTime startDate = DateTime.parse(startDateString, formatter);
		DateTime endDate = DateTime.parse(endDateString, formatter);

		return getDays(startDate.toDateMidnight(), endDate.toDateMidnight());
	}

	public static long getNumberofDays(Date startDate, Date endDate) {

		DateTime startDateJoda = new DateTime(startDate.getTime());
		DateTime endDateJoda = new DateTime(endDate.getTime());

		return getDays(startDateJoda.toDateMidnight(), endDateJoda.toDateMidnight());
	}

	public static double getNumberofYears(String startDateString, String endDateString, String format) {

		DateTimeFormatter formatter = DateTimeFormat.forPattern(format);
		DateTime startDate = DateTime.parse(startDateString, formatter);
		DateTime endDate = DateTime.parse(endDateString, formatter);

		return dateUtils.getNumberofYearsGivenDate(startDate.toDate(), endDate.toDate());
		//return Years.yearsBetween(startDate , endDate).getYears() ;

	}

	public static Date addDays(Date inputDate, int days) {
		Calendar calender = Calendar.getInstance();
		calender.setTime(inputDate);
		calender.add(Calendar.DATE, days);

		return calender.getTime();
	}

	public static String changeFormat(String dateInString, String format, String outputFormat) {

		Date tempDate = getDateFormat(dateInString, format);
		return format(tempDate, outputFormat);
	}

	public static String getDate(String dateInString, int days, String format) {

		String dateString = "";
		Calendar calender = Calendar.getInstance();
		DateFormat df = new SimpleDateFormat(format);
		try {

			Date myDate = df.parse(dateInString.trim());
			calender.setTime(myDate);
			calender.add(Calendar.DATE, days);

			dateString = df.format(calender.getTime());
		} catch (ParseException e) {
			// do nothing
		}

		return dateString;
	}

	public static Date getDateOutput(String dateInString, int days, String format) {

		Calendar calender = Calendar.getInstance();
		DateFormat df = new SimpleDateFormat(format);
		try {

			Date myDate = df.parse(dateInString.trim());
			calender.setTime(myDate);
			calender.add(Calendar.DATE, days);

		} catch (ParseException e) {
			// do nothing
		}

		return calender.getTime();
	}

	public static boolean checkDate(String inDate) {

		if (inDate == null) {
			return false;
		}

		try {
			//parse the inDate parameter
			dateFormat.parse(inDate.trim());
		} catch (Exception pe) {
			return false;
		}
		return true;
	}

	public static String getCurrentQuarterKey() {
		return Long.toString(getQuarterKey(new Date()));
	}

	public static long getQuarterKey(Date startDate) {
		Calendar calendar = Calendar.getInstance(Locale.US);
		calendar.setTime(startDate);

		int month = calendar.get(Calendar.MONTH);
		int quarter = (month / 3) + 1;
		return Long.parseLong(calendar.get(Calendar.YEAR) + "" + quarter);
	}

	public static String getCurrentYearKey() {
		Calendar calendar = Calendar.getInstance(Locale.US);
		calendar.setTime(new Date());

		return String.valueOf(calendar.get(Calendar.YEAR));
	}

	public static boolean checkDate(String inDate, String format) {

		boolean result = false;
		try {
			if (inDate != null) {
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
				simpleDateFormat.setLenient(true);
				//parse the inDate parameter
				simpleDateFormat.parse(inDate.trim());
				result = true;
			}
		} catch (Exception pe) {
			//return false;
		}

		return result;
	}

	/**
	 * Check data format against list of formats
	 *
	 * @param inDate
	 * @param formats
	 * @return boolean
	 */
	public static boolean checkDate(String inDate, String[] formats) {

		boolean result = false;
		try {
			if (inDate != null) {
				for (String format : formats) {
					try {
						if (inDate != null) {
							SimpleDateFormat simpleDateFormat = new SimpleDateFormat(format);
							simpleDateFormat.setLenient(false);
							simpleDateFormat.parse(inDate.trim());
							return true;
						}
					} catch (Exception pe) {
						//return false;
					}
				}
			}
		} catch (Exception pe) {
			//return false;
		}

		return result;
	}

	public static boolean checkTime(String inTime) {

		boolean result = false;
		if (inTime != null) {
			Pattern pattern = Pattern.compile(TIME24HOURS_PATTERN);
			Matcher matcher = pattern.matcher(inTime);
			result = matcher.matches();
		}

		return result;
	}

	public static long getDateKey(Date date) {
		if (date == null) {
			return -1;
		}
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		String dateString = sdf.format(date);
		long dateKey = Long.parseLong(dateString);
		return dateKey;
	}

	public static String getTimeKey(Date date) {
		if (date == null) {
			return "-1";
		}
		SimpleDateFormat sdf = new SimpleDateFormat("HHmm");
		String timeString = sdf.format(date);
		return timeString;
	}

	public static String mergeDateAndTime(String date, String dateFormat, String time, String timeformat) {

		String dateTime = "";
		try {

			//check the date format
			if (checkDate(date, dateFormat)) {
				//parse the date
				SimpleDateFormat dateParser = new SimpleDateFormat(dateFormat);
				Date dateObj = dateParser.parse(date);

				//format the date to "yyyy-MM-dd" format
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
				dateTime = sdf.format(dateObj);

				//check the time format
				if (checkDate(time, timeformat)) {
					//parse the time
					Date timeObj = (new SimpleDateFormat(timeformat)).parse(time);

					//format the time to "HH:mm:ss" format
					String timeString = (new SimpleDateFormat("HH:mm:ss")).format(timeObj);
					dateTime = dateTime + " " + timeString;
				} else {
					// if time null or format is not correct add zero time
					dateTime = dateTime + " 00:00:00";
				}
			}

		} catch (Exception ex) {
			//do nothing
			dateTime = "";
		}
		return dateTime;
	}

	/**
	 * This method is used to convert date to Timestamp
	 *
	 * @param javaDate
	 * @return Timestamp
	 */
	public static Timestamp getSqlDateTime(Date javaDate) {
		if (javaDate != null) {
			return new java.sql.Timestamp(javaDate.getTime());
		}
		return null;
	}

	/**
	 * This method is used to convert StringDate to Timestamp
	 *
	 * @param date InputDate to convert to Timestamp
	 * @return Timestamp SQLTimestamp of java Date
	 */
	public static Timestamp getTimeStamp(Object date) {
		return dateUtils.getTimeStamp(date);

	}

	/**
	 * Add months to month and days to given date
	 * @param dateString
	 * @param months
	 * @param days
	 * @return
	 */
	public static String addMonths(String dateString, int months, int days) {
		return dateUtils.addMonths(dateString, months, days);
	}

	/**
	 * Add days to given date
	 * @param dateString
	 * @param days
	 * @return
	 */
	public static String addDays(String dateString, int days) {
		return dateUtils.addDays(dateString, days);
	}

	public static String addMonthsTillEndofDay(String dateString, int months, int days) {
		return dateUtils.addMonthsTillEndofDay(dateString, months, days);
	}

	public static String addDaysTillEndofDay(String dateString, int days) {
		return dateUtils.addDaysTillEndofDay(dateString, days);
	}

	/**
	 * Add seconds to given date
	 * @param dateString
	 * @param seconds
	 * @return
	 */
	public static String addSeconds(String dateString, int seconds) {
		return dateUtils.addSeconds(dateString, seconds);
	}

	/**
	 * Returns the number of days between the 2 dates.
	 * @param startDate DateMidnight
	 * @param endDate DateMidnight
	 * @return long
	 */
	private static long getDays(final DateMidnight startDate, final DateMidnight endDate) {
		Period period = new Period(startDate, endDate);
		Duration duration = period.toDurationFrom(new DateTime());
		return duration.toStandardDays().getDays();
	}

	public static long getNumberofDays(String startDateString, String endDateString, String[] formats) {

        int result = -1;

        for (String format : formats) {
            try {
                DateTimeFormatter formatter = DateTimeFormat.forPattern(format);
                DateTime startDate = DateTime.parse(startDateString, formatter);
                DateTime endDate = DateTime.parse(endDateString, formatter);
                if(!startDate.isAfter(endDate))
                result = Days.daysBetween(startDate.toDateMidnight(), endDate.toDateMidnight()).getDays();
            } catch (Exception e) {

            }

        }
        return result;
    }
}
