
package com.spectramd.products.focus.common;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;

/**
 *
 * @author lravilla
 */
public class ApplicationContextProvider implements ApplicationContextAware {

    private static ApplicationContext context;

    @Override
    public void setApplicationContext(ApplicationContext appContext) {
        ApplicationContextProvider.context = appContext;
    }

    public static ApplicationContext getApplicationContext() throws BeansException {
        return context;
    }
    
}
