/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

/**
 *
 * @author sathyaji.raja
 */
public class DatabaseField {
    
    private long id;
    private String name;
    private String aliasName;
    private FieldType type;
    private boolean internal = false;
    
    public DatabaseField()  {
        
    }
    
    public DatabaseField(DatabaseField argField)    {
        id = argField.id;
        name = argField.name;
        aliasName = argField.aliasName;
        type = argField.type;
        internal = argField.internal;
    }
    
    public DatabaseField(String argName, String argAliasName, FieldType argType)    {
        id = -1;
        name = argName;
        aliasName = argAliasName;
        type = argType;
    }
    
    public DatabaseField(long id, String argName, String argAliasName, 
                            FieldType argType, boolean internal)    {
        this.id = id;
        this.name = argName;
        this.aliasName = argAliasName;
        this.type = argType;
        this.internal = internal;
    }
    
    public long getId() {
        return id;
    }
    
    public void setId(long fieldId) {
        id = fieldId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String fieldName)   {
        name = fieldName;
    }
    
    public String getAliasName() {
        return aliasName;
    }
    
    public void setAliasName(String fieldAliasName)   {
        aliasName = fieldAliasName;
    }
    
    public FieldType getType()  {
        return type;
    }
    
    public void setType(FieldType fdType)   {
        type = fdType;
    }
    
    public void setTypeString(String strType)   {
        type = FieldType.getFieldType(strType);
    }
    
    public boolean isInternal()  {
        return internal;
    }
    
    public void setInternal(boolean argInternal)   {
        internal = argInternal;
    }
}
