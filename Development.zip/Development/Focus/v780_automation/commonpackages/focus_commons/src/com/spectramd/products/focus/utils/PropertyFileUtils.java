/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

/**
 *
 * @author sathyaji.raja
 */
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class PropertyFileUtils {
    
    private PropertyFileUtils() {
        
    }
    
    public static Properties readPropertyFile(String propertyFileName) throws IOException {
         
        InputStream is = PropertyFileUtils.class.getResourceAsStream(propertyFileName); 
        Properties propertyValues = new Properties();   
        propertyValues.load(is);   

        return propertyValues;
    }
}
