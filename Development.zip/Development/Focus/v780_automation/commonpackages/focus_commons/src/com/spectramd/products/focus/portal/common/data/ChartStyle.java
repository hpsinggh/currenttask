/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.portal.common.data;

import java.util.HashMap;
import java.util.Map;

/**
 * This class contains the chartStyle related properties and setter/getter methods.
 * @author rpalaparthi
 */
public class ChartStyle extends WidgetStyle {
    
    private String divLineColor;
    
    private String canvasBgColor;
    
    private String canvasBaseColor;
    
    private String bgColor;
    
    private String labelDisplay;
    
    private int showValues = -1;
    
    private String lineColor;
    
    private int numDivLines = -1;
    
    private int palette = -1;
    
    private int animation = -1;
    
    private int formatNumberScale = -1;
    
    private String numberPrefix = "";
    
    private String numberSuffix = "";
    
    private int showPercentInToolTip = -1;
    
    private int showPercentValues = -1;

    private int legendPosition = -1;
    
    private int showLabels = -1;
    
    private int showBorder = -1;
    
    private int showLegend = -1;
    
    private int slantLabels = -1;
    
    private int useRoundEdges = 1;
    
    private int chartTopMargin = -1;
    
    private int chartBottomMargin = -1;
    
    private String baseFontColor;
    
    private int showShadow = -1;
    
    private int manageResize = -1;
    
    private String chartStyleType; 
    
    private String extendedStyle;
    
    private int adaptiveYMin = -1;
    
    private String borderColor;
    
    private String clickUrl = null;
    
    // Sathya : Added for Grid + Chart..
    private Map<String, String> extendedStylesMap = new HashMap<String, String>();

    public Map<String, String> getExtendedStylesMap() {
        return extendedStylesMap;
    }

    public void setExtendedStylesMap(Map<String, String> extendedStylesMap) {
        this.extendedStylesMap = extendedStylesMap;
    }
    
    

    public String getClickUrl() {
        return clickUrl;
    }

    public void setClickUrl(String clickUrl) {
        this.clickUrl = clickUrl;
    }
    

    public String getBorderColor() {
        return borderColor;
    }

    public void setBorderColor(String borderColor) {
        this.borderColor = borderColor;
    }

    
    public int getAdaptiveYMin() {
        return useRoundEdges;
    }

    public void setAdaptiveYMin(int adaptiveYMin) {
        this.adaptiveYMin = adaptiveYMin;
    }
    
    public String getExtendedStyle() {
        return extendedStyle;
    }

    public void setExtendedStyle(String extendedStyle) {
        update(extendedStyle);
    }
    
    private void update(String extendedStyles){
        if (extendedStyles != null && extendedStyles.trim().length() > 0) {
            String[] elements = new String[extendedStyles.split("#").length];
            elements = extendedStyles.split("#");

            for (String object : elements) {
                String[] objects = object.split(":");
                extendedStylesMap.put(objects[0].trim(), objects[1]!= null ?objects[1].trim():"");
            }
        }
       
    }

    public int getUseRoundEdges() {
        return useRoundEdges;
    }

    public void setUseRoundEdges(int useRoundEdges) {
        this.useRoundEdges = useRoundEdges;
    }

    public String getChartStyleType() {
        return chartStyleType;
    }

    public void setChartStyleType(String chartStyleType) {
        this.chartStyleType = chartStyleType;
    }
    
    public String getBaseFontColor() {
        return baseFontColor;
    }

    public void setBaseFontColor(String baseFontColor) {
        this.baseFontColor = baseFontColor;
    }
    
    public int getChartBottomMargin() {
        return chartBottomMargin;
    }

    public void setChartBottomMargin(int chartBottomMargin) {
        this.chartBottomMargin = chartBottomMargin;
    }

    public int getChartTopMargin() {
        return chartTopMargin;
    }

    public void setChartTopMargin(int chartTopMargin) {
        this.chartTopMargin = chartTopMargin;
    }
    
    public int getManageResize() {
        return manageResize;
    }

    public void setManageResize(int manageResize) {
        this.manageResize = manageResize;
    }
    
    public int getShowShadow() {
        return showShadow;
    }

    public void setShowShadow(int showShadow) {
        this.showShadow = showShadow;
    }

    public int getSlantLabels() {
        return slantLabels;
    }

    public void setSlantLabels(int slantLabels) {
        this.slantLabels = slantLabels;
    }

    public int getLegendPosition() {
        return legendPosition;
    }

    public void setLegendPosition(int legendPosition) {
        this.legendPosition = legendPosition;
    }

    public int getShowBorder() {
        return showBorder;
    }

    public void setShowBorder(int showBorder) {
        this.showBorder = showBorder;
    }

    public int getShowLabels() {
        return showLabels;
    }

    public void setShowLabels(int showLabels) {
        this.showLabels = showLabels;
    }

    public int getShowLegend() {
        return showLegend;
    }

    public void setShowLegend(int showLegend) {
        this.showLegend = showLegend;
    }
        
    public int getAnimation() {
        return animation;
    }

    public void setAnimation(int animation) {
        this.animation = animation;
    }

    public int getFormatNumberScale() {
        return formatNumberScale;
    }

    public void setFormatNumberScale(int formatNumberScale) {
        this.formatNumberScale = formatNumberScale;
    }

    public String getNumberPrefix() {
        return numberPrefix;
    }

    public void setNumberPrefix(String numberPrefix) {
        this.numberPrefix = numberPrefix;
    }
    
    public String getNumberSuffix() {
        return numberSuffix;
    }

    public void setNumberSuffix(String numberSuffix) {
        this.numberSuffix = numberSuffix;
    }

    public int getPalette() {
        return palette;
    }

    public void setPalette(int palette) {
        this.palette = palette;
    }

    public int getShowPercentInToolTip() {
        return showPercentInToolTip;
    }

    public void setShowPercentInToolTip(int showPercentInToolTip) {
        this.showPercentInToolTip = showPercentInToolTip;
    }

    public int getShowPercentValues() {
        return showPercentValues;
    }

    public void setShowPercentValues(int showPercentValues) {
        this.showPercentValues = showPercentValues;
    }
    
    public String getBgColor() {
        return bgColor;
    }

    public void setBgColor(String bgColor) {
        this.bgColor = bgColor;
    }

    public String getCanvasBaseColor() {
        return canvasBaseColor;
    }

    public void setCanvasBaseColor(String canvasBaseColor) {
        this.canvasBaseColor = canvasBaseColor;
    }

    public String getCanvasBgColor() {
        return canvasBgColor;
    }

    public void setCanvasBgColor(String canvasBgColor) {
        this.canvasBgColor = canvasBgColor;
    }

    public String getDivLineColor() {
        return divLineColor;
    }

    public void setDivLineColor(String divLineColor) {
        this.divLineColor = divLineColor;
    }

    public String getLabelDisplay() {
        return labelDisplay;
    }

    public void setLabelDisplay(String labelDisplay) {
        this.labelDisplay = labelDisplay;
    }

    public String getLineColor() {
        return lineColor;
    }

    public void setLineColor(String lineColor) {
        this.lineColor = lineColor;
    }

    public int getNumDivLines() {
        return numDivLines;
    }

    public void setNumDivLines(int numDivLines) {
        this.numDivLines = numDivLines;
    }

    public int getShowValues() {
        return showValues;
    }

    public void setShowValues(int showValues) {
        this.showValues = showValues;
    }
}
