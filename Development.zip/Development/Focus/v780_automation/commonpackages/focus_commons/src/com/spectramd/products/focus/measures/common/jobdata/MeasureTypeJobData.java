/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common.jobdata;

/**
 *
 * @author sathyaji.raja
 */
public class MeasureTypeJobData extends AbstractJobData {
    
    public String category = "CLINICAL";
    public String measureTypeCode;
    
    public MeasureTypeJobData() {
        
    }
    
    public MeasureTypeJobData(String category)    {
        this.category = category;
        
    }
    
    public void setCategory(String category) {
        this.category = category;
    }
    
    public String getCategory() {
        return category;
    }
    
    public String getMeasureTypeCode()  {
        return measureTypeCode;
    }
    
    public void setMeasureTypeCode(String argMeasureCode)  {
        measureTypeCode = argMeasureCode;
    }
    
}
