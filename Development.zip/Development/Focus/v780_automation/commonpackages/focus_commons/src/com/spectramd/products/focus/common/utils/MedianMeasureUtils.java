/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.common.FocusConfig;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author lravilla
 */
public class MedianMeasureUtils {

    /**
     * This method is used to find the median value.
     *
     * @param edTimes - it is having List of Ed and Decision Times.
     * @return medianValue -return Median Value
     */
    public static Double calculateMedianValue(List<Double> edTimes) {
        FocusConfig.getCurrentLogger().writeDebug("Start : MedianMeasureUtils method: calculateMedianValue()");
        double medianValue = -1;
        
        //1. Sort the collection
        Collections.sort(edTimes);
        //2.Find the middle index and evaluate median value
        Integer middleOfEdTime = edTimes.size() / 2;
        if (edTimes.size() % 2 == 1) {
            medianValue = edTimes.get(middleOfEdTime);
        } else {
            medianValue = (edTimes.get(middleOfEdTime - 1) + edTimes.get(middleOfEdTime)) / 2;
        }
        FocusConfig.getCurrentLogger().writeDebug("End : MedianMeasureUtils method: calculateMedianValue()");
        return medianValue;
    }
}
