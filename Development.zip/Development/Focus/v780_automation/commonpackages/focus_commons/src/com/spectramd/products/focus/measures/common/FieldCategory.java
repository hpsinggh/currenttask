/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.spectramd.products.focus.measures.common;

/**
 *
 * @author sathyaji.raja
 */
public enum FieldCategory {
    NONE, FIELD, VALUE, EXPRESSION, EXPR_JUMP;
    
    
    public static FieldCategory getFieldCategory(String category) {
        
        if (category.equalsIgnoreCase("FIELD"))
            return FieldCategory.FIELD;
        else if (category.equalsIgnoreCase("VALUE"))
            return FieldCategory.VALUE;
        else if (category.equalsIgnoreCase("EXPRESSION"))
            return FieldCategory.EXPRESSION;
        else if (category.equalsIgnoreCase("EXPR_JUMP"))
            return FieldCategory.EXPR_JUMP;
        else 
            return FieldCategory.NONE;
    }
}
