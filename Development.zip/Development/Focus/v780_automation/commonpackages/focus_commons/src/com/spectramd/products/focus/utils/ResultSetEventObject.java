/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import java.sql.ResultSet;

/**
 *
 * @author sathyaji.raja
 */
public class ResultSetEventObject  extends java.util.EventObject {

    public ResultSetEventObject(Object source)    {
        super(source);
    }
    
    public ResultSetEventObject(ResultSet source) {
        super(source);
    }
}
