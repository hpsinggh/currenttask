/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 *
 * @author sathyaji.raja
 */
public class TableDetails extends DBTableDetails {
 
    
    private String primaryKey;
    
    // applies for related tables
    private String aliasName;
    private String joinCondition;
    private long tableRelationId = -1;  // instead of defining this member, change arraylist of table 
                                        // details to hashmap of tablerelationid to tabledetails
    
    private HashMap<String, DatabaseField> tableFields = new HashMap<String, DatabaseField>();
    private ArrayList<TableDetails> relatedTableDetails = new ArrayList<TableDetails>();

    public TableDetails()   {
        
    }
    
    public TableDetails(TableDetails argTableDetails)   {
        setTableId(argTableDetails.getTableId());
        setName(argTableDetails.getName());
        setAliasName(argTableDetails.getAliasName());
        setPrimaryKey(argTableDetails.getPrimaryKey());
        setJoinCondition(argTableDetails.getJoinCondition());
    }
    
    public String getPrimaryKey() {
        return primaryKey;
    }

    public void setPrimaryKey(String PrimaryKey) {
        this.primaryKey = PrimaryKey;
    }

    public ArrayList<TableDetails> getRelatedTableDetails() {
        return relatedTableDetails;
    }

    public void setRelatedTableDetails(ArrayList<TableDetails> argRelatedTableDetails) {
        this.relatedTableDetails = argRelatedTableDetails;
    }

    public HashMap<String, DatabaseField> getTableFields() {
        return tableFields;
    }

    public void setTableFields(HashMap<String, DatabaseField> TableFields) {
        this.tableFields = TableFields;
    }
    
    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String argAliasName) {
        this.aliasName = argAliasName;
    }
    
    public void setJoinCondition(String condition) {
        this.joinCondition = condition;
    }
    
    public String getJoinCondition() {
        return joinCondition;
    }
    
    public TableDetails eliminateTableFields(TableDetails argPrimaryTableDetails) {
        
        TableDetails primaryTableDetails = new TableDetails(argPrimaryTableDetails);
        
        // copy the database fields
        HashMap<String, DatabaseField> currentPrimaryTableFields = argPrimaryTableDetails.getTableFields();
        HashMap<String, DatabaseField> newPrimaryTableFields = removeInternalFields(currentPrimaryTableFields);
        primaryTableDetails.setTableFields(newPrimaryTableFields);
    
        // copy the related tables
        ArrayList<TableDetails> relatedTableDetailsList = new ArrayList<TableDetails>();
        for(TableDetails relatedTableDetails : argPrimaryTableDetails.getRelatedTableDetails())    {
            TableDetails tempTableDetails = new TableDetails(relatedTableDetails);
            
            HashMap<String, DatabaseField> currentTableFields = relatedTableDetails.getTableFields();
            HashMap<String, DatabaseField> newTableFields = removeInternalFields(currentTableFields);
            tempTableDetails.setTableFields(newTableFields);
            
            // add to the related table list
            relatedTableDetailsList.add(tempTableDetails);
        }
        
        primaryTableDetails.setRelatedTableDetails(relatedTableDetailsList);
        
        return primaryTableDetails;
    }
    
    private HashMap<String, DatabaseField> removeInternalFields(HashMap<String, DatabaseField> currentTableFields) {
        
        HashMap<String, DatabaseField> newTableFields = new HashMap<String, DatabaseField>();
        Iterator<String> iterator = currentTableFields.keySet().iterator();
        while (iterator.hasNext()){
            String key = iterator.next();
            DatabaseField curFieldValue = currentTableFields.get(key);
            if(!curFieldValue.isInternal()) {
                DatabaseField newField = new DatabaseField(curFieldValue);
                newTableFields.put(key, newField);
            } else {
                // for debug
                //FocusConfig.getCurrentLogger().writeDebug("Fields internal - " + curFieldValue.getAliasName());
            }
            
        }
        
        return newTableFields;
    }
    
     public long getTableRelationId() {
        return tableRelationId;
    }

    public void setTableRelationId(long argtableRelationId) {
        this.tableRelationId = argtableRelationId;
    }
 
}
