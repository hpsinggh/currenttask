/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.measures.common.AbstractView;
import com.spectramd.products.focus.measures.common.DatabaseField;
import com.spectramd.products.focus.measures.common.SqlView;
import java.util.ArrayList;

/**
 *
 * @author sumit.taneja
 */
public class ElasticSearchQueryBuilder implements QueryBuilderInterface {

	/**
	 * This method will get the complex query for secondary data.
	 *
	 * @param argView AbstractView
	 * @param defaultFieldValues ArrayList<DatabaseField>
	 * @param inputValues ArrayList
	 * @return String
	 */
	@Override
	public final String getComplexQuery(final AbstractView argView, final ArrayList<DatabaseField> defaultFieldValues,
			final ArrayList inputValues) {
		FocusConfig.getCurrentLogger().writeDebug("Enter ProcedureQueryBuilder getComplexQuery() method");

		SqlView sqlView = (SqlView) argView;
		if (inputValues != null) {
			return String.format(sqlView.getQuery(), inputValues.toArray());
		} else {
			return sqlView.getQuery();
		}
	}

	/**
	 * This method will get the query for primary axis data.
	 *
	 * @param argView AbstractView
	 * @param defaultFieldValues ArrayList<DatabaseField>
	 * @param inputValues String[]
	 * @return String
	 */
	@Override
	public final String getQuery(final AbstractView argView, final ArrayList<DatabaseField> defaultFieldValues,
			final String[] inputValues) {
		SqlView sqlView = (SqlView) argView;
		return String.format(sqlView.getQuery(), (Object[]) inputValues);
	}

	/**
	 * This method will get the complex query for the procedure.
	 *
	 * @param argView AbstractView
	 * @param defaultFieldValues ArrayList<DatabaseField>
	 * @param inputType String
	 * @param inputValues ArrayList
	 * @return String
	 */
	@Override
	public final String getComplexQuery(final AbstractView argView, final ArrayList<DatabaseField> defaultFieldValues,
			final String inputType, final ArrayList inputValues) {
		SqlView sqlView = (SqlView) argView;
		if (inputValues != null) {
			return String.format(sqlView.getQuery(), inputValues.toArray());
		} else {
			return sqlView.getQuery();
		}
	}
}
