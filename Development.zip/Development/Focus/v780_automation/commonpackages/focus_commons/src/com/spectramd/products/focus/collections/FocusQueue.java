/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.collections;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author sathyaji.raja
 */
public class FocusQueue<T> {
    
    private ArrayList<T> listObjects = new ArrayList<T>();
    
    public FocusQueue() {
        
    }
    
    public void add (T object) {
        listObjects.add(object);
    }
    
    public void add (List<T> objects) {
        listObjects.addAll(objects);
    }
    
    public T removeFirst() {
        return listObjects.remove(0);
    }
    
    public synchronized List<T> remove(int batchsize) {
        
        List<T> objects = new ArrayList<T>();
        int size = batchsize > listObjects.size() ? listObjects.size() : batchsize;
        for (int count=0; count < size; count++) {
            objects.add(listObjects.remove(0));
        }
        
        return objects;
    }
    
}
