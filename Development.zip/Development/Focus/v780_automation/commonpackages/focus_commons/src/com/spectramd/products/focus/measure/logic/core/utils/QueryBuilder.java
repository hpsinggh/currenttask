/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.measures.common.AbstractView;
import com.spectramd.products.focus.measures.common.DatabaseField;
import java.util.ArrayList;

/**
 *
 * @author sathyaji.raja
 */
public final class QueryBuilder {
    
    private static String TableAlias = "TABLE";
    private QueryBuilder() {
        
    }
    
    public static String getComplexQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    ArrayList inputValues) {
        
        // 1. Get the query builder
        QueryBuilderFactory factory = QueryBuilderFactory.getInstance();
        QueryBuilderInterface queryBuilder = factory.getQueryBuilder("VIEW");
        
        // 2. get the formatted query
        return queryBuilder.getComplexQuery(argView, defaultFieldValues, inputValues);
    }
    
     public static String getComplexQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    ArrayList inputValues, String viewType) {
        
        // 1. Get the query builder
        QueryBuilderFactory factory = QueryBuilderFactory.getInstance();
        QueryBuilderInterface queryBuilder = factory.getQueryBuilder(viewType);
        
        // 2. get the formatted query
        return queryBuilder.getComplexQuery(argView, defaultFieldValues, inputValues);
    }
    
    public static String getQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    String[] inputValues) {
        
        // 1. Get the query builder
        QueryBuilderFactory factory = QueryBuilderFactory.getInstance();
        QueryBuilderInterface queryBuilder = factory.getQueryBuilder("VIEW");
        
        // 2. get the formatted query
        return queryBuilder.getQuery(argView, defaultFieldValues, inputValues);
    }
    
    public static String getQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    String[] inputValues, String viewType) {
        
        // 1. Get the query builder
        QueryBuilderFactory factory = QueryBuilderFactory.getInstance();
        QueryBuilderInterface queryBuilder = factory.getQueryBuilder(viewType);
        
        // 2. get the formatted query
        return queryBuilder.getQuery(argView, defaultFieldValues, inputValues);
    }

    
}
