
package com.spectramd.products.focus.utils;

import java.util.Iterator;
import java.util.Map;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author sathyaji.raja
 */
public class LogUtils {
    
    private LogUtils() {
        
    }
    
    
    public static void writeLog(Map map, String [] formatoutput) {
        
        Iterator itrMap = map.keySet().iterator();
            while (itrMap.hasNext()) {
                String mapKey = itrMap.next().toString();
                StringBuilder logOutput = new StringBuilder(200);
                logOutput.append(formatoutput[0]);
                logOutput.append(" ");
                logOutput.append(mapKey);
                
                logOutput.append(" ");
                logOutput.append(formatoutput[1]);
                logOutput.append(" ");
                logOutput.append(map.get(mapKey));
                logOutput.append(" ");
            }
            //System.out.println("");
    }
    
    public static void writeDuration(String component, long startDateTime, long endDateTime) {
        
        System.out.println(component + "-" + "Time in ms: "+ (endDateTime- startDateTime));
       
    }
    
}
