/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.utils;

import com.spectramd.products.focus.collections.GenericComparator;
import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.springframework.util.CollectionUtils;

/**
 *
 * @author sathyaji.raja
 */
public class CollectionFunctions {

    /**
     * Method is used to get list of keys from the list of map
     * @param list
     * @return list
     */
    public static List getKeyListFromMap(HashMap map) {
        List outputList = new ArrayList();
        if (map != null) {
            outputList.addAll(map.keySet());
        }
        return outputList;
    }

    /**
     * Method is used to get list of keys from the list of map
     * @param list
     * @param key
     * @return list
     */
    public static List getKeyListFromListOfMap(List<OrderedInsensitiveMap> list, String key) {
        List outputList = new ArrayList();
        if (list != null) {
            for (OrderedInsensitiveMap map : list) {
                outputList.add(map.get(key));
            }
        }
        return outputList;
    }

    /**
     * This method is used to check whether any of second list elements contain in first list
     * @param source
     * @param candidates
     * @return boolean
     */
    public static boolean containsAnyKey(List source, List candidates) {
        boolean retVal = false;
        if (source != null && candidates != null) {
            retVal = !Collections.disjoint(source, candidates);
        }
        return retVal;
    }

    public static List<OrderedInsensitiveMap> getUniqueList(List<OrderedInsensitiveMap> mapList, String uniqueField) {
        List<OrderedInsensitiveMap> resultList = null;
        if (mapList != null) {

            // temporary map to check if the value has been added
            Map<String, Object> mapUniqueValuesAdded = new HashMap<String, Object>();
            resultList = new ArrayList<OrderedInsensitiveMap>();
            for (OrderedInsensitiveMap map : mapList) {

                Object uniqueValue = map.get(uniqueField);
                if (uniqueValue != null) {

                    // Check if the temporary map contains the value
                    String uniqueValueString = uniqueValue.toString().toUpperCase();
                    if (!mapUniqueValuesAdded.containsKey(uniqueValueString)) {

                        resultList.add(map);
                        mapUniqueValuesAdded.put(uniqueValueString, null);
                    }

                }

            }
        }

        return resultList;

    }

    public static List getSortedSubset(List<OrderedInsensitiveMap> mapList,
            String filterField, String filterValue, String sortField,
            String sortDirection, String resultField) {


        if (mapList != null && !mapList.isEmpty() && filterField != null) {
            List<Object> resultList = null;
            List<OrderedInsensitiveMap> filteredMapList = mapList;
            //1. Filter the mapList
            if (filterValue != null && !filterValue.isEmpty()) {
                filteredMapList = doFilter(mapList, filterField, filterValue);
            }

            if (filteredMapList != null) {
                //2. Sort the Filtered Map List
                if (sortField != null && !sortField.isEmpty()) {
                    doSort(filteredMapList, sortField, sortDirection);
                }

                //3.Construnct the list of result fields
                if (resultField != null && !resultField.isEmpty()) {
                    resultList = getResultList(filteredMapList, resultField);
                }

                return resultList == null ? filteredMapList : resultList;
            }

        }

        return null;
    }

    private static List<Object> getResultList(List<OrderedInsensitiveMap> mapList, String resultField) {
        List<Object> resultList = null;
        if (mapList != null) {
            resultList = new LinkedList<Object>();
            for (OrderedInsensitiveMap map : mapList) {
                if (map.get(resultField) != null) {
                    resultList.add(map.get(resultField));
//                    System.out.println("map input type for  " + resultField + " is " + 
//                            map.get(resultField).getClass().getName()  + " and value is " + map.get(resultField));
                }
            }
        }
        return resultList;
    }

    private static List<OrderedInsensitiveMap> doFilter(List<OrderedInsensitiveMap> mapList,
            String filterField, String filterValue) {

        List<OrderedInsensitiveMap> filteredMapList = null;
        for (OrderedInsensitiveMap map : mapList) {
            if (map.get(filterField) != null && map.get(filterField).toString().equalsIgnoreCase(filterValue)) {
                if (filteredMapList == null) {
                    filteredMapList = new ArrayList<OrderedInsensitiveMap>();
                }

                filteredMapList.add(map);
            }
        }

        return filteredMapList;
    }

    private static void doSort(List<OrderedInsensitiveMap> mapList,
            String sortField, String sortDirection) {

        if (sortDirection != null && sortDirection.equalsIgnoreCase("DESC")) {
            Collections.sort(mapList, Collections.reverseOrder(new GenericComparator(sortField)));
        } else {
            Collections.sort(mapList, new GenericComparator(sortField));
        }

    }

    /**
     * If given mapList is not null and size is > 0 then sort the list based of the sortField in given sortDirection
     * and return a new List only the 1st element in the list.
     * @param mapList
     * @param sortField
     * @param sortDirection
     * @return 
     */
    public static List<OrderedInsensitiveMap> getMostRecent(List<OrderedInsensitiveMap> mapList,
            String sortField, String sortDirection) {
        List<OrderedInsensitiveMap> resultList = new ArrayList<OrderedInsensitiveMap>();
        if (mapList != null && mapList.size() > 0) {
            doSort(mapList, sortField, sortDirection);
            resultList.add(mapList.get(0));
        }
        return resultList;
    }

    /**
     * Sort the list based on sortfield and sort direction and return the fist element
     * @param mapList
     * @param sortField
     * @param sortDirection
     * @return OrderedInsensitive
     */
    public static OrderedInsensitiveMap getMostRecentElement(List<OrderedInsensitiveMap> mapList,
            String sortField, String sortDirection) {
        if (mapList != null && mapList.size() > 0) {
            doSort(mapList, sortField, sortDirection);
            return mapList.get(0);
        }
        return null;
    }
    
    /**
     * Merge list2 into list1
     * @param list1
     * @param list2
     * @return list
     */
    public static List<OrderedInsensitiveMap> mergeList(List<OrderedInsensitiveMap> list1,
                                           List<OrderedInsensitiveMap> list2) {
        if (list1 != null) {
            list1.addAll(list2);
            return list1;
        }
        return null;
    }
    
    /**
     * Sum of list integers
     * @param list
     * @return numeric
     */
    public static int sum(List<Integer> list) {
        int sum = 0;
        for (int value : list) {
            sum += value;
        }
        return sum;
    }
    
    
    public static List<OrderedInsensitiveMap> getSubSet(List<OrderedInsensitiveMap> mapList, String fieldRank) {
        List<OrderedInsensitiveMap> resultList = new ArrayList<OrderedInsensitiveMap>();
        if (mapList != null && mapList.size() > 0) {
            if (fieldRank.equalsIgnoreCase("FIRST")) {
                doSort(mapList, "startDateTime", "ASC");
                resultList.add(mapList.get(0));
            } else if (fieldRank.equalsIgnoreCase("RECENT")){
                doSort(mapList, "startDateTime", "DESC");
                resultList.add(mapList.get(0));
            }
        }
        return resultList;
    }
}
