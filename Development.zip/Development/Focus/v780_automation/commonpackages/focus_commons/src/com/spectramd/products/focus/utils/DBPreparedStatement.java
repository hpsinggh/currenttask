/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.FocusException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author sathyaji.raja
 */
public abstract class DBPreparedStatement {
    
    private Connection con = null;
    //private DBOperation dbOperation;
      
    protected PreparedStatement stmtInsert = null;
    protected PreparedStatement stmtDelete = null;
    protected PreparedStatement stmtUpdate = null;

    
    public DBPreparedStatement(Connection argConnection) {
        con = argConnection;
    }
    
    protected void createStatements(String queryInsert, String queryDelete, 
                                    String queryUpdate) throws SQLException   {
        if (queryInsert != null && queryInsert.length() > 0)   {
            stmtInsert = con.prepareStatement(queryInsert, PreparedStatement.RETURN_GENERATED_KEYS);
        } 

        if (queryUpdate != null && queryUpdate.length() > 0)   {
            stmtUpdate = con.prepareStatement(queryUpdate, PreparedStatement.NO_GENERATED_KEYS);
            System.out.println("update query =" + queryUpdate);
        } 

        if (queryDelete != null && queryDelete.length() > 0)   {
            stmtDelete = con.prepareStatement(queryDelete, PreparedStatement.NO_GENERATED_KEYS);
        }
    }
    
    public DBPreparedStatement(Connection argConnection, /*, DBOperation operation, */
                                    String queryInsert, String queryDelete, 
                                    String queryUpdate) throws SQLException   {
        con = argConnection;
            
        if (queryInsert != null && queryInsert.length() > 0)   {
            stmtInsert = con.prepareStatement(queryInsert, PreparedStatement.RETURN_GENERATED_KEYS);
        } 

        if (queryUpdate != null && queryUpdate.length() > 0)   {
            stmtUpdate = con.prepareStatement(queryUpdate, PreparedStatement.NO_GENERATED_KEYS);
            System.out.println("update query =" + queryUpdate);
        } 

        if (queryDelete != null && queryDelete.length() > 0)   {
            stmtDelete = con.prepareStatement(queryDelete, PreparedStatement.NO_GENERATED_KEYS);
        }
       
    }
    
    public int [] execute() throws SQLException {
        
        int [] result = null;
           
        if (stmtDelete != null)  {
            stmtDelete.executeBatch();
        }

        if (stmtInsert != null)  {
            result = stmtInsert.executeBatch();
        } 

        if (stmtUpdate != null)  {
            stmtUpdate.executeBatch();
        }  
          
        return result;
    }
    
    public abstract void addInsertBatch(Object data, OrderedInsensitiveMap map) throws FocusException;
    public abstract void addDeleteBatch(Object data, OrderedInsensitiveMap map) throws FocusException;
    public abstract void addUpdateBatch(Object data, OrderedInsensitiveMap map) throws FocusException;
}
