/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 *
 * @author sathyaji.raja
 */
public class FocusConfigUtils {
    
    public static void initialize(Object[] arguments)  {
        
        String contextValue = (String)arguments[0];
        String[] classInitializers = contextValue.split(",");
        if (classInitializers != null && classInitializers.length > 0)  {

            for (int index=0; index < classInitializers.length; index++)    {
                try {
                    // Load the class
                    FocusAppInitializer appInit = 
                                (FocusAppInitializer)Class.forName(classInitializers[index]).newInstance();
                    appInit.Initialize(arguments);
                } catch (Exception ex) {
                    //FocusLogger.debug("Failed to load class - ", ex); 
                }
            }
        }
    }
}
