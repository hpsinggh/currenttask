/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

/**
 *
 * @author sathyaji.raja
 */
public interface ConfigReader {
    
    ConfigInfo getConfigInfo();
}
