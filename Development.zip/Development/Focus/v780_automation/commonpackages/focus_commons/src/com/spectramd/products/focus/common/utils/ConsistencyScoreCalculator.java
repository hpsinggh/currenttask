/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusLogger;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * 
 * @author pratapkonakala
 */
public class ConsistencyScoreCalculator {
    
    /**
     * This method is used to calculate the consistency score for satisfaction measures.
     * @param floorValueList
     * @param achievementValueList
     * @param percentFactorValueList
     * @return 
     */
    public static int getConsistencyScore(List<Double> floorValueList, List<Double> achievementValueList, List<Double> percentFactorValueList) {
        FocusConfig.getCurrentLogger().writeDebug("Entered into ConsistencyScoreCalculator :: getConsistencyScore");
        boolean consistencyScoreZero = false;
        int index = 0;
        if(percentFactorValueList != null && achievementValueList != null && floorValueList != null){
            /**
             * This logic is check whether any HCAHPS measure is less than Floor value
             * then consistency value is '0'
             */
            for(Double percentValue : percentFactorValueList){
                if(percentValue < floorValueList.get(index)){
                    consistencyScoreZero = true;
                    break;
                }
                index++;
            }
            boolean consistencyScoreTwenty = false;
            if(consistencyScoreZero){
                FocusConfig.getCurrentLogger().writeDebug("Consistency score is zero");
                FocusConfig.getCurrentLogger().writeDebug("Exit of ConsistencyScoreCalculator :: getConsistencyScore");
                return 0;
            }else{
                /**
                * If consistency score is not 0 then check whether all HCAHPS measure are greater than Achievement Threshold value
                * then consistency value is '20'
                */
                index = 0;
                for(Double percentValue : percentFactorValueList){
                    if(percentValue > achievementValueList.get(index)){
                        consistencyScoreTwenty = true;
                    }else{
                        consistencyScoreTwenty = false;
                        break;
                    }
                    index++;
                }  
            }
            Set<Double> consistencyScoreValues = new TreeSet<Double>();
            if(consistencyScoreTwenty){
                FocusConfig.getCurrentLogger().writeDebug("Consistency score is 20");
                FocusConfig.getCurrentLogger().writeDebug("Exit of ConsistencyScoreCalculator :: getConsistencyScore");
                return 20;
            }else{
                /**
                 * if consistency score is not 0 and 20 then it will execute the below logic.
                 * In this case consistency score is calculated with formula
                 * Formula - (HPPS - Floor)/(AT-Floor) 
                 * Get Lost value of a measure(Lowest Dimension) then finally 
                 * consistencyScore = (20*LD)-0.5 --> round the value.
                 * 
                 */
                index = 0;
                for(Double percentValue : percentFactorValueList){
                   
                    if(percentValue > floorValueList.get(index)
                            && percentValue < achievementValueList.get(index)){
                        
                        double numerator = percentValue-floorValueList.get(index);
                        double denominator = achievementValueList.get(index)-floorValueList.get(index);
                        double consistencyScore = (numerator/denominator);
                        consistencyScoreValues.add(consistencyScore);
                        FocusConfig.getCurrentLogger().writeDebug("Consistency Score = "+ 
                                    consistencyScore + ", nmr="+ numerator+ ", dnr=" + denominator) ;
                    }
                    index++;
                }
                //FocusConfig.getCurrentLogger().writeDebug("Exit of ConsistencyScoreCalculator :: getConsistencyScore");
                
                double updatedConsistencyScore = consistencyScoreValues.iterator().next();
                int consistencyScore = (int)Math.round((20*updatedConsistencyScore)-0.5);
                
                FocusConfig.getCurrentLogger().writeDebug("Exit of ConsistencyScoreCalculator :: "
                                        + "getConsistencyScore, value = "+ consistencyScore);
                return consistencyScore;
            }
        }
        FocusConfig.getCurrentLogger().writeDebug("Exit of ConsistencyScoreCalculator :: getConsistencyScore");
        return 0;
    }
}
