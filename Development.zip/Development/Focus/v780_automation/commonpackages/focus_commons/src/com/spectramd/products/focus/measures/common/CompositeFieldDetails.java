/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author pratapkonakala
 */
public class CompositeFieldDetails extends BaseFieldDetails{
    
    public CompositeFieldDetails(FieldDetails details){
        super(details);
    }
    private List<BaseFieldDetails> fieldDetailsList = new ArrayList<BaseFieldDetails>();

    @Override
    public void addFieldDetails(BaseFieldDetails baseFieldDetails) {
        fieldDetailsList.add(baseFieldDetails);
    }

    @Override
    public List<BaseFieldDetails> getChildren() {
        return fieldDetailsList;
    }

    @Override
    public void setChildren(List<BaseFieldDetails> fieldDetailsList) {
        Collections.sort(fieldDetailsList,new Comparator<BaseFieldDetails>(){
            @Override
            public int compare(BaseFieldDetails baseFieldDetails1, BaseFieldDetails baseFieldDetails2) {
                if(baseFieldDetails1.getFieldDetails().getSequenceNumber() >  baseFieldDetails2.getFieldDetails().getSequenceNumber()){
                    return 1;
                }
                if(baseFieldDetails1.getFieldDetails().getSequenceNumber() <  baseFieldDetails2.getFieldDetails().getSequenceNumber()){
                    return -1;
                }
                return 0;
            }
        });
        this.fieldDetailsList = fieldDetailsList;
    }
}
