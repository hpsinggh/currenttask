/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.spectramd.products.focus.measures.common;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

/**
 *
 * @author sathyaji.raja
 */
public enum FieldType {
    NONE, INT, BIGINT, STRING, DECIMAL, DATE, BOOLEAN, MAP, LIST, VOID;
    
    public static FieldType getFieldType(String type) {
        
        if (type.equalsIgnoreCase("STRING"))
            return FieldType.STRING;
        else if (type.equalsIgnoreCase("BIGINT"))
            return FieldType.BIGINT;
        else if (type.equalsIgnoreCase("INT"))
            return FieldType.INT;
        else if (type.equalsIgnoreCase("DATETIME") || type.equalsIgnoreCase("DATE"))
            return FieldType.DATE;
        else if (type.equalsIgnoreCase("DECIMAL"))
            return FieldType.DECIMAL;
        else if (type.equalsIgnoreCase("BOOLEAN"))
            return FieldType.BOOLEAN;
        else if (type.equalsIgnoreCase("MAP"))
            return FieldType.MAP;
        else if (type.equalsIgnoreCase("LIST"))
            return FieldType.LIST;
        else if (type.equalsIgnoreCase("VOID"))
            return FieldType.VOID;
        else 
            return FieldType.NONE;
    }
    
    public static Class getFieldClass(FieldType type) {
        
        switch (type){
            case BIGINT:
                return long.class;
            case INT:
                return int.class;
            case DATE:
                return Date.class;
            case DECIMAL:
                return double.class;
            case BOOLEAN:
                return boolean.class;
            case LIST:
                return ArrayList.class;
            case MAP:
                return HashMap.class;
            case VOID:
                return Object.class;
            default:
            case NONE:
            case STRING:
                return String.class;
            
        }
     }
    
     public static Object getFieldValue(String valueInString, FieldType type) {
         Object retValue = valueInString;
         
         switch (type){
            case BIGINT:
                retValue = Long.parseLong(valueInString);
                break;
            case INT:
                retValue = Integer.parseInt(valueInString);
                break;
            case DECIMAL:
                retValue = Double.parseDouble(valueInString);
                break;
            case BOOLEAN:
                retValue = Boolean.parseBoolean(valueInString);
                break;
            default:
            case DATE:
            case NONE:
            case STRING:
                break;
        }
         
         return retValue;
     }
}
