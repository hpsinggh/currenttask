/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

/**
 *
 * @author sathyaji.raja
 */
public enum DBOperation {
    INSERT, UPDATE, DELETE_INSERT, DELETE
}
