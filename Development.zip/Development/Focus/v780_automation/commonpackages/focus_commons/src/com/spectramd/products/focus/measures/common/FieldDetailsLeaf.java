/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

import java.util.List;

/**
 *
 * @author pratapkonakala
 */
public class FieldDetailsLeaf extends BaseFieldDetails{

    public FieldDetailsLeaf(FieldDetails details){
        super(details);
    }
    
    @Override
    public void addFieldDetails(BaseFieldDetails baseFieldDetails) {
    }

    @Override
    public List<BaseFieldDetails> getChildren() {
        return null;
    }

    @Override
    public void setChildren(List<BaseFieldDetails> fieldDetailsList) {
    }
    
}
