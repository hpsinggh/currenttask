/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.math.BigInteger;
import java.security.Key;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.RSAPrivateKeySpec;
import java.security.spec.RSAPublicKeySpec;
import javax.crypto.Cipher;

/**
 *
 * @author sathyaji.raja
 */
public class CryptographyUtils {

    public static PublicKey readPublicKeyFromFile(String file) throws Exception {
        ObjectInputStream oin = null;
        InputStream in = null;
        PublicKey pubKey = null;
        Key key = null;
        try {
            in = new FileInputStream(file);
            oin = new ObjectInputStream(new BufferedInputStream(in));
            BigInteger m = (BigInteger) oin.readObject();
            BigInteger e = (BigInteger) oin.readObject();
            KeyFactory fact = KeyFactory.getInstance("RSA");

            RSAPublicKeySpec keySpec = new RSAPublicKeySpec(m, e);
            pubKey = fact.generatePublic(keySpec);
        } finally {
            if (in != null) {
                in.close();
            }
            if (oin != null) {
                oin.close();
            }
        }
        return pubKey;
    }

    public static PrivateKey readPrivateKeyFromFile(String file) throws Exception {
        InputStream in = null;
        ObjectInputStream oin = null;
        PrivateKey privateKey = null;
        try {
            in = new FileInputStream(file);
            oin = new ObjectInputStream(new BufferedInputStream(in));
            BigInteger m = (BigInteger) oin.readObject();
            BigInteger e = (BigInteger) oin.readObject();
            KeyFactory fact = KeyFactory.getInstance("RSA");

            RSAPrivateKeySpec keySpec = new RSAPrivateKeySpec(m, e);
            privateKey = fact.generatePrivate(keySpec);
        } finally {
            if (in != null) {
                in.close();
            }
            if (oin != null) {
                oin.close();
            }
        }
        return privateKey;
    }

    /**
     * 
     * @param data Byte array
     * @param key The public key
     * @param cipherMode The Cipher Mode
     * @return
     * @throws Exception 
     */
    public static byte[] encryptData(byte[] data, Key key) throws Exception {
        ByteArrayInputStream input = null;
        ByteArrayOutputStream bos = null;
        byte[] output = null;

        try {
            bos = new ByteArrayOutputStream();
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");

            String textLine = null;
            byte[] buf = new byte[100];
            int bufTemp;
            cipher.init(Cipher.ENCRYPT_MODE, key);

            // start FileIO
            input = new ByteArrayInputStream(data);
            while ((bufTemp = input.read(buf)) != -1) {
                byte[] encText = null;
                encText = encrypt(copyBytes(buf, bufTemp), (PublicKey) key);
                bos.write(encText);
            }
            output = bos.toByteArray();
        } finally {

            if (bos != null) {
                bos.close();
            }
            if (input != null) {
                input.close();
            }
        }
        return output;
    }

    public static byte[] decryptFile(String srcFileName, Key key, int cipherMode) throws Exception {
        ByteArrayOutputStream bos = null;
        InputStream inputReader = null;
        byte[] data = null;
        try {
            bos = new ByteArrayOutputStream();
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            String textLine = null;
            byte[] buf = cipherMode == Cipher.ENCRYPT_MODE ? new byte[100] : new byte[128];
            int bufl;
            // init the Cipher object for Encryption...
            cipher.init(cipherMode, key);

            // start FileIO
            inputReader = new FileInputStream(srcFileName);
            while ((bufl = inputReader.read(buf)) != -1) {
                byte[] encText = decrypt(copyBytes(buf, bufl), (PrivateKey) key);
                bos.write(encText);
            }
            data = bos.toByteArray();

        } finally {
            if (bos != null) {
                bos.close();
            }
            if (inputReader != null) {
                inputReader.close();
            }
        }

        return data;
    }

    public static byte[] decryptFile(InputStream inputStream, Key key, int cipherMode) throws Exception {
        ByteArrayOutputStream bos = null;
        byte[] data = null;
        try {
            bos = new ByteArrayOutputStream();
            Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
            String textLine = null;
            byte[] buf = cipherMode == Cipher.ENCRYPT_MODE ? new byte[100] : new byte[128];
            int bufl;
            // init the Cipher object for Encryption...
            cipher.init(cipherMode, key);

            // start FileIO
            while ((bufl = inputStream.read(buf)) != -1) {
                byte[] encText = decrypt(copyBytes(buf, bufl), (PrivateKey) key);
                bos.write(encText);
            }
            data = bos.toByteArray();

        } finally {
            if (bos != null) {
                bos.close();
            }
            if (inputStream != null) {
                inputStream.close();
            }
        }

        return data;
    }
    
    public static byte[] copyBytes(byte[] arr, int length) {
        byte[] newArr = null;
        if (arr.length == length) {
            newArr = arr;
        } else {
            newArr = new byte[length];
            for (int i = 0; i < length; i++) {
                newArr[i] = (byte) arr[i];
            }
        }
        return newArr;
    }

    public static byte[] encrypt(byte[] text, PublicKey key) throws Exception {
        byte[] cipherText = null;
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        // encrypt the text using public key
        cipher.init(Cipher.ENCRYPT_MODE, key);
        cipherText = cipher.doFinal(text);

        return cipherText;
    }

    public static byte[] decrypt(byte[] text, PrivateKey key) throws Exception {
        byte[] dectyptedText = null;
        // decrypt the text using the private key
        Cipher cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding");
        cipher.init(Cipher.DECRYPT_MODE, key);
        dectyptedText = cipher.doFinal(text);
        return dectyptedText;
    }
}
