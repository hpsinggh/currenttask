/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common.jobdata;

/**
 *
 * @author sathyaji.raja
 */
public class MeasureJobData extends MeasureTypeJobData {
    
        //private int progCoverageKey;
        private int progIncentiveKey;
        private long measureKey;
        private String progIncentiveCode;
        private String measureCode;
        private long progStartDateKey;
        private long progEndDateKey;
        
        public MeasureJobData() {
            
        }
        
        public MeasureJobData(long measureKey, int progIncentiveKey) {//, int progCoverageKey) {
            this.measureKey = measureKey;
            this.progIncentiveKey = progIncentiveKey;
           // this.progCoverageKey = progCoverageKey;
        }
        
//        public int getProgCoverageKey() {
//            return progCoverageKey;
//        }
//        
//        public void setProgCoverageKey(int argProgCoverageKey)   {
//            progCoverageKey = argProgCoverageKey;
//        }
        
        public int getprogIncentiveKey() {
            return progIncentiveKey;
        }
        
        public void setProgIncentiveKey(int argProgIncentiveKey)   {
            progIncentiveKey = argProgIncentiveKey;
        }
        
        public long getMeasureKey() {
            return measureKey;
        }
        
        public void setMeasureKey(long argMeasureKey)   {
            measureKey = argMeasureKey;
        }
        
        public long getProgStartDateKey() {
            return progStartDateKey;
        }
        
        public void setProgStartDateKey(long argProgStartDateKey)   {
            progStartDateKey = argProgStartDateKey;
        }
        
        public long getProgEndDateKey() {
            return progEndDateKey;
        }
        
        public void setProgEndDateKey(long argProgEndDateKey)   {
            progEndDateKey = argProgEndDateKey;
        }

    public String getProgIncentiveCode() {
        return progIncentiveCode;
    }

    public void setProgIncentiveCode(String progIncentiveCode) {
        this.progIncentiveCode = progIncentiveCode;
    }

    public String getMeasureCode() {
        return measureCode;
    }

    public void setMeasureCode(String measureCode) {
        this.measureCode = measureCode;
    }
}
