/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.utils;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.joda.time.DateTime;
import org.joda.time.Days;
import org.joda.time.Hours;
import org.joda.time.Minutes;
import org.joda.time.Months;
import org.joda.time.Years;
import org.joda.time.Weeks;

/**
 *
 * @author ramya.khasnis
 */
public class eMeasureFunctions {

    /**
     * Method to check if the given list is not null and not empty
     *
     * @param alist
     * @return
     */
    public static boolean notEmpty(List alist) {
        if (alist != null && alist.size() > 0) {
            return true;
        }
        return false;
    }

    /**
     * filterList : method filters the dataList based on the parameters
     *
     * @param dataList - a list of Map objects
     * @param parametersList - a list of parameters. Each parameter is a
     * objectArray of length 4 -6 parameter[0] = key in the dataMap, the
     * attribute that needs to be compared parameter[1] = operator, e.g.
     * "contains" for list, "=" "<" for decimal, "=" for string "SBS",
     * "SAS:low:inclusive:5","EAS", "DURING", "SBE:inverse" etc parameter[2] =
     * value, it can be a List, double, string, date parameter[3] = datatype of
     * parameter[2] LIST, DECIMAL, STRING, DATE parameter[4] = unit of the value
     * in parameter[2], can be null parameter[5] = additionalValue, for dateTime
     * comparision this additionalValue represents duration
     * @return - a filtered list of dataMap that satisfies all the conditions in
     * the parametersList
     */
    public static List<OrderedInsensitiveMap> filterList(List<OrderedInsensitiveMap> dataList,
            Object[]... parametersList) {
        List<OrderedInsensitiveMap> filteredList = new ArrayList<OrderedInsensitiveMap>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
        if (dataList != null) {
            for (Object[] parameters : parametersList) {

                String unit = null;
                Object additionalValue = null;

                //if parameter length is >= 6 get additional value
                if (parameters.length >= 6) {
                    additionalValue = parameters[5];
                }
                //if parameter length is >= 5 get unit
                if (parameters.length >= 5) {
                    unit = (String) parameters[4];
                }
                if (parameters.length >= 4) {
                    //if parameter length is >= 4 get data type
                    String dataType = (String) parameters[3];

                    // Sathya: This needs to be changed to Map
                    if (dataType.equalsIgnoreCase("LIST")) {
                        Set valueKeys = ((Map) parameters[2]).keySet();
                        List valueList = new ArrayList(valueKeys);
                        filteredList = listCompare(parameters[0].toString(), parameters[1].toString(), valueList, dataList, unit, additionalValue);
                    } else if (dataType.equalsIgnoreCase("DECIMAL")) {
                        double valueDouble = Double.parseDouble(parameters[2].toString());
                        filteredList = doubleCompare(parameters[0].toString(), parameters[1].toString(), valueDouble, dataList, unit, additionalValue);
                    } else if (dataType.equalsIgnoreCase("STRING")) {
                        String valueString = (String) parameters[2];
                        filteredList = stringCompare(parameters[0].toString(), parameters[1].toString(), valueString, dataList, unit, additionalValue);
                    } else if (dataType.equalsIgnoreCase("DATETIME")) {
                        try {
                            Date valueDate = null;

                            if (parameters[2] instanceof Date) {
                                valueDate = (Date) parameters[2];
                            } else {
                                valueDate = sdf.parse((String) parameters[2]);
                            }

                            filteredList = dateCompare(parameters[0].toString(), parameters[1].toString(), valueDate, dataList, unit, additionalValue);
                        } catch (Exception ex) {
                            //nothing
                        }
                    } else if (dataType.equalsIgnoreCase("LIST_DATETIME")) {
                        try {
                            List valueList = (List) parameters[2];
                            filteredList = dataCompare(parameters[0].toString(), parameters[1].toString(), valueList, dataList, unit, additionalValue);
                        } catch (Exception ex) {
                            //nothing
                        }
                    }

                    if (filteredList != null && filteredList.size() > 0) {
                        dataList = filteredList;
                    } else {
                        break;
                    }
                }
            }
        }
        return filteredList;
    }

    private static List<OrderedInsensitiveMap> listCompare(String mapkey, String operator, List valueList,
            List<OrderedInsensitiveMap> dataList, String unit, Object additionalValue) {
        List filteredList = new ArrayList();
        List negFilteredList = new ArrayList();
        List<String> operators = Arrays.asList(operator.split(":"));
//        if (operators.contains("negation")) {
//            if (operators.contains("contains")) {
//                for (OrderedInsensitiveMap data : dataList) {
//                    if (valueList.contains(data.get(mapkey))) {
//                        filteredList.add(data);
//                    }else{
//                        negFilteredList.add(data);
//                    }
//                }
//
//                if(!filteredList.isEmpty()){                
//                    filteredList.clear();
//                }else if(!negFilteredList.isEmpty()) {                
//                    filteredList = negFilteredList;
//                }else{
//                    filteredList.add(new OrderedInsensitiveMap());
//                }
//            }
//        } else {
            //operator is contains check if the valueset contains data['mapkey']
            if (operators.contains("contains")) {
                for (OrderedInsensitiveMap data : dataList) {
                    if (valueList.contains(data.get(mapkey))) {
                        filteredList.add(data);
                    } else {
                        negFilteredList.add(data);
                    }
                }
            }else if (operators.contains("not_contains")) {
                // check whether any data doesn't qualify for the valueset
                for (OrderedInsensitiveMap data : dataList) {
                    if (!valueList.contains(data.get(mapkey))) {
                        filteredList.add(data);
                    } else {
                        negFilteredList.add(data);
                    }
                }
            }
        //}
        
        if (operators.contains("negation")) {
            if(!filteredList.isEmpty()) {                
                filteredList.clear();
            } else if(!negFilteredList.isEmpty()) { 
                filteredList = negFilteredList;
            }else{
                filteredList.add(new OrderedInsensitiveMap());
            }
        }
        
        return filteredList;
    }

    private static List<OrderedInsensitiveMap> doubleCompare(String mapkey, String operator, double valueDouble, List<OrderedInsensitiveMap> dataList, String unit, Object additionalValue) {

        List<OrderedInsensitiveMap> filteredList = new ArrayList<OrderedInsensitiveMap>();
        List<OrderedInsensitiveMap> negFilteredList = new ArrayList<OrderedInsensitiveMap>();
        List<String> operators = Arrays.asList(operator.split(":"));

        if (dataList != null && dataList.size() > 0) {
            for (OrderedInsensitiveMap map : dataList) {
                if(map.get(mapkey) != null) {
                    
                    double value = Double.parseDouble(map.get(mapkey).toString());
                    if (operators.contains("<")) {
                        if ((value < valueDouble)) {
                            filteredList.add(map);
                        }else{
                           negFilteredList.add(map);
                        }
                    } else if (operators.contains("<=")) {
                        if ((value <= valueDouble)) {
                            filteredList.add(map);
                        }else{
                           negFilteredList.add(map);
                        }
                    } else if (operators.contains(">")) {
                        if ((value > valueDouble)) {
                            filteredList.add(map);
                        }else{
                           negFilteredList.add(map);
                        }
                    } else if (operators.contains(">=")) {
                        if ((value >= valueDouble)) {
                            filteredList.add(map);
                        }else{
                           negFilteredList.add(map);
                        }
                    }
                }
            }
        }

        if (operators.contains("negation")) {
            if(!filteredList.isEmpty()) {                
                filteredList.clear();
            } else if(!negFilteredList.isEmpty()) { 
                filteredList = negFilteredList;
            }else{
                filteredList.add(new OrderedInsensitiveMap());
            }
        }
        
        return filteredList;
    }

    private static List<OrderedInsensitiveMap> stringCompare(String mapkey, String operator, String valueString, List<OrderedInsensitiveMap> dataList, String unit, Object additionalValue) {
        List<OrderedInsensitiveMap> filteredList = new ArrayList<OrderedInsensitiveMap>();
        List<OrderedInsensitiveMap> negFilteredList = new ArrayList<OrderedInsensitiveMap>();
        List<String> operators = Arrays.asList(operator.split(":"));
        
        //operator is = , check if data['mapkey'] is equal to valueString
        if (operator.equalsIgnoreCase("=")) {
            for (OrderedInsensitiveMap data : dataList) {
                String dataStr = (String) data.get(mapkey);
                if (valueString.equalsIgnoreCase(dataStr)) {
                    filteredList.add(data);
                }else{
                    negFilteredList.add(data);
                }
            }
        }
    
        if (operators.contains("negation")) {
            if(!filteredList.isEmpty()) {                
                filteredList.clear();
            } else if(!negFilteredList.isEmpty()) { 
                filteredList = negFilteredList;
            }else{
                filteredList.add(new OrderedInsensitiveMap());
            }
        }

        return filteredList;
    }

    private static List<OrderedInsensitiveMap> dateCompare(String mapkey, String operator, Date valueDate, List<OrderedInsensitiveMap> dataList, String unit, Object additionalValue) throws ParseException {
        List<OrderedInsensitiveMap> filteredList = new ArrayList<OrderedInsensitiveMap>();
        List<OrderedInsensitiveMap> negFilteredList = new ArrayList<OrderedInsensitiveMap>();
        //split the given operator by ":" get all the sub-operators e.g operator "SAS:inverse:inclusive:high:2"
        List<String> operators = Arrays.asList(operator.split(":"));

        for (OrderedInsensitiveMap data : dataList) {
            String lhsDateStr = (String) data.get(mapkey);
            if (lhsDateStr != null) {
                Date lhsDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0").parse(lhsDateStr);
                Date rhsDate = valueDate;

                Boolean result = dateCompare(lhsDate, rhsDate, operators, unit, additionalValue);

                // if result is true add the data to filteredList
                if (result) {
                    filteredList.add(data);
                } else { //if (operators.contains("negation")) {
                    negFilteredList.add(data);
                }
            }
        }


        if (operators.contains("negation")) {
            if(!filteredList.isEmpty()) {                
                filteredList.clear();
            } else if(!negFilteredList.isEmpty()) { 
                filteredList = negFilteredList;
            }else{
                filteredList.add(new OrderedInsensitiveMap());
            }
        }

        return filteredList;
    }

    private static List<OrderedInsensitiveMap> dataCompare(String mapkey, String operator, List valueList, List<OrderedInsensitiveMap> dataList, String unit, Object additionalValue) throws ParseException {
        List<OrderedInsensitiveMap> filteredList = new ArrayList<OrderedInsensitiveMap>();
        List<OrderedInsensitiveMap> negFilteredList = new ArrayList<OrderedInsensitiveMap>();
        //split the given operator by ":" get all the sub-operators e.g operator "SAS:inverse:inclusive:high:2"
        List<String> operators = Arrays.asList(operator.split(":"));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");

        for (OrderedInsensitiveMap data : dataList) {
            //1. get the lhs date from the map
            String lhsDateStr = (String) data.get(mapkey);
            if (lhsDateStr != null) {
                Date lhsDate = sdf.parse(lhsDateStr);
                //Boolean result = false;
                Boolean resultSuccessAdded = false;
                Boolean resultFailedAdded = false;
                //2. iterate through valueList can compare lhs date with each one in the valueList
                for (int index = 0; index < valueList.size(); index++) {
                    Date rhsDate = sdf.parse((String) valueList.get(index));
                    Object additionalValueObj = additionalValue;
                    //3. if the additionValue is List of date time values then get the item at index
                    // and additionValueObj =  additionalValue.get(index)
                    if (additionalValue instanceof List) {
                        additionalValueObj = ((List) additionalValue).get(index);
                        if(additionalValueObj != null){
                            additionalValueObj = sdf.parse((String) additionalValueObj);
                        }
                    }
                    
                    Boolean result = dateCompare(lhsDate, rhsDate, operators, unit, additionalValueObj);
                    // if result is true add the data to filteredList
                    //Check whether result is true then add to filteredList if not added 
                    if (result) {
                        if(!resultSuccessAdded){
                            filteredList.add(data);
                            resultSuccessAdded = true;
                        }
                    }else{
                        //Check whether operator contains negation and not added to negation list then add
                        if(operators.contains("negation") && !resultFailedAdded){
                            negFilteredList.add(data);
                            resultFailedAdded = true;
                        }
                }
                }
            }
        }
        
        if (operators.contains("negation")) {
            if(!filteredList.isEmpty()) {                
                filteredList.clear();
            } else if(!negFilteredList.isEmpty()) { 
                filteredList = negFilteredList;
            }else{
                filteredList.add(new OrderedInsensitiveMap());
            }
        }
        
        return filteredList;
    }

    private static boolean dateCompare(Date lhsDate, Date rhsDate, List<String> operators, String unit, Object additionalValue) throws ParseException {

        Boolean result = false;
        //1. if operator contains inverse the exchange the lhsdate with rhsdate
        if (operators.contains("inverse") || operators.contains("inversion")) {
            Date temp = new Date(lhsDate.getTime());
            lhsDate = new Date(rhsDate.getTime());
            rhsDate = temp;
        }

        //2. if the 1st operator is SAS, SAE, EAS, EAE check if lhsDate is after rhsDate
        //else if 1st operator is SBS, SBE, EBS, EBE check if lhsDate is before rhsDate
        if (((operators.get(0).equalsIgnoreCase("SAS")
                || operators.get(0).equalsIgnoreCase("SAE")
                || operators.get(0).equalsIgnoreCase("EAS")
                || operators.get(0).equalsIgnoreCase("EAE"))
                && (lhsDate.after(rhsDate) || lhsDate.equals(rhsDate)))
                || ((operators.get(0).equalsIgnoreCase("SBS")
                || operators.get(0).equalsIgnoreCase("SBE")
                || operators.get(0).equalsIgnoreCase("EBS")
                || operators.get(0).equalsIgnoreCase("EBE"))
                && (lhsDate.before(rhsDate) || lhsDate.equals(rhsDate))) 
             || ((operators.get(0).equalsIgnoreCase("SCW")
                || operators.get(0).equalsIgnoreCase("ECW")
                ||operators.get(0).equalsIgnoreCase("CONCURRENT"))
                && lhsDate.equals(rhsDate))) {
            //2.1 if unit and additional value both are present the check if the duration 
            //between lhs and rhs is within the additional value
            if (unit != null && !unit.equalsIgnoreCase("null") 
                    && additionalValue != null && !additionalValue.toString().equalsIgnoreCase("null")) {
                //2.2. get the duration
                double duration = getDuration(lhsDate, rhsDate, unit);
                duration = Math.abs(duration);

                long additionalLongValue = new Long(additionalValue.toString());

                //if operator conatins is low and inclusive check duration >= additional value else duration > additional value
                if (operators.contains("low")) {
                    if ((operators.contains("inclusive") && duration >= additionalLongValue)
                            || (duration > additionalLongValue)) {
                        result = true;
                    }
                } //if operator conatins is high and inclusive check duration <= additional value else duration < additional value
                else if (operators.contains("high")) {
                    if ((operators.contains("inclusive") && duration <= additionalLongValue)
                            || (duration < additionalLongValue)) {
                        result = true;
                    }
                } else if (operators.contains("equal")) {
                    if (duration == additionalLongValue) {
                        result = true;
                    }
                }
            } else {
                result = true;
            }
        } else if (operators.get(0).equalsIgnoreCase("DURING")
                || operators.get(0).equalsIgnoreCase("SDU")
                || operators.get(0).equalsIgnoreCase("EDU")) {
            //if the operator is DURING or SDU additional value is endDate and rhsDate is startDate of duration
            //check lhsdate is within rhsDate and additional value
            Date additionalValueDate = null;
            if (additionalValue instanceof Date) {
                additionalValueDate = (Date) additionalValue;
            } else {
                if(additionalValue != null){
                additionalValueDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0").parse((String) additionalValue);
                }
            }

            if ((lhsDate.equals(rhsDate)) || (lhsDate.equals(additionalValueDate))
                    || (additionalValueDate != null && lhsDate.after(rhsDate) && lhsDate.before(additionalValueDate))) {
                result = true;
            }
        }
        return result;
    }

    public static double getDuration2(String lhsDateStr, String rhsDateStr, String unit) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.0");
            Date  lhsDate = sdf.parse(lhsDateStr);
            Date rhsDate = sdf.parse(rhsDateStr);
            return getDuration(lhsDate, rhsDate, unit);
        } catch (Exception ex) {
        }
        
        return -1;
    }
    /**
     * calculates and returns the duration between given dates in given unit
     *
     * @param lhsDate - startDateTime
     * @param rhsDate - endDateTime
     * @param unit - a=years, d=days, h=hours, mo= months, min= minutes
     * @return
     */
    public static double getDuration(Date lhsDate, Date rhsDate, String unit) {
        DateTime startDate = new DateTime(lhsDate.getTime());
        DateTime endDate = new DateTime(rhsDate.getTime());
        double duration = 0;
        if (unit.equalsIgnoreCase("a")) {
            duration = Years.yearsBetween(startDate, endDate).getYears();
        } else if (unit.equalsIgnoreCase("d")) {
            duration = Days.daysBetween(startDate, endDate).getDays();
        } else if (unit.equalsIgnoreCase("h")) {
            duration = Minutes.minutesBetween(startDate, endDate).getMinutes();
            //duration = Hours.hoursBetween(startDate, endDate).getHours();
            duration  = duration/60.0;
        } else if (unit.equalsIgnoreCase("mo")) {
            duration = Months.monthsBetween(startDate, endDate).getMonths();
        } else if (unit.equalsIgnoreCase("min")) {
            duration = Minutes.minutesBetween(startDate, endDate).getMinutes();
        } else if (unit.equalsIgnoreCase("wk")) {
            duration = Weeks.weeksBetween(startDate, endDate).getWeeks();
        }
        return duration;
    }

    public static boolean filterElement(Object value, Object[] parameters) {
        boolean result = false;
        String unit = null;
        Object additionalValue = null;
        String operator = (String) parameters[0];
        List<String> operators = Arrays.asList(operator.split(":"));

        if (value != null) {

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
            if (parameters.length >= 5) {
                try {
                    additionalValue = parameters[4];
                    unit = (String) parameters[3];
                    String dataType = (String) parameters[2];
                    Date lhsDate = sdf.parse((String) value);


                    if (dataType.equalsIgnoreCase("DATETIME")) {

                        Date rhsDate = null;
                        if (parameters[1] != null) {
                            if (parameters[1] instanceof Date) {
                                rhsDate = (Date) parameters[1];
                            } else {
                                rhsDate = sdf.parse((String) parameters[1]);
                            }

                            result = dateCompare(lhsDate, rhsDate, operators, unit, additionalValue);
                        }

                    } else if (dataType.equalsIgnoreCase("LIST_DATETIME")) {

                        if (parameters[1] != null) {
                            List rhsList = (List) parameters[1];
                            int index = 0;

                            for (Object rhsValue : rhsList) {
                                if (rhsValue != null) {
                                    Date rhsDate = sdf.parse((String) rhsValue);
                                    Object additionalObj = additionalValue;
                                    if (additionalValue instanceof List) {
                                        additionalObj = ((List) additionalValue).get(index);
                                        additionalObj = sdf.parse((String) additionalObj);
                                    }
                                    result = dateCompare(lhsDate, rhsDate, operators, unit, additionalObj);
                                    if (result) {
                                        break;
                                    }
                                }
                            }
                        }
                    }
                } catch (Exception ex) {
                    //nothing
                }
            }
        }
        
        if(operators.contains("negation")){
            result = !result;
        }
        return result;
    }

    public static List<OrderedInsensitiveMap> filterReverseList(List<OrderedInsensitiveMap> dataList, Object[] parameters) {
        List<OrderedInsensitiveMap> filteredList = new ArrayList<OrderedInsensitiveMap>();
        List<OrderedInsensitiveMap> negFilteredList = new ArrayList<OrderedInsensitiveMap>();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");

        if (dataList != null) {

            String unit = null;
            Object additionalValue = null;

            //if parameter length is >= 6 get additional value
            if (parameters.length >= 6) {

                additionalValue = parameters[5];
                unit = (String) parameters[4];
                String dataType = (String) parameters[3];
                String operator = (String) parameters[1];
                List<String> operators = Arrays.asList(operator.split(":"));


                if (dataType.equalsIgnoreCase("DATETIME")) {
                    try {
                        Date valueDate = null;
                        if (parameters[2] != null) {
                            if (parameters[2] instanceof Date) {
                                valueDate = (Date) parameters[2];
                            } else {
                                valueDate = sdf.parse((String) parameters[2]);
                            }

                            for (OrderedInsensitiveMap data : dataList) {
                                String rhsDateStr = (String) data.get(parameters[0]);
                                if (rhsDateStr != null) {
                                    Date rhsDate = sdf.parse(rhsDateStr);
                                    Date lhsDate = valueDate;
                                    Object additionalObj = additionalValue;

                                    if (operators.contains("DURING") || operators.contains("SDU")
                                            || operators.contains("EDU")) {
                                        
                                        additionalObj = data.get(additionalValue);
                                        additionalObj = sdf.parse((String) additionalObj);
                                    }

                                    Boolean result = dateCompare(lhsDate, rhsDate, operators, unit, additionalObj);

                                    // if result is true add the data to filteredList
                                    if (result) {
                                        filteredList.add(data);
                                    } else if (operators.contains("negation")) {
                                        negFilteredList.add(data);
                                    }
                                }
                            }


                            if (operators.contains("negation")) {
                                
                                  if(!filteredList.isEmpty()){                
                                        filteredList.clear();
                                    }else if(!negFilteredList.isEmpty()) {                
                                    filteredList = negFilteredList;
                                } else {
                                        filteredList.add(new OrderedInsensitiveMap());
                                }
                            }

                        }
                    } catch (Exception ex) {
                        //nothing
                    }
                } else if (dataType.equalsIgnoreCase("LIST_DATETIME")) {
                    try {
                        List valueList = (List) parameters[2];
                        for (OrderedInsensitiveMap data : dataList) {
                            //1. get the lhs date from the map
                            String rhsDateStr = (String) data.get(parameters[0]);
                            if (rhsDateStr != null) {
                                Date rhsDate = sdf.parse(rhsDateStr);
                                Boolean result = false;
                                Boolean resultSuccessAdded = false;
                                Boolean resultFailedAdded = false;
                                //2. iterate through valueList can compare lhs date with each one in the valueList
                                for (int index = 0; index < valueList.size(); index++) {
                                    Date lhsDate = sdf.parse((String) valueList.get(index));
                                    Object additionalValueObj = additionalValue;

                                    if (operators.contains("DURING") || operator.contains("SDU")
                                            || operators.contains("EDU")) {
                                        if (additionalValue instanceof List) {
                                            additionalValueObj = ((List) additionalValue).get(index);
                                        }else{
                                        additionalValueObj = data.get(additionalValue);
                                        }
                                        if(additionalValueObj != null){
                                            additionalValueObj = sdf.parse((String) additionalValueObj);
                                        }
                                    }
                                    result = dateCompare(lhsDate, rhsDate, operators, unit, additionalValueObj);
                                    // if result is true add the data to filteredList
                                     //Check whether result is true then add to filteredList if not added 
                                    if (result) {
                                        if(!resultSuccessAdded){
                                        filteredList.add(data);
                                            resultSuccessAdded = true;
                                }
                                    }else{
                                        //Check whether operator contains negation and not added to negation list then add
                                        if(operators.contains("negation") && !resultFailedAdded){
                                    negFilteredList.add(data);
                                         resultFailedAdded = true;
                                        }
                                    }
                                }
                               /* if (operators.contains("negation") && !result) {
                                    negFilteredList.add(data);
                                }*/
                            }
                        }
                        if (operators.contains("negation")) {
                              if(!filteredList.isEmpty()){                
                                    filteredList.clear();
                                }else if(!negFilteredList.isEmpty()) {                
                                filteredList = negFilteredList;
                            } else {
                                    filteredList.add(new OrderedInsensitiveMap());
                            }
                        }
                    } catch (Exception ex) {
                        //nothing
                    }
                }
            }

        }
        return filteredList;
    }
    
    /**
     * This method is used to calculate the cumulative medication duration
     * @param dataList
     * @return List of OrderedIncensitiveMap
     */
    public static List<OrderedInsensitiveMap> cumulativeMedicationDurationList(List<OrderedInsensitiveMap> dataList) {
        List<OrderedInsensitiveMap> resultMapList = new ArrayList<OrderedInsensitiveMap>();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.0");
        OrderedInsensitiveMap resultMap = new OrderedInsensitiveMap();
        double cumulativeMedicationDuration = 0;
        boolean resultMapProcessed = false;
        
        //1. Check whether datalist is not null
        if (dataList != null) {
            //2.Iterate the datalist
            for(OrderedInsensitiveMap map : dataList){
                
                //3. Check resultMap created otherwise create
                if(!resultMapProcessed){
                    resultMap = new OrderedInsensitiveMap(map);
                    resultMapProcessed = true;
                }
                
                //3. Calculate the days between startDateTime and endDateTime dates
                double days = 0;
                try {
                    days = getDuration(sdf.parse((String)map.get("startDateTime")),
                            sdf.parse((String)map.get("endDateTime")),"d");
                } catch (Exception ex) {
                }
                
                //4. Get repeatNumber (refills)
                double refills = (Double)map.get("repeatNumber");
                
                //TODO: Temp fix as there is no data for repeatNumber
                refills = refills == 0 ? 1 : refills;
                
                //5. Calculate cumulative medicationDuration 
                cumulativeMedicationDuration = cumulativeMedicationDuration + (refills * days);
            }
            resultMap.put("cumulativeMedDuration", cumulativeMedicationDuration);
            resultMapList.add(resultMap);
        }
        //10. Return the List of map
        return resultMapList;
    }

}
