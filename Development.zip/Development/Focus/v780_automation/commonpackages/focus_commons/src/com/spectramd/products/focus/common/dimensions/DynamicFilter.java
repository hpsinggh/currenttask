package com.spectramd.products.focus.common.dimensions;

import java.util.ArrayList;
import java.util.List;

/**
 * Applies the list of column filters to ES Query clause,<br> by default all the
 * ColumnFilters will be added with an "OR" condition.<br> This class can be
 * further enhanced to have an operator field to support different operations(LT, GT,
 * BETWEEN etc) and generate ES compliant queries.
 *
 * @author niranjan.velakanti
 */
public class DynamicFilter {

    private List<ColumnFilter> columnFilters;

    public List<ColumnFilter> getColumnFilters() {
        return columnFilters;
    }

    public void setColumnFilters(List<ColumnFilter> columnFilters) {
        this.columnFilters = columnFilters;
    }

    public void addColumnFilter(final ColumnFilter columnFilter) {
        if (columnFilters == null) {
            columnFilters = new ArrayList<ColumnFilter>();
        }
        columnFilters.add(columnFilter);
    }

}
