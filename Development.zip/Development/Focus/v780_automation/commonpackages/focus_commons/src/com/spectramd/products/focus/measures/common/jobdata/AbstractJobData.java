/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common.jobdata;

/**
 *
 * @author sathyaji.raja
 */
public abstract class AbstractJobData   {
    
    private long jobId = -1;
  
    private long measureId = -1;
   
    public long getJobId()  {
        return jobId;
    }
    
    public void setJobId(long argJobId) {
        jobId = argJobId;
    }
    
    public long getMeasureId() {
        return measureId;
    }

    public void setMeasureId(long argMeasureId) {
        this.measureId = argMeasureId;
    }
    
}
