/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.common.FocusConfig;
import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author sathyaji.raja
 */
public final class QueryBuilderFactory {
    
	/**
	 * Singleton Instance.
	 */
    private static QueryBuilderFactory instance = new QueryBuilderFactory();
	/**
	 * Map containing Axis Category vs Class Name.
	 */
    private Map<String,String> mapQueryBuilder = new HashMap<String, String>();
    
	/**
	 * Private Constructor.
	 */
     private QueryBuilderFactory() {
        mapQueryBuilder.put("VIEW", "com.spectramd.products.focus.measure.logic.core.utils.ViewDetailsQueryBuilder" );
        mapQueryBuilder.put("SQLVIEW", "com.spectramd.products.focus.measure.logic.core.utils.SqlViewQueryBuilder");
        mapQueryBuilder.put("SPVIEW", "com.spectramd.products.focus.measure.logic.core.utils.ProcedureQueryBuilder");
		mapQueryBuilder.put("ESVIEW",
				"com.spectramd.products.focus.measure.logic.core.utils.ElasticSearchQueryBuilder");
		mapQueryBuilder.put("ESAGGSVIEW",
				"com.spectramd.products.focus.measure.logic.core.utils.ElasticSearchQueryBuilder");
		mapQueryBuilder.put("ESDOCSVIEW",
				"com.spectramd.products.focus.measure.logic.core.utils.ElasticSearchQueryBuilder");
    }
    
	/**
	 * Returns Singleton instance of QueryBuilderFactory.
	 * @return QueryBuilderFactory
	 */
    public static QueryBuilderFactory getInstance()   {
        return instance;
    }
    
	/**
	 * Returns instance of QueryBuilderInterface depending on the provided axis category.
	 * @param queryTypeString String
	 * @return QueryBuilderInterface
	 */
	public QueryBuilderInterface getQueryBuilder(final String queryTypeString) {
     
        QueryBuilderInterface transformer = null;
        try {
            String classNameToCreate = mapQueryBuilder.get(queryTypeString);
            transformer = (QueryBuilderInterface)Class.forName(classNameToCreate).newInstance();
        } catch (Exception ex) {
            FocusConfig.getCurrentLogger().writeError("", ex);
        }
        return transformer;
    }
    
	/**
	 * Returns instance of QueryBuilderInterface depending on the provided ClassName.
	 * @param className String
	 * @return QueryBuilderInterface
	 */
	public QueryBuilderInterface getQueryBuilderFromClassName(final String className) {
     
        QueryBuilderInterface transformer = null;
        if (className.equalsIgnoreCase("com.spectramd.products.focus.measures.common.ViewDetails")) {
            transformer = getQueryBuilder("VIEW");
        } else if (className.equalsIgnoreCase("com.spectramd.products.focus.measures.common.SqlView")) {
             transformer = getQueryBuilder("SQLVIEW");
        }
        return transformer;
    }
}
