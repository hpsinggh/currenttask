/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.collections;

import java.sql.Timestamp;
import java.util.Comparator;

/**
 *
 * @author sathyaji.raja
 */
public class GenericComparator implements Comparator {
    
    private String sortField;
    
    public GenericComparator(String sortField){
        this.sortField = sortField;
    }
    
   
    @Override
    public int compare(Object obj1, Object obj2) {
        //Cast the objects to OrderedInsensitiveMap
        OrderedInsensitiveMap object1 = (OrderedInsensitiveMap) obj1;
        OrderedInsensitiveMap object2 = (OrderedInsensitiveMap) obj2;
        
        //To identify the datatype of the sortField , get the value from object and check the instance
        Object sortFieldValue = object1.get(sortField);
         if(sortFieldValue instanceof Timestamp){
            Timestamp timestampObj1 = (Timestamp)object1.get(sortField);
            Timestamp timestampObj2 = (Timestamp)object2.get(sortField);
            return timestampObj1.compareTo(timestampObj2);
         }else if(sortFieldValue instanceof Integer) {
             Integer integerObj1 = (Integer)object1.get(sortField);
            Integer integerObj2 = (Integer)object2.get(sortField);
            return integerObj1.compareTo(integerObj2);
         }else if(sortFieldValue instanceof Long) {
             Long longObj1 = (Long)object1.get(sortField);
            Long longObj2 = (Long)object2.get(sortField);
            return longObj1.compareTo(longObj2);
         }else if(sortFieldValue instanceof String) {
            return object1.get(sortField).toString().compareTo(object2.get(sortField).toString());
         }
        return 0;
    }
    
}
