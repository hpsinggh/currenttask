/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.utils.MathUtils;
import com.spectramd.products.focus.measures.utils.CollectionExpressionUtils;
import com.spectramd.products.focus.measures.utils.CollectionFunctions;
import com.spectramd.products.focus.measures.utils.DSRIPUtils;
import com.spectramd.products.focus.measures.utils.DateUtils;
import com.spectramd.products.focus.measures.utils.SecondaryDimensionUtils;
import com.spectramd.products.focus.measures.utils.TimeUtils;
import com.spectramd.products.focus.measures.utils.eMeasureFunctions;
import com.spectramd.products.focus.utils.StringUtils;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 *
 * @author sathyaji.raja
 */
public class FocusContextFunctions {

    private static Map<String, Method> functions = new HashMap<String, Method>();

    static {
        try {
            functions.put("dateValue", DateUtils.class.getDeclaredMethod("getDateValue", String.class));
            functions.put("days", DateUtils.class.getDeclaredMethod("getNumberofDays", String.class, String.class));
            functions.put("years", DateUtils.class.getMethod("getNumberofYears", String.class, String.class));
			functions.put("getDays", DateUtils.class.getDeclaredMethod("getNumberofDays", String.class, String.class, String.class));
            functions.put("getDaysForDiffFormats", DateUtils.class.getDeclaredMethod("getNumberofDays", String.class, String.class, String[].class));
            //add months method due to criteria in months by Ankur Gupta
            functions.put("months", DateUtils.class.getMethod("getNumberofMonths", String.class, String.class)); 
            //add weeks method due to criteria in weeks by Ankur Gupta
            functions.put("weeks", DateUtils.class.getMethod("getNumberofWeeks", String.class, String.class));
            functions.put("hours", DateUtils.class.getDeclaredMethod("getNumberofHours", String.class, String.class, String.class, String.class));
            functions.put("minutes", DateUtils.class.getDeclaredMethod("getNumberofMinutes", String.class, String.class, String.class, String.class));
            functions.put("monthkey", DateUtils.class.getDeclaredMethod("getMonthKey", String.class));
            functions.put("weekkey", DateUtils.class.getDeclaredMethod("getWeekKey", String.class));
            functions.put("quarterkey", DateUtils.class.getDeclaredMethod("getQuarterKey", String.class));
            functions.put("fiscalyearkey", DateUtils.class.getDeclaredMethod("getFiscalYearKey", String.class));
            functions.put("addYears", DateUtils.class.getDeclaredMethod("addYears", Date.class, int.class));

            functions.put("number", StringUtils.class.getMethod("stringToLong", String.class));
            functions.put("convertToInteger", StringUtils.class.getMethod("stringToInteger", String.class));
            functions.put("equals", StringUtils.class.getMethod("isEquals", String.class, String.class, boolean.class));
            functions.put("splitString", StringUtils.class.getMethod("splitString", String.class, String.class));

            // time specific functions
            functions.put("timevalue", TimeUtils.class.getMethod("getTimeInDouble", String.class));

            functions.put("sum", MathUtils.class.getMethod("sum", List.class));

            functions.put("checkdate", DateUtils.class.getMethod("checkDate", String.class));
            functions.put("checkDateFormat", DateUtils.class.getMethod("checkDate", new Class[]{String.class, String.class}));
            functions.put("checkDateFormats", DateUtils.class.getMethod("checkDate", new Class[]{String.class, String[].class}));
            functions.put("checkTime", DateUtils.class.getMethod("checkTime", String.class));
            functions.put("mergeDateAndTime", DateUtils.class.getMethod("mergeDateAndTime", new Class[]{String.class, String.class, String.class, String.class}));

            functions.put("insertIntoMap", CollectionExpressionUtils.class.getDeclaredMethod("insertIntoMap",
                    new Class[]{Map.class, String.class, String.class}));
        
            functions.put("evaluateDim", CollectionExpressionUtils.class.getDeclaredMethod("evaluate",
                    new Class[]{List.class, String.class, String.class, String.class}));
            functions.put("evaluate", CollectionExpressionUtils.class.getDeclaredMethod("evaluate",
                    new Class[]{List.class, String.class}));
            functions.put("uniqueList", CollectionFunctions.class.getDeclaredMethod("getUniqueList",
                    new Class[]{List.class, String.class}));
            functions.put("sortedsubset", CollectionFunctions.class.getDeclaredMethod("getSortedSubset",
                    List.class, String.class, String.class, String.class, String.class, String.class));

            functions.put("splitRowColumn", CollectionExpressionUtils.class.getDeclaredMethod("splitRowColumn",
                    new Class[]{String.class, String.class, String.class, String.class, String.class, String.class}));
            functions.put("listMapValue", CollectionExpressionUtils.class.getDeclaredMethod("getValueFromListMap",
                    new Class[]{List.class, String.class, String.class}));
            functions.put("removeListMapValue",
                    CollectionExpressionUtils.class.getDeclaredMethod("removeFromListMap",
                    new Class[]{List.class, String.class, String.class}));

            functions.put("keyValue",
                    CollectionExpressionUtils.class.getDeclaredMethod("getKeyValue",
                    new Class[]{List.class, String.class, String.class, String.class}));

            functions.put("keyList", CollectionFunctions.class.getDeclaredMethod("getKeyListFromListOfMap",
                    new Class[]{List.class, String.class}));
            functions.put("containsAnyKey", CollectionFunctions.class.getDeclaredMethod("containsAnyKey",
                    new Class[]{List.class, List.class}));

            functions.put("evaluateAny", CollectionExpressionUtils.class.getDeclaredMethod("evaluateAny",
                    new Class[]{List.class, String.class, Object.class}));

            functions.put("observationcodes", CollectionExpressionUtils.class.getDeclaredMethod("getObservationCodes",
                    new Class[]{TreeMap.class}));

            functions.put("notEmpty", eMeasureFunctions.class.getDeclaredMethod("notEmpty",
                    new Class[]{List.class}));
            functions.put("filterReverseList", eMeasureFunctions.class.getDeclaredMethod("filterReverseList",
                    new Class[]{List.class, Object[].class}));
            functions.put("filterList", eMeasureFunctions.class.getDeclaredMethod("filterList",
                    new Class[]{List.class, Object[][].class}));
            functions.put("filterElement", eMeasureFunctions.class.getDeclaredMethod("filterElement",
                    new Class[]{Object.class, Object[].class}));
            
            functions.put("getDuration", eMeasureFunctions.class.getDeclaredMethod("getDuration",
                    new Class[]{Date.class, Date.class, String.class}));
            functions.put("getSecondaryDimKey",
                    SecondaryDimensionUtils.class.getMethod("getSecondaryDimensionKey",
                    Object.class, HashMap.class));

            functions.put("getMostRecent", CollectionFunctions.class.getDeclaredMethod("getMostRecent",
                    List.class, String.class, String.class));
			functions.put("keyListFromHashMap", CollectionFunctions.class.getDeclaredMethod("getKeyListFromMap", 
                    new Class[] { HashMap.class}));

            functions.put("addDays", DateUtils.class.getDeclaredMethod("addDays", Date.class, int.class));
            functions.put("getMinutes", DateUtils.class.getDeclaredMethod("getNumberofMinutes", String.class,String.class, String.class));
            functions.put("getSubSet", CollectionFunctions.class.getDeclaredMethod("getSubSet", List.class, String.class));
            
            functions.put("getDuration2", eMeasureFunctions.class.getDeclaredMethod("getDuration2",
                    new Class[]{String.class, String.class, String.class}));
            
            functions.put("compareListValues", CollectionExpressionUtils.class.getDeclaredMethod("compareListValues",
                    new Class[]{List.class, String.class, String.class, String.class}));
            
            functions.put("getDateFormat", DateUtils.class.getDeclaredMethod("getDateFormat", 
                                                                new Class[] {String.class,String.class}));
            functions.put("getDateBasedOnMatchingFormat", DateUtils.class.getDeclaredMethod("getDateBasedOnMatchingFormat", 
                                                                new Class[] {String.class,String[].class}));
//            functions.put("hoursForDates", DateUtils.class.getDeclaredMethod(
//                    "getNumberofHours", String.class, String.class, String.class, String.class));
            functions.put("cumulativeMedicationDurationList", eMeasureFunctions.class.getDeclaredMethod("cumulativeMedicationDurationList",
                    new Class[]{List.class}));
            
            functions.put("addMonths", DateUtils.class.getDeclaredMethod("addMonths",
                    new Class[]{String.class,Integer.TYPE,Integer.TYPE}));
            functions.put("getMostRecentElement", CollectionFunctions.class.getDeclaredMethod("getMostRecentElement",
                    List.class, String.class, String.class));
            functions.put("mergeList", CollectionFunctions.class.getDeclaredMethod("mergeList",List.class, List.class));
            functions.put("sum", CollectionFunctions.class.getDeclaredMethod("sum",List.class));
            functions.put("addDays", DateUtils.class.getDeclaredMethod("addDays",new Class[]{String.class,Integer.TYPE}));
            functions.put("getReadmitVisits", DSRIPUtils.class.getDeclaredMethod("getRedmitVisits",new Class[]{Long.class}));
            functions.put("visitsWithDiagnosis", DSRIPUtils.class.getDeclaredMethod("getVisitsWIthDiagnosis",new Class[]{List.class,List.class}));
            functions.put("addSeconds", DateUtils.class.getDeclaredMethod("addSeconds",new Class[]{String.class,Integer.TYPE}));
			functions.put("changeFormat", DateUtils.class.getDeclaredMethod("changeFormat",new Class[]{String.class,String.class,String.class}));
                        
            // border fix
            functions.put("addMonthsTillEndofDay", DateUtils.class.getDeclaredMethod("addMonthsTillEndofDay",
                    new Class[]{String.class,Integer.TYPE,Integer.TYPE}));
            functions.put("addDaysTillEndofDay", DateUtils.class.getDeclaredMethod("addDaysTillEndofDay",
                    new Class[]{String.class,Integer.TYPE}));
        } catch (Exception ex) {
            FocusConfig.getCurrentLogger().writeError("Failed to initialize context functions", ex);
        }
    }

    public static void register(String name, Method methodName) {
        functions.put(name, methodName);
    }

    public static Map<String, Method> getFunctions() {
        return functions;
    }
}
