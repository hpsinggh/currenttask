/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import java.util.List;
import org.apache.commons.math3.util.Precision;
/**
 *
 * @author sathyaji.raja
 */
/**
 * Changes made: added overloaded round method with input parameter scale
 * @author ramya.khasnis
 * Date : 10/04/2013
 */
public class MathUtils {
    
    public static double getDivisionResult(long numerator, long denominator)    {
        if (denominator != 0) {
            return (double)numerator/(double)denominator;
        } else {
            return 0.0;
        }
    }
    
    public static double round(double value) {
        //return Precision.round(value,0);
        return round(value, 0);
    }
    
    /**
     * round method rounds the input double "value" to "scale" decimal points.
     * @param value - input double value
     * @param scale - input scale, number of decimal point
     * @return  - rounded double value
     */
    public static double round(double value, int scale) {
        return Precision.round(value, scale);
    }
    
    public static int sum(List<Integer> valueList) {
        int sum =0; 
        
        for(Integer value : valueList){
            sum += value;
        }
        
        return sum;
    }
}
