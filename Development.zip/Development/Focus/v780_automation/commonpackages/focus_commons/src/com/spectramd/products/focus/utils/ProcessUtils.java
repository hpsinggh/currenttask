/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import com.spectramd.products.focus.common.FocusConfig;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.UUID;
import org.apache.commons.io.IOUtils;

/**
 *
 * @author sathyaji.raja
 */
public class ProcessUtils {
    
    public static int cmdExecute(String commandName, String workingDirectory, 
                                String[] args)  throws IOException, InterruptedException {

        //1. create the command statement
        String[] commandArray = new String[args.length + 3];
        commandArray[0] = "cmd";
        commandArray[1] = "/c";
        commandArray[2] = commandName;

        
        System.arraycopy(args, 0, commandArray, 3, args.length);
        
        //String command[] = {"java","-jar",args[0],"-client",args[2],args[3],args[4],args[5],args[6],args[7]};

        //2. Create process working directory
        return ProcessUtils.execute(commandName, workingDirectory, commandArray);
     }
    
    /**
     * This method will execute the jar file
     *
     * @param String[] args
     */
    public static int execute(String jarName, String workingDirectory, 
                                String[] args)  throws IOException, InterruptedException {
        
        int returnValue = -1;
        Process process = null;
        InputStream stdOutputStream = null;
        BufferedReader reader = null;
        FileOutputStream fileOutputStream = null;
        BufferedWriter writer = null;
        
        try {
            //2. Create process working directory
            File processWorkingDirectory = new File(workingDirectory);

            //3. Execute the process
            //Process process = Runtime.getRuntime().exec(args, null, processWorkingDirectory);
            ProcessBuilder processBuilder = new ProcessBuilder(args);
            processBuilder.directory(processWorkingDirectory);
            processBuilder.redirectErrorStream(true);
            process = processBuilder.start();

            //StreamGobbler outputStream = new StreamGobbler(process.getInputStream(), "output");
            //StreamGobbler errorStream = new StreamGobbler(process.getErrorStream(), "error");

            stdOutputStream = process.getInputStream();
            reader = new BufferedReader(new InputStreamReader(stdOutputStream));
            String outputFileName =  UUID.randomUUID().toString();
            fileOutputStream = new FileOutputStream(outputFileName);
            writer = new BufferedWriter(new OutputStreamWriter(fileOutputStream));

            long count=0;
            String str = null;
            //StringBuilder sb = new StringBuilder(8192);
            while ((str = reader.readLine()) != null) {
                writer.write(str);
                count++;
                
                if (count%50 == 0) 
                    writer.flush();
            }
            //outputStream.start();
            returnValue = process.waitFor();
        } catch (IOException ioe) {
            ioe.printStackTrace();
           
        
        //to print error messages
        //printToConsole(process.getErrorStream());

        //4. Use this value to set whether job is successfully executed or not
        // value = 0 indicates successfull, other than 0 not successfull

//        errorStream.start();
//        outputStream.start();
        // Handle stdout...
    
        
        
        
//        errorStream.interrupt();
//        outputStream.interrupt();
        } finally {
             if(writer != null){
                writer.close();
            }            
            if(fileOutputStream != null){
                fileOutputStream.flush();
                fileOutputStream.close();
            }
            if(reader != null){
                reader.close();
            }
            if(stdOutputStream != null){
                stdOutputStream.close();
            }
            
            if( process != null ) {
//                close(process.getErrorStream());
//                close(process.getOutputStream());
//                close(process.getInputStream());
                process.destroy();
      
            }
        }
        
        return returnValue;
     }
    
    private static void close(InputStream anInput) {
    try {
        if (anInput != null) {
            anInput.close();
        }
    } catch (IOException anExc) {
        anExc.printStackTrace();
    }
}

private static void close(OutputStream anOutput) {
    try {
        if (anOutput != null) {
            anOutput.close();
        }
    } catch (IOException anExc) {
        anExc.printStackTrace();
    }
}
    
    
    /**
     * Print error/input streams
     * @param proc
     * @param inputStream
     * @throws IOException 
     */
    private static void printToConsole(InputStream inputStream) throws IOException {
      
        
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        String line=null;
        
        while((line=reader.readLine()) != null) {
           // do nothing as SOP will be costly
          System.out.println(" "+line);
        }
        
        reader.close();
    }
    
}
