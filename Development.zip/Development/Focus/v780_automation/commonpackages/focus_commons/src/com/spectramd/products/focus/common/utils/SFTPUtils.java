/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusLogger;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URLEncoder;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Vector;
import org.apache.commons.vfs2.FileObject;
import org.apache.commons.vfs2.FileSystemOptions;
import org.apache.commons.vfs2.Selectors;
import org.apache.commons.vfs2.impl.StandardFileSystemManager;
import org.apache.commons.vfs2.provider.sftp.SftpFileSystemConfigBuilder;

/**
 *
 * @author smujtab
 */
public class SFTPUtils {

	private static String PATHSEPARATOR = "/";

	public static void uploadFile(FTPInfo ftpInfo, String fileName, String filePath) throws Exception {

		StandardFileSystemManager manager = new StandardFileSystemManager();
		try {
			FocusConfig.getCurrentLogger().writeInfo("Starting to transfer file -" + fileName);
			String serverAddress = ftpInfo.getHost();
			String userId = ftpInfo.getUsername();
			String password = URLEncoder.encode(ftpInfo.getPassword(), "UTF-8");
			String remoteDirectory = ftpInfo.getServerPath();

			//check if the file exists
			String filepath = filePath + '\\' + fileName;
			File file = new File(filepath);
			if (!file.exists()) {
				throw new RuntimeException("Error. Local file not found");
			}

			//Initializes the file manager
			manager.init();

			//Setup our SFTP configuration
			FileSystemOptions opts = new FileSystemOptions();
			SftpFileSystemConfigBuilder.getInstance().setStrictHostKeyChecking(
					opts, "no");
			SftpFileSystemConfigBuilder.getInstance().setUserDirIsRoot(opts, true);
			SftpFileSystemConfigBuilder.getInstance().setTimeout(opts, 10000);

			//Create the SFTP URI using the host name, userid, password,  remote path and file name
			String sftpUri = "sftp://" + userId + ":" + password + "@" + serverAddress + "/"
					+ remoteDirectory + fileName;

			System.out.println("Transferring file " + file.getName());
			// Create local file object
			//FileObject localFile = manager.resolveFile(file.getAbsolutePath());
			FileObject localFile = manager.resolveFile(file.getParentFile(), file.getName());

			// Create remote file object
			FileObject remoteFile = manager.resolveFile(sftpUri, opts);

			if (!(remoteFile.exists())) {     //check whether same file name exist on Remote.
				// Copy local file to sftp server
				remoteFile.copyFrom(localFile, Selectors.SELECT_SELF);
				FocusLogger.info("File upload successful");
			} else {
				FocusLogger.info("Duplicate File Name");
			}
		} catch (Exception ex) {
			FocusLogger.error("Exception in SFTPUtils :" + ex, ex);
			//return false;
		} finally {
			manager.close();
		}
	}

	public static long recursiveDownload(FTPInfo ftpInfo, String sourcePath,
			String destinationPath) throws Exception {

		long fileCount = 0;
		FocusConfig.getCurrentLogger().writeDebug("Start::::Recursive Download Method");
		ChannelSftp channelSftp = null;
		Session session = null;
		Channel channel = null;
		try {
			JSch jsch = new JSch();

			session = jsch.getSession(ftpInfo.getUsername(), ftpInfo.getHost(), ftpInfo.getPort());
			session.setPassword(ftpInfo.getPassword());
			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			session.setConfig(config);
			session.connect(); // Create SFTP Session
			FocusConfig.getCurrentLogger().writeDebug("Connection established !!!!!!!");
			channel = session.openChannel("sftp"); // Open SFTP Channel
			channel.connect();
			channelSftp = (ChannelSftp) channel;
			channelSftp.cd(sourcePath);
			FocusConfig.getCurrentLogger().writeDebug("Calling download method !!!!!!!");

			fileCount = recursiveFolderDownload(channelSftp, ftpInfo, sourcePath,
					destinationPath);
			if (fileCount > 0) {
				recursiveFolderDelete(channelSftp, sourcePath);
			}
		} finally {
			if (channelSftp != null) {
				channelSftp.disconnect();
			}
			if (channel != null) {
				channel.disconnect();
			}
			if (session != null) {
				session.disconnect();
			}
		}
		FocusConfig.getCurrentLogger().writeDebug("File download successful");
		return fileCount;
	}

	private static long recursiveFolderDownload(ChannelSftp channelSftp, FTPInfo ftpInfo, String sourcePath,
			String destinationPath) throws Exception {
		long fileCount = 0;
		Vector<ChannelSftp.LsEntry> fileAndFolderList = channelSftp.ls(sourcePath); // Let list of folder content

		//Iterate through list of folder content
		for (ChannelSftp.LsEntry item : fileAndFolderList) {
			if (!item.getAttrs().isDir()) { // Check if it is a file (not a directory).
				if (!(new File(destinationPath + PATHSEPARATOR + item.getFilename())).exists()
						|| (item.getAttrs().getMTime()
						> Long.valueOf(new File(destinationPath + PATHSEPARATOR + item.getFilename()).lastModified()
								/ (long) 1000)
						.intValue())) { // Download only if lastModificationtime has changed.

					new File(destinationPath + PATHSEPARATOR + item.getFilename());
					channelSftp.get(sourcePath + PATHSEPARATOR + item.getFilename(),
							destinationPath + PATHSEPARATOR + item.getFilename()); // Download file from source (source filename, destination filename).
					fileCount++;
				}
			} else if (!(".".equals(item.getFilename()) || "..".equals(item.getFilename()))) {
				FocusConfig.getCurrentLogger().writeDebug("Copy started !!!!!!!");
				new File(destinationPath + PATHSEPARATOR + item.getFilename()).mkdirs(); // Empty folder copy.
				recursiveFolderDownload(channelSftp, ftpInfo, sourcePath + PATHSEPARATOR + item.getFilename(),
						destinationPath + PATHSEPARATOR + item.getFilename()); // Enter found folder on server to read its contents and create locally.
			}
		}

		return fileCount;
	}

	private static void recursiveFolderDelete(ChannelSftp channelSftp, String path) throws Exception {

		FocusConfig.getCurrentLogger().writeDebug("Start:::Recursive Folder Delete");
		//System.out.println("Start ::: Inside recursiveFolderDelete method");
		channelSftp.cd(path); // Change Directory on SFTP Server
		// List source directory structure.
		Vector<ChannelSftp.LsEntry> fileAndFolderList = channelSftp.ls(path);

		// Iterate objects in the list to get file/folder names.
		if (!(fileAndFolderList.isEmpty())) {
			for (ChannelSftp.LsEntry item : fileAndFolderList) {

				// If it is a file (not a directory).
				if (!item.getAttrs().isDir()) {

					channelSftp.rm(path + "/" + item.getFilename()); // Remove file.

				} else if (!(".".equals(item.getFilename()) || "..".equals(item.getFilename()))) { // If it is a subdir.

					try {

						// removing sub directory.
						FocusConfig.getCurrentLogger().writeDebug("Recursive Folder Delete:::Removing Subdirectories");
						channelSftp.rmdir(path + "/" + item.getFilename());

					} catch (Exception e) { // If subdir is not empty and error occurs.

						// Do lsFolderRemove on this subdir to enter it and clear its contents.
						recursiveFolderDelete(channelSftp, path + "/" + item.getFilename());
					}
				}
			}
		} else {
			FocusConfig.getCurrentLogger().writeDebug("No Source Files to delete");
		}
		//channelSftp.rmdir(path); // delete the parent directory after empty
		FocusConfig.getCurrentLogger().writeDebug("End:::Recursive Folder Delete");
	}

	/**
	 * Uploads the provided files or folders to the SFTP location.
	 * @param ftpInfo FTPInfo
	 * @param sourcePath String
	 * @param destinationPath String
	 * @throws Exception on error
	 */
	public static void recursiveUpload(final FTPInfo ftpInfo, final String sourcePath, final String destinationPath) throws Exception {
		FocusConfig.getCurrentLogger().writeDebug("Start::::Recursive Upload Method");

		ChannelSftp channelSftp = null;
		Session session = null;
		Channel channel = null;
		try {
			JSch jsch = new JSch();
			session = jsch.getSession(ftpInfo.getUsername(), ftpInfo.getHost(), ftpInfo.getPort());
			session.setPassword(ftpInfo.getPassword());

			java.util.Properties config = new java.util.Properties();
			config.put("StrictHostKeyChecking", "no");
			config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");
			session.setConfig(config);
			session.connect();
			FocusConfig.getCurrentLogger().writeDebug("Connection established !!!!!!!");

			channel = session.openChannel("sftp"); // Open SFTP Channel
			channel.connect();
			channelSftp = (ChannelSftp) channel;
			channelSftp.cd(ftpInfo.getServerPath());
			FocusConfig.getCurrentLogger().writeDebug("Calling upload method !!!!!!!");

			recursiveFolderUpload(channelSftp, sourcePath, destinationPath);
			FocusConfig.getCurrentLogger().writeDebug("File(s) upload successful");
		} finally {
			if (channelSftp != null) {
				channelSftp.disconnect();
			}
			if (channel != null) {
				channel.disconnect();
			}
			if (session != null) {
				session.disconnect();
			}
		}
		FocusConfig.getCurrentLogger().writeDebug("End::::Recursive Upload Method");
	}

	/**
	 * Uploads the provided files or folders to the SFTP location.
	 * @param channelSftp ChannelSftp
	 * @param sourcePath String
	 * @param destinationPath String
	 * @throws SftpException on error
	 * @throws FileNotFoundException on error
	 * @throws IOException on error
	 */
	private static void recursiveFolderUpload(final ChannelSftp channelSftp, final String sourcePath, final String destinationPath)
			throws SftpException, FileNotFoundException, IOException {
		FocusConfig.getCurrentLogger().writeDebug("Start::::Recursive Folder Upload Method");

		File sourceFile = new File(sourcePath);
		if (sourceFile.isDirectory()) {
			FocusConfig.getCurrentLogger().writeDebug("Encountered Directory " + sourcePath);
			for (File file : sourceFile.listFiles()) {
				Path source = Paths.get(sourcePath);
				Path dest = source.relativize(Paths.get(file.getPath()));

				FocusConfig.getCurrentLogger().writeDebug("Recursively calling Folder Upload Method for " + dest);
				recursiveFolderUpload(channelSftp, file.getAbsolutePath(), destinationPath + PATHSEPARATOR + dest.toString());
			}
		} else {
			String dest = destinationPath + (!destinationPath.endsWith(sourceFile.getName()) ? PATHSEPARATOR + sourceFile.getName() : "");
			FocusConfig.getCurrentLogger().writeDebug("Attempting upload for " + dest);

			String dir = dest.replace(PATHSEPARATOR + sourceFile.getName(), "");
			if (dir.length() > 0) {
				try {
					FocusConfig.getCurrentLogger().writeDebug("Attempting to create new directory " + dir);
					channelSftp.mkdir(dir);
				} catch (SftpException e) {
					FocusConfig.getCurrentLogger().writeDebug("Directory " + dir + " already exists");
				}
			}

			FileInputStream fis = null;
			try {
				fis = fis = new FileInputStream(sourceFile);
				channelSftp.put(fis, dest, ChannelSftp.OVERWRITE);
			} finally {
				if (fis != null) {
					fis.close();
				}
			}
			FocusConfig.getCurrentLogger().writeDebug("Uploaded " + dest + " successfully");
		}
		FocusConfig.getCurrentLogger().writeDebug("End::::Recursive Folder Upload Method");
	}

	/*	public static void main(String[] args) throws Exception {
		String source = "C:\\Development\\FOCUS\\v740_int\\Interfaces\\FocusInterface\\nbproject\\ant-deploy.xml";
		String dest = "";

		FTPInfo sftp = new FTPInfo();
		sftp.setHost("focusanalytics.spectramd.com");
		sftp.setPort(22);
		sftp.setUsername("sftp.test");
		sftp.setPassword("SMDtech@123456789!");
		sftp.setTimeOut(3000);
		sftp.setServerPath("/");

		recursiveUpload(sftp, source, dest);
	}*/
}
