/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.portal.common.data;

/**
 *
 * @author sathyaji.raja
 */
public abstract class WidgetStyle {
 
    private long id = -1;
    
    public long getId() {
        return id;
    }
    
    public void setId(long styleId) {
        id = styleId;
    }
}
