/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.dimensions;

/**
 *
 * @author siraj.M
 */
public final class FocusDimensionConstants {

	/**
	 * Private Constructor.
	 */
	private FocusDimensionConstants() {
	}
	/**
	 * View Type Query.
	 */
	public static final String VIEW = "VIEW";
	/**
	 * SQL Type View.
	 */
	public static final String SQL_VIEW = "SQLVIEW";
	/**
	 * Procedure Type View.
	 */
	public static final String SP_VIEW = "SPVIEW";
	/**
	 * Elastic Search View.
	 */
	public static final String ES_VIEW = "ESVIEW";
	/**
	 * Elastic Search Aggregates View.
	 */
	public static final String ES_AGGS_VIEW = "ESAGGSVIEW";
	/**
	 * Elastic Search Documents View.
	 */
	public static final String ES_DOCS_VIEW = "ESDOCSVIEW";
        
}
