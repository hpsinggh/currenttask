/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import java.util.HashMap;

/**
 *
 * @author sathyaji.raja
 */
public class FocusConfiguration {
    
    private static FocusConfiguration configInstance = new FocusConfiguration();
    
    private HashMap<String, ConfigInfo> configMap = new HashMap<String, ConfigInfo>();
    
    private FocusConfiguration() {
        
    }
    
    public static FocusConfiguration getConfiguration()  {
        return configInstance;
    }
    
    public ConfigInfo getConfigInfo(String argConfigKey)    {
        return configMap.get(argConfigKey);
    }
    
    public void setConfigInfo(String argConfigKey, ConfigInfo argConfigInfo)    {
        configMap.put(argConfigKey, argConfigInfo);
    }
}
