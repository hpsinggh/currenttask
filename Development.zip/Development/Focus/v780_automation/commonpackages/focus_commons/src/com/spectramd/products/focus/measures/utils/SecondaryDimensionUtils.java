/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.utils;

import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusException;
import com.spectramd.products.focus.measures.common.DimensionValue;
import java.util.Collection;
import java.util.HashMap;

/**
 *
 * @author pratapkonakala
 */
public class SecondaryDimensionUtils {

    /**
     * This method is used to get secondary dimension key
     * @param secondaryDimValue - Secondary Dimension Value ( for example incase LOS , this value will be either 3N or 4S...)
     * @param secondaryDimensionDetailsList - List of Secondary Dimension Details
     * @return secondaryDimensionKey
     * @throws FocusException 
     */
    public static Long getSecondaryDimensionKey(Object secondaryDimValue, HashMap secondaryDimensionDetailsMap) throws FocusException {
        Long secondaryDimensionKey = -1L;
        try {
            //1. Iterate the secondary dimension details
            for (DimensionValue dimensionValue : (Collection<DimensionValue>) secondaryDimensionDetailsMap.values()) {
                //2. Check whether dimension category is RANGE
                if (dimensionValue.getCategory().equalsIgnoreCase("RANGE")) {
                    //3. Get Min and Max values
                    int minValue = dimensionValue.getMinValue();
                    int maxValue = dimensionValue.getMaxValue();
                    //4. Check whether secondary dimension value is in Range
                    int dimValue = new Integer(secondaryDimValue.toString());
                    if (dimValue >= minValue && dimValue <= maxValue) {
                        secondaryDimensionKey = dimensionValue.getKey();
                        break;
                    }
                    //5. Otherwise check whether category is VALUE    
                } else if (dimensionValue.getCategory().equalsIgnoreCase("VALUE")) {
                    //6. Check whether category type is STRING
                    if (dimensionValue.getCategoryType().equalsIgnoreCase("STRING")) {
                        //7.Check whether the secondary dimension value matches
                        if (((String) secondaryDimValue).equalsIgnoreCase(dimensionValue.getValue())) {
                            secondaryDimensionKey = dimensionValue.getKey();
                            break;
                        }
                        //8. Check whether category type is INTEGER   
                    } else if (dimensionValue.getCategoryType().equalsIgnoreCase("INTEGER")) {
                        //9.Check whether the secondary dimension value matches
                        int value = Integer.parseInt(dimensionValue.getValue());
                        if ((secondaryDimValue).equals(value)) {
                            secondaryDimensionKey = dimensionValue.getKey();
                            break;
                        }
                    }
                } else if (dimensionValue.getCategory().equalsIgnoreCase("GREATER")) {
                    int dimValue = new Integer(secondaryDimValue.toString());
                    if (dimensionValue.getCategoryType().equalsIgnoreCase("INTEGER")) {
                        int value = Integer.parseInt(dimensionValue.getValue());
                        if (dimValue >= value) {
                            secondaryDimensionKey = dimensionValue.getKey();
                            break;
                        }
                    }
                }

            }

        } catch (Exception ex) {
            FocusConfig.getCurrentLogger().writeError("Error while getting getSecondaryDimensionKey", ex);
            throw new FocusException("Error while getting getSecondaryDimensionKey", ex);
        }
        //10. Return secondary dimension key
        return secondaryDimensionKey;
    }
}