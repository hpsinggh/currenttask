/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

/**
 *
 * @author sathyaji.raja
 */
public class SqlView extends AbstractView {
    
   private String query;
   
   
   public SqlView() {
       super("SQLVIEW");
       
   }
   
   public SqlView(String query) {
       super("SQLVIEW");
       this.query = query;
       
   }
   
   
   public String getQuery() {
       return query;
   }
   
   public void setQuery(String query) {
       this.query = query;
   }
    
}
