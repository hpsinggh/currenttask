/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.common.FocusConfig;
import java.util.ArrayList;

/**
 *
 * @author sathyaji.raja
 */
public class QueryBuilderUtils {
    
    
    public static String formatQuery(String query, String[] inputValues) {
    
        String outputQuery = "";
        if (inputValues != null && inputValues.length > 0)   {
            String tempQuery = query;
            FocusConfig.getCurrentLogger().writeDebug("count of inputvalues = " + inputValues.length);
            for (int index = 0; index < inputValues.length; index++)    {
                
                int formatIndex = tempQuery.indexOf("%s");
                String queryToFormat = tempQuery.substring(0, formatIndex+2);
                
                StringBuilder updatedQuery = new StringBuilder(1024);
                updatedQuery.append(String.format(queryToFormat, inputValues[index]));
                updatedQuery.append(tempQuery.substring(formatIndex+2));
                
                tempQuery = updatedQuery.toString();
                
                FocusConfig.getCurrentLogger().writeDebug("query during formatting "+ index +" = "+ tempQuery);
            }
            
            outputQuery = tempQuery;
            FocusConfig.getCurrentLogger().writeDebug("output query from query builder =" + outputQuery);
        } else {
            outputQuery = query;
        }
            
        
        return outputQuery;
    }
    
    
    public static String formatComplexQuery(String query, ArrayList inputValues) {
       
        String outputQuery = "";
        if (inputValues != null && inputValues.size() > 0)   {
            
            String tempQuery = query;
            FocusConfig.getCurrentLogger().writeDebug("input value length =" + inputValues.size());
            for (int index=0; index < inputValues.size(); index++)    {
                
                int formatIndex = tempQuery.indexOf("%s");
                String queryToFormat = tempQuery.substring(0, formatIndex+2);
                
                Object mapValue = inputValues.get(index);
                String inputValue = "";
                if (mapValue instanceof ArrayList)  {
                    
                    ArrayList listValue = (ArrayList)mapValue;
                    StringBuilder sbTemp = new StringBuilder(1024);
                     
                    if (listValue.size() > 0)   {
                        sbTemp.append("(");
                        
                        for ( int listIndex=0; listIndex < listValue.size(); listIndex++)    {
                            if (listIndex != 0)
                                sbTemp.append(",");
                            sbTemp.append(listValue.get(listIndex));
                        }
                        sbTemp.append(")");
                    }
                    inputValue = sbTemp.toString();
                    
                } else {
                   inputValue = mapValue.toString();
                }
                
                FocusConfig.getCurrentLogger().writeDebug("values string in query =" + inputValue);
                
                 StringBuilder updatedQuery = new StringBuilder(1024);
                 updatedQuery.append(String.format(queryToFormat, inputValue));
                 updatedQuery.append(tempQuery.substring(formatIndex+2));
                 
                 tempQuery = updatedQuery.toString();
                
                 FocusConfig.getCurrentLogger().writeDebug("query during formatting = "+ index + " = "+tempQuery);
            }
            outputQuery = tempQuery;
            FocusConfig.getCurrentLogger().writeDebug("output query from query builder =" + outputQuery);
        } else {
            outputQuery = query;
        }
        
        return outputQuery;
    }
    
    public static String formatComplexQuery(String query, String inputType, ArrayList inputValues) {
       
        String outputQuery = "";
        if (inputValues != null && inputValues.size() > 0)   {
            
            String tempQuery = query;
            FocusConfig.getCurrentLogger().writeDebug("input value length =" + inputValues.size());
            for (int index=0; index < inputValues.size(); index++)    {
                
                int formatIndex = tempQuery.indexOf("%s");
                String queryToFormat = tempQuery.substring(0, formatIndex+2);
                
                Object mapValue = inputValues.get(index);
                String inputValue = "";
                if (mapValue instanceof ArrayList)  {
                    
                    ArrayList listValue = (ArrayList)mapValue;
                    StringBuilder sbTemp = new StringBuilder(1024);
                     
                    if (listValue.size() > 0)   {
                        sbTemp.append("(");
                        
                        for ( int listIndex=0; listIndex < listValue.size(); listIndex++)    {
                            if (listIndex != 0)
                                sbTemp.append(",");
                            if (inputType.equalsIgnoreCase("STRING")) {
                                sbTemp.append("'");
                            } else if (inputType.equalsIgnoreCase("STRING_PROCEDURE")) {
                                sbTemp.append("''");
                            }
                            sbTemp.append(listValue.get(listIndex));
                            if (inputType.equalsIgnoreCase("STRING")) {
                                sbTemp.append("'");
                            } else if (inputType.equalsIgnoreCase("STRING_PROCEDURE")) {
                                sbTemp.append("''");
                            }
                        }
                        sbTemp.append(")");
                    }
                    inputValue = sbTemp.toString();
                    
                } else {
                   inputValue = mapValue.toString();
                }
                
                FocusConfig.getCurrentLogger().writeDebug("values string in query =" + inputValue);
                
                 StringBuilder updatedQuery = new StringBuilder(1024);
                 updatedQuery.append(String.format(queryToFormat, inputValue));
                 updatedQuery.append(tempQuery.substring(formatIndex+2));
                 
                 tempQuery = updatedQuery.toString();
                
                 FocusConfig.getCurrentLogger().writeDebug("query during formatting = "+ index + " = "+tempQuery);
            }
            outputQuery = tempQuery;
            FocusConfig.getCurrentLogger().writeDebug("output query from query builder =" + outputQuery);
        } else {
            outputQuery = query;
        }
        
        return outputQuery;
    }
    
}
