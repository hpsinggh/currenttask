/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.utils;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import java.io.FileWriter;
import java.util.List;
import java.util.Map;

/**
 *
 * @author sathyaji.raja1
 */
public final class CSVDataExporter  {
    
    //Delimiter used in CSV file
    private static final String COMMA_DELIMITER = ",";
    private static final String NEW_LINE_SEPARATOR = System.getProperty("line.separator");;

    private CSVDataExporter() {
    }
    
    /**
         * This method is used to generate CSV file
     *
         * @param gridRowMap
         * @param outputFileName
         * @throws Exception 
         */
    public static void CreateFile(List<OrderedInsensitiveMap> gridRowMap,
                                       String outputFileName) throws Exception {
        FileWriter writer = null;
        StringBuffer stringwriter = new StringBuffer();
        try {
            writer = new FileWriter(outputFileName, false);
            //generate the headers for csv
            generateCSVHeader(stringwriter, gridRowMap.get(0));
            
            //iterate the map and add the values to csv file
            for (Map<String, Object> rowObj : gridRowMap) {
                int counter = 1;
                for (Map.Entry<String, Object> mapEntry : rowObj.entrySet()) {
//                    stringwriter.append("\"").append(mapEntry.getValue()).append("\"");
//                    if (mapEntry.getValue() != null) {
                        stringwriter.append(((counter <= rowObj.size()) && counter != 1) ? COMMA_DELIMITER : "");
                        stringwriter.append((mapEntry.getValue() != null) ? mapEntry.getValue() : "");
//                    }
                    counter++;
                }
                stringwriter.append(NEW_LINE_SEPARATOR);
                
            }
            writer.write(stringwriter.toString());
        } finally {
            if (writer != null) {
                writer.close();
            }
        }

    }
    
    // Generating the headers for csv file
    private static void generateCSVHeader(StringBuffer writer,
            Map<String, String> gridRowMap) throws Exception {
        int counter = 1;
        for (String key : gridRowMap.keySet()) {
            writer.append(key);
            writer.append((counter < gridRowMap.size()) ? COMMA_DELIMITER : "");
            counter++;
        }
        writer.append(NEW_LINE_SEPARATOR);
    }
}
