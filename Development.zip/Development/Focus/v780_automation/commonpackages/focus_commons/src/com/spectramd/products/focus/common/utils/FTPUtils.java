/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import com.spectramd.products.focus.common.FocusConfig;
import java.io.File;
import java.util.Properties;
import org.ftp4che.FTPConnection;
import org.ftp4che.FTPConnectionFactory;
import org.ftp4che.util.ftpfile.FTPFile;

/**
 *
 * @author smujtab
 */
public class FTPUtils {
    
    public static void uploadFile(FTPInfo ftpInfo, String fileName, String encryptFilePath) throws Exception {
        
        FTPConnection connection = null;
        try {
            FocusConfig.getCurrentLogger().writeInfo("Starting to transfer file -" + fileName);
            Properties ftpProperties = FTPUtils.getProperties(ftpInfo);
            FTPFile fromFile = new FTPFile(new File(encryptFilePath));
            FTPFile toFile = new FTPFile(ftpInfo.getServerPath(), fileName);

            //connection = FTPConnectionFactory.getInstance(ftpProperties);
            
            //FTPPool pool = FTPPool.getInstance();
            //connection = pool.getConnection(ftpInfo);
            connection = getConnection(ftpProperties, 5, 500);
            if (connection != null) {
                connection.uploadFile(fromFile, toFile);
                 FocusConfig.getCurrentLogger().writeInfo("Completed transferring file -" + fileName);
            } else {
                 FocusConfig.getCurrentLogger().writeInfo("Failed to transferg file -" + fileName);
            }
            //connection.disconnect();
        } finally {
            if (connection != null) {
                //FTPPool.getInstance().release();
                connection.disconnect();
            }
            //connection = null;
           
        }
        
    }
    
    public static FTPConnection getConnection(Properties ftpProperties, int retryCount, 
                                                            int sleepDuration) throws Exception {
        
        FTPConnection connection = null;
        
        for (int index = 0; index < retryCount; index++) {
            Thread.sleep(sleepDuration);
            try{
                connection = FTPConnectionFactory.getInstance(ftpProperties);
                connection.connect();
                connection.noOperation();
                break;
            } catch (Exception ex) {
                // do nothing..
            }
        }
        
        return connection;
    }
    
     public static void uploadFiles(FTPInfo ftpInfo, String[] fileNames, String[] encryptFilePaths) throws Exception {
        
        FTPConnection connection = null;
        try {
            
            Properties ftpProperties = FTPUtils.getProperties(ftpInfo);
            connection = FTPConnectionFactory.getInstance(ftpProperties);
            connection.connect();
            connection.noOperation();
            
            for (int index=0; index < fileNames.length; index++) {
                String fileName = fileNames[index];
                FocusConfig.getCurrentLogger().writeInfo("Starting to transfer file -" + fileName);
                FTPFile fromFile = new FTPFile(new File(encryptFilePaths[index]));
                FTPFile toFile = new FTPFile(ftpInfo.getServerPath(), fileName);

                connection.uploadFile(fromFile, toFile);
                FocusConfig.getCurrentLogger().writeInfo("Completed transferring file -" + fileName);
            }
            connection.disconnect();
        } finally {
//            if (connection != null) {
//                connection.disconnect();
//            }
            //connection = null;
            
        }
        
    }
    
    public static Properties getProperties(FTPInfo ftpInfo) {
        Properties ftpProperties = new Properties();
        ftpProperties.setProperty("connection.host", ftpInfo.getHost());
        ftpProperties.setProperty("connection.port", "" + ftpInfo.getPort());
        ftpProperties.setProperty("user.login", ftpInfo.getUsername());
        ftpProperties.setProperty("user.password", ftpInfo.getPassword());
        ftpProperties.setProperty("connection.type", "AUTH_SSL_FTP_CONNECTION");
        ftpProperties.setProperty("connection.timeout", "10000");
        ftpProperties.setProperty("connection.passive", "true");
        return ftpProperties;
    }
}
