/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core.utils;

import com.spectramd.products.focus.measures.common.AbstractView;
import com.spectramd.products.focus.measures.common.DatabaseField;
import com.spectramd.products.focus.measures.common.SqlView;
import java.util.ArrayList;

/**
 *
 * @author sathyaji.raja
 */
public class SqlViewQueryBuilder implements QueryBuilderInterface {

    @Override
    public String getQuery(AbstractView argView, 
                                ArrayList<DatabaseField> defaultFieldValues, 
                                String[] inputValues) {
        
        SqlView sqlView = (SqlView)argView;
        return QueryBuilderUtils.formatQuery(sqlView.getQuery(), inputValues);
    }

    @Override
    public String getComplexQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    ArrayList inputValues) {
        SqlView sqlView = (SqlView)argView;
        return QueryBuilderUtils.formatComplexQuery(sqlView.getQuery(), inputValues);
    }
    
    @Override
     public String getComplexQuery(AbstractView argView, 
                                    ArrayList<DatabaseField> defaultFieldValues, 
                                    String inputType,ArrayList inputValues) {
        SqlView sqlView = (SqlView)argView;
        return QueryBuilderUtils.formatComplexQuery(sqlView.getQuery(), inputType, inputValues);
    }
    
}
