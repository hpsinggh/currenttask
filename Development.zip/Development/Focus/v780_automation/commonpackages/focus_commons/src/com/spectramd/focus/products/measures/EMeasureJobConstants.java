/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.focus.products.measures;

/**
 *
 * @author ramya.khasnis
 */
public interface EMeasureJobConstants {
    public static String PROGRAM_INCENTIVE_KEY = "__FOCUS_PROGRAM_INCENTIVE_CODE__";
    public static String PROGRAM_INCENTIVE_CODES = "__FOCUS_PROGRAM_INCENTIVE_CODES__";
    public static String MEASURE_CODE = "__FOCUS_MEASURE_CODE__";
    public static String MEASURE_DEF_ID = "__FOCUS_MEASURE_DEF_ID__";
    public static String JOBNAME = "__FOCUS_JOBNAME__";
    public static String PAYOR_PROGRAM_DETAIL = "__FOCUS_PAYOR_PROGRAM_DETAILS__";
    
    public static String VALUESETS = "__FOCUS_VALUESETS__";
    public static String POPULATION_CATEGORY = "CATEGORY";
    public static String DIM_POPULATION_TYPE_DETAILS = "__FOCUS_DIM_POPULATION_TYPE_DETAILS__";
  
}
