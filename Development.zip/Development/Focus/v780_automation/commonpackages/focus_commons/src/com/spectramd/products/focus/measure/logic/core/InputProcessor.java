/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measure.logic.core;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.FocusException;
import com.spectramd.products.focus.measures.common.jobdata.MeasureJobData;
import java.util.List;

/**
 *
 * @author sathyaji.raja
 */
/**
 * Changes made: added MeasureJobData parameter to start method
 * @author ramya.khasnis
 * Date : 01/14/2014
 */
public interface InputProcessor {
    
    //Object getInput();
    long getCurrentRecordCount() ;
    void start(MeasureJobData measureJobData) throws FocusException;
    boolean next()  throws FocusException;
    List<OrderedInsensitiveMap> getCurrentData()    throws FocusException;
    public void stop()  throws FocusException;
}
