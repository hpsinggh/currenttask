/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

/**
 *
 * @author sathyaji.raja
 */
public class DimensionDetails  {
    
    private long id;
    private String name;
    private String uiName;

    
    private AbstractView viewDetails;
    private String query;
    private String fields;
    private String value;
    public long getId() {
        return id;
    }
    
    public void setId(long dimId) {
        id = dimId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String dimName) {
        name = dimName;
    }
    
    public AbstractView getViewDetails() {
        return viewDetails;
    }
    
    public void setViewDetails(AbstractView inputViewDetails)    {
        viewDetails = inputViewDetails;
    }
    
    public String getQuery()    {
        return query;
    }
    
    public void setQuery(String dimQuery)   {
        query = dimQuery;
    }
    
    public String getFields()    {
        return fields;
    }
    
    public void setFields(String dimFields)   {
        fields = dimFields;
    }
    public String getUiName() {
        return uiName;
    }

    public void setUiName(String uiName) {
        this.uiName = uiName;
    }
    
     public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
