/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.dimensions;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 *
 * @author sumit.taneja
 */
public final class DimensionElasticSearchBean extends DimensionQueryBean {

    /**
     * Key / Value pairs similar to a SQL WHERE clause.
     */
    private Map<String, Object> conditions;
    /**
     * Optional Fields list for Elastic Search to return. If null, all fields
     * will be returned.
     */
    private Set<String> fields;
    /**
     * Fields for Elastic Search similar to SQL GROUP BY clause.
     */
    private List<String> aggConditions;
    /**
     * Fields for Elastic Search on which aggregations are to be fetched.
     */
    private List<String> aggColumns;
    /**
     * RST Fields for Elastic Search on which additional aggregates are to be
     * fetched, like performance calculations on aggregates.
     */
    private Map<String, Object> additionalAggregates;
    /**
     * Range Condtion Map for Elastic Search.
     */
    private String rangeCondition;

    /**
     * [NIRANJAN] additional conditions to be added to filter the resultset
     * further<br>
     * By default Dynamic Filters will be applied with "AND"/MUST and
     * ColumnFilters will be applied with "OR"/SHOULD conditions respectively
     */
    private List<Map<String, Object>> filterConditions;
    /**
     * To tell aggregation type Applicable values are
     * - sum, value_count, avg, cardinality, extended_stats, max and etc., 
     * -Refer : 
     *      https://www.elastic.co/guide/en/elasticsearch/reference/1.5/search-aggregations.html
     */
    private String aggType;

    /**
     * Key / Value pairs similar to a SQL WHERE clause.
     */
    private Map<String, Object> mustNotConditions;

    /**
     *
     * @return Map<String, Object>.
     */
    public Map<String, Object> getConditions() {
        return conditions;
    }

    /**
     *
     * @param map Map<String, Object>.
     */
    public void setConditions(final Map<String, Object> map) {
        this.conditions = map;
    }

    /**
     *
     * @return Set<String>.
     */
    public Set<String> getFields() {
        return fields;
    }

    /**
     *
     * @param flds Set<String>.
     */
    public void setFields(final Set<String> flds) {
        this.fields = flds;
    }

    /**
     *
     * @return List<String>.
     */
    public List<String> getAggConditions() {
        return aggConditions;
    }

    /**
     *
     * @param dims List<String>.
     */
    public void setAggConditions(final List<String> dims) {
        this.aggConditions = dims;
    }

    /**
     *
     * @return List<String>.
     */
    public List<String> getAggColumns() {
        return aggColumns;
    }

    /**
     *
     * @param cols List<String>.
     */
    public void setAggColumns(final List<String> cols) {
        this.aggColumns = cols;
    }

    /**
     * @return the additionalAggregates
     */
    public Map<String, Object> getAdditionalAggregates() {
        return additionalAggregates;
    }

    /**
     * @param addAgg to set.
     */
    public void setAdditionalAggregates(final Map<String, Object> addAgg) {
        this.additionalAggregates = addAgg;
    }

    /**
     * @return the rangeCondition
     */
    public String getRangeCondition() {
        return rangeCondition;
    }

    /**
     * @param rCondition the rCondition to set.
     */
    public void setRangeCondition(final String rCondition) {
        this.rangeCondition = rCondition;
    }

    public List<Map<String, Object>> getFilterConditions() {
        return filterConditions;
    }

    public void setFilterConditions(List<Map<String, Object>> filterConditions) {
        this.filterConditions = filterConditions;
    }

    /**
     *
     * @return aggType
     */
    public String getAggType() {
        return aggType;
    }
    /**
     * 
     * @param aggType to set aggregationType
     */
    public void setAggType(String aggType) {
        this.aggType = aggType;
    }
    /**
     * 
     * @return mustNotConditions
     */
    public Map<String, Object> getMustNotConditions() {
        return mustNotConditions;
    }
    /**
     * 
     * @param mustNotConditions to set mustNotConditions
     */
    public void setMustNotConditions(Map<String, Object> mustNotConditions) {
        this.mustNotConditions = mustNotConditions;
    }
    
    
}
