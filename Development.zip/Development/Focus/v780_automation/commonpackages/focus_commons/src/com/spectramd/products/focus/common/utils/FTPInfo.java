/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import java.util.StringTokenizer;

/**
 *
 * @author smujtab
 */
public class FTPInfo {

    private String host;
    private int port;
    private String username;
    private String password;
    private String serverPath;
    private int timeOut;

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getServerPath() {
        return serverPath;
    }

    public void setServerPath(String serverPath) {
        this.serverPath = serverPath;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
      public static FTPInfo getFTPDetails(String ftpUrl) {
        FTPInfo ftpInfo = new FTPInfo();
        StringTokenizer st = new StringTokenizer(ftpUrl, ",");

        //host,port,username,password,ftp_folder
        ftpInfo.setHost(st.nextToken());
        ftpInfo.setPort(Integer.parseInt(st.nextToken()));
        ftpInfo.setUsername(st.nextToken());
        ftpInfo.setPassword(st.nextToken());
        ftpInfo.setServerPath(st.nextToken());
        return ftpInfo;
    }

    /**
     * @return the timeOut
     */
    public int getTimeOut() {
        return timeOut;
    }

    /**
     * @param timeOut the timeOut to set
     */
    public void setTimeOut(int timeOut) {
        this.timeOut = timeOut;
    }
}
