/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

/**
 *
 * @author lravilla
 */
public class DOMXmlUtils {

    private static DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    private static XPath xPath = XPathFactory.newInstance().newXPath();
    private static DocumentBuilder db = null;

    public static XPath getXPath() {
        return xPath;
    }

    public static Document createDocument(String templateName){
        //creating document builder factory and document
        Document originalDocument = null;
        try{
        db = dbf.newDocumentBuilder();
        originalDocument =  db.parse(templateName);
        }catch(Exception ex){
            
        }
        return originalDocument;
    }

    /**
     * 
     * @param originalDcoument
     * @return copiedDocument
     */
    public static Document cloneDocument(Document originalDcoument) {
        
        Node originalRoot = originalDcoument.getDocumentElement();
        Document copiedDocument = db.newDocument();
        Node copiedRoot = copiedDocument.importNode(originalRoot, true);
        copiedDocument.appendChild(copiedRoot);

        return copiedDocument;
    }
}
