/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.portal.common.data;

/**
 *
 * @author sathyaji.raja
 */
public class WidgetParameters {
    
    private long id = -1;
    private long chartStyleId = -1;
    private int width;
    private int height;
    
    private String type;
    private String subType;
    private String style;
    
    private String widgetType; // duplicate to be removed
    
    //private WidgetDataSort dataSorter = new WidgetDataSort();
    //private List<WidgetOrderData> listOrder = new ArrayList<WidgetOrderData>();
    
    private String htmlHeader;
    
    public long getId() {
        return id;
    }
    
    public void setId(long id)  {
        this.id = id;
    }
    
    public long getChartStyleId() {
        return chartStyleId;
    }
    
    public void setChartStyleId(long id)  {
        this.chartStyleId = id;
    }
    
    public int getWidth()   {
        return width;
    }
    
    public void setWidth(int width)   {
        this.width = width;
    }
    
    public int getHeight()   {
        return height;
    }
    
    public void setHeight(int height)   {
        this.height = height;
    }
    
    public String getType() {
        return type;
    }
    
     public void setType(String type)    {
        this.type = type;
    }
     
     public String getSubType() {
        return subType;
    }
    
    public void setSubType(String subType)    {
        this.subType = subType;
    }
    
    public void setStyle(String style)    {
        this.style = style;
    }
     
     public String getStyle() {
        return style;
    }
     
    public String getWidgetType() {
        return widgetType;
    }
    
    public void setWidgetType(String widgetType) {
        this.widgetType = widgetType;
    }

    /**
     * @return the htmlHeader
     */
    public String getHtmlHeader() {
        return htmlHeader;
    }

    /**
     * @param htmlHeader the htmlHeader to set
     */
    public void setHtmlHeader(String htmlHeader) {
        this.htmlHeader = htmlHeader;
    }
}
