/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

/**
 *
 * @author sathyaji.raja
 */
public class FieldDetailsList extends ArrayList<FieldDetails> {

    public FieldDetailsList( int initialCapacity ){
        super( initialCapacity );
    }
    
    private long id;
    private String name;
    private long templateId = 0;
    private long referenceId = -1;
    private long parentId = -1;
    // For Ambulatory
    private String filterType;
    private String category;
//    private ArrayList<FieldDetailsList> subSequenceList = null;
 
    public FieldDetailsList() {
        
    }
    
    public FieldDetails getFieldDetails(String resultFieldName) {
        FieldDetails dtlResult = null;
        
        for (int index=0; index < this.size(); index++) {
            FieldDetails dtlTemp = this.get(index);
            if (dtlTemp.ResultFieldName.equalsIgnoreCase(resultFieldName)) {
                dtlResult = dtlTemp;
                break;
            }
        }
        
        return dtlResult;
    }
    
    public long getId() {
        return id;
    }
    
    public void setId(long measureId) {
        id = measureId;
    }
    
    public long getTemplateId() {
        return templateId;
    }
    
    public void setTemplateId(long argTemplateId) {
        templateId = argTemplateId;
    }
    
    public long getReferenceId() {
        return referenceId;
    }
    
    public void setReferenceId(long argRefId) {
        referenceId = argRefId;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String fieldDetailListName) {
        name = fieldDetailListName;
    }
    
    public FieldDetailsList getFieldDetailList(FieldQualifier[] qualifier) {
        FieldDetailsList listDetails = new FieldDetailsList();
        
        for (int index=0; index < this.size(); index++)  {
            FieldDetails temp = this.get(index);
            
            for (int qlfrIndex=0; qlfrIndex < qualifier.length; qlfrIndex++) {
                // check if the current field meets one of the input qualifiers, if so add to the result
                if (temp.Qualifier == qualifier[qlfrIndex]) {
                    listDetails.add(temp);
                    break;
                }
            }
           
        }
        
        return listDetails;
    }
    
    
    
//    public ArrayList<FieldDetailsList> getSubSequenceList() {
//        return subSequenceList;
//    }
//    
//    public void setSubSequenceList(ArrayList<FieldDetailsList> argSubSequenceList)  {
//        subSequenceList = argSubSequenceList;
//    }

    public String getFilterType() {
        return filterType;
    }

    public void setFilterType(String filterType) {
        this.filterType = filterType;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
   
   /**
    * Reorganize fieldDetailsList to parent-child structure
    * @param fieldDetailsList
    * @return List<BaseFieldDetails>
    */ 
   public static List<BaseFieldDetails> reStructureFieldDetailsList(FieldDetailsList fieldDetailsList){
        List<BaseFieldDetails> baseFieldDetailsList = new ArrayList<BaseFieldDetails>();
         
        double sequnceNo = 1.0;
        //1. Arrange fielddetailslist to map of fielddetails
        Map<Double, FieldDetails> fieldDetailsMap = getMapOfFieldDetailsList(fieldDetailsList);
        BaseFieldDetails  baseFieldDetails = null;
        //2. Process fielddetails based on sequence
        while (fieldDetailsMap.containsKey(sequnceNo)) {
            
            //3. Get fieldDetails for given sequence
             FieldDetails fieldDetails = fieldDetailsMap.get(sequnceNo);
             
            
             //4. check whether fielddetails id is -1 then consider fielddetails as composite and identify the children otherwise leaf
             if(fieldDetails.getId() == -1){
                 baseFieldDetails = new CompositeFieldDetails(fieldDetails);
                 baseFieldDetails.setChildren(getChildren(fieldDetailsList,fieldDetails.getSequenceNumber()));
             }else{
                 baseFieldDetails = new FieldDetailsLeaf(fieldDetails);
             }
             
             //5. Add to baseFieldDetailsList
             baseFieldDetailsList.add(baseFieldDetails);
             sequnceNo++;
         }
         return baseFieldDetailsList;
   }
   
    /**
     * To get map of sequenceNumber and FieldDetails
     * @param listFieldDetails
     * @return Collection of FieldDetails
     */
    private static Map<Double, FieldDetails> getMapOfFieldDetailsList(FieldDetailsList listFieldDetails) {
        Map<Double, FieldDetails> fieldDetailsMap = new HashMap<Double, FieldDetails>();
        for (FieldDetails details : listFieldDetails) {
             if (details.Qualifier == FieldQualifier.PERM) {
                fieldDetailsMap.put(details.getSequenceNumber(), details);
             }
        }
        return fieldDetailsMap;
    }
    
    /**
    * 
    * @param fieldDetailsList
    * @param parentSeqNo
    * @return 
    */
   private static List<BaseFieldDetails> getChildren(FieldDetailsList fieldDetailsList,double parentSeqNo){
       List<BaseFieldDetails> childrenFieldDetailsList = new ArrayList<BaseFieldDetails>();
       //1. Create the pattern with parent seqeunce number 
        // if parentSquenceNo = 1.01 then allowed children are 1.0101 to 1.0199 
        // if parentSquenceNo = 1.0101 then allowed children are 1.010101 to 1.010199
       String parentSequnceNoStr = String.valueOf(parentSeqNo);
       parentSequnceNoStr = parentSequnceNoStr.replaceAll("0*$", "");
       
       //in case of 1.10 , here child sequence is 10 , but double gives us as 1.1 - which is not actual or expected value
       // we will change the sequenceStr to 1.10 by appending "zero"
       if(Pattern.matches("[1-9].[1-9]", parentSequnceNoStr)){
          parentSequnceNoStr = parentSequnceNoStr + "0" ;
       }
       //2. Create pattern for given parentSeqeunce
       Pattern pattern = Pattern.compile(String.valueOf(parentSequnceNoStr)+"([0-9][1-9]|[1-9])");
       
       BaseFieldDetails baseFieldDetails = null;
       //3. Iterate through the list of fieldDetailsList
       for(FieldDetails details : fieldDetailsList){
           
           
           //4. Check whether fieldDetails sequence number matches with pattern
           if(pattern.matcher(String.valueOf(details.getSequenceNumber())).matches()){
            //if(sequenceDouble < details.getSequenceNumber() && details.getSequenceNumber() < nextSequenceDouble){
               
               //5. check whether id is -1 then create composite fielddetails and get children
                if(details.getId() == -1){
                    baseFieldDetails = new CompositeFieldDetails(details);
                    baseFieldDetails.setChildren(getChildren(fieldDetailsList,details.getSequenceNumber()));
                }else{
                    //6. Create fieldDetailsLeaf
                    baseFieldDetails = new FieldDetailsLeaf(details);
                }
                //7. Add to list
                childrenFieldDetailsList.add(baseFieldDetails);
           }
       }
       return childrenFieldDetailsList;
   }
}
