/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

import java.util.ArrayList;

/**
 *
 * @author sathyaji.raja
 */
public abstract class AbstractView {
    private long viewId;
    private String viewName;
    private String viewType = "NORMAL";
    private String viewCategory = "";
    private long tableRelationId = -1;
    
    public ArrayList<AbstractView> childViews = null;
    
    
    public AbstractView() {
        
    }
    
    public AbstractView(String category) {
        this.viewCategory = category;
    }
    
    public long getViewId() {
        return viewId;
    }

    public void setViewId(long viewId) {
        this.viewId = viewId;
    }

    public String getViewName() {
        return viewName;
    }

    public void setViewName(String viewName) {
        this.viewName = viewName;
    }
    
    public String getViewType() {
        return viewType;
    }

    public void setViewType(String viewType) {
        this.viewType = viewType;
    }
    
    public String getViewCategory() {
        return viewCategory;
    }

    public void setViewCategory(String viewCategory) {
        this.viewCategory = viewCategory;
    }
    
    public long getTableRelationId() {
        return tableRelationId;
    }

    public void setTableRelationId(long argtableRelationId) {
        this.tableRelationId = argtableRelationId;
    }
    
    public ArrayList<AbstractView> getChildViews() {
        return childViews;
    }

    public void setChildViews(ArrayList<AbstractView> argChildViews) {
        this.childViews = argChildViews;
    }
}
