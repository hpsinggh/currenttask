/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.agent;

import com.spectramd.products.focus.common.*;
import com.spectramd.products.focus.common.utils.ThreadUtils;

/**
 *
 * @author ravi.palaparthi
 */
public class FocusArgConfigInitializer {

    /**
     * @param args the command line arguments
     */
    public static void initialize(String[] args) {
        
        try {
            // 1. Initialize logger
            FocusDefaultLogInitializer appInit = new FocusDefaultLogInitializer();
            appInit.Initialize(args);

            if (args[0].equalsIgnoreCase("-client")
                    || args[0].equalsIgnoreCase("client")) {
                    
                // 2. Initialize the configuration
                String clientCode = args[1];
                ThreadUtils.set("FOCUS_CLIENTID", clientCode);
                FocusConfigInitializer.initialize(".\\config\\" + clientCode
                        + "\\focusconfig.properties");
                
            } else if (args[0].equalsIgnoreCase("-version")
                    || args[0].equalsIgnoreCase("version")) {
                    System.out.println("Product Name : FocusMeditechAgent"
                            + ", version = " + "1.0");
                    System.out.println("");
            } else {
                FocusLogger.debug("Cannot get client code from the arguments");
            }
            
        } catch (Exception ex) {
            FocusLogger.error("Error executing measures",ex);
            System.out.println("Failed to execute Job");
        }
    }
}
