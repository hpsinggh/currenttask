/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

/**
 *
 * @author sathyaji.raja
 */
public class ProgramMeasureUtils {
 
    public static long getMeasureQuarterKey(Long inputQuarterKey, Long firstMeasureQuarterKey, 
                                        Long lastMeasureQuarterKey) {
        
        long outputQuarterKey = -1;
        
        if (inputQuarterKey > lastMeasureQuarterKey) {
            outputQuarterKey = lastMeasureQuarterKey;
        } else if (inputQuarterKey >= firstMeasureQuarterKey) {
            outputQuarterKey = inputQuarterKey;
        }
        
        return outputQuarterKey;
    }
}
