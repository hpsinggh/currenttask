/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.common;

//import com.spectramd.products.focus.utils.HtmlUtils;

import java.util.List;


/**
 * 
 * @author pratapkonakala
 */
public abstract class BaseFieldDetails {
    private FieldDetails fieldDetails;
    
    public abstract void addFieldDetails(BaseFieldDetails baseFieldDetails);
    public abstract List<BaseFieldDetails> getChildren();
    public abstract void setChildren(List<BaseFieldDetails> fieldDetailsList);
    
    public BaseFieldDetails(FieldDetails details){
        fieldDetails = details;
    }
    
    public FieldDetails getFieldDetails() {
        return fieldDetails;
    }

    public void setFieldDetails(FieldDetails fieldDetails) {
        this.fieldDetails = fieldDetails;
    }
}
