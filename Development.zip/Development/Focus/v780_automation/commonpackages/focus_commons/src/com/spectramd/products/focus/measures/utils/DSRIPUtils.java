package com.spectramd.products.focus.measures.utils;

import com.spectramd.products.focus.collections.OrderedInsensitiveMap;
import com.spectramd.products.focus.common.DBConfigInfo;
import com.spectramd.products.focus.common.FocusConfig;
import com.spectramd.products.focus.common.FocusException;
import com.spectramd.products.focus.utils.DBConnection;
import com.spectramd.products.focus.utils.DBUtil;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;

/**
 *
 * @author pratap.konakala
 */
public class DSRIPUtils {
    
    private static DataSource dataSource;
    
    public DSRIPUtils(){
        
    }
    public DSRIPUtils(DataSource ds){
        dataSource = ds;
    }
    /**
     * Get Readmit visits for the given index visit
     * @param visitIdentifier
     * @return List of readmits
     * @throws FocusException 
     */
    public static List<OrderedInsensitiveMap> getRedmitVisits(Long visitIdentifier) throws FocusException{
        FocusConfig.getCurrentLogger().writeDebug("Entered into DSRIPReadmitVisitsDAOImpl :: getRedmitVisits");
        List<OrderedInsensitiveMap> readmitVisitslist = new ArrayList<OrderedInsensitiveMap>();
        try{
            Connection con = dataSource.getConnection();
            String query = "{call EH_READMIT_VISITS_DETAILS ('(%s)')}";
            String formattedQuery = String.format(query, visitIdentifier);
            FocusConfig.getCurrentLogger().writeDebug("formattedQuery = "+formattedQuery);
            Statement statement = DBUtil.getStatement(con,100);
            ResultSet resultSet = statement.executeQuery(formattedQuery);
            while (resultSet.next()) {
                readmitVisitslist.add(DBUtil.getResulSetAsMap(resultSet, resultSet.getMetaData()));
            }
        }catch (Exception ex)  {
            FocusConfig.getCurrentLogger().writeError("", ex);
            throw new FocusException("", ex);
        } 
       // FocusConfig.getCurrentLogger().writeDebug("Exited from DSRIPReadmitVisitsDAOImpl :: getRedmitVisits");
        return readmitVisitslist;
        
    }
    
    /**
     * Get all visits with diagnosis  
     * @param visits
     * @param problems
     * @return List<OrderedInsensitiveMap> - Visits
     */
    public static List<OrderedInsensitiveMap> getVisitsWIthDiagnosis(List<OrderedInsensitiveMap> visits,List<OrderedInsensitiveMap> problems) {
        List<OrderedInsensitiveMap> resultList = null;
        if(visits != null && problems != null){
            resultList = new ArrayList<OrderedInsensitiveMap>();
            for (OrderedInsensitiveMap visit : visits) {
                for (OrderedInsensitiveMap problem : problems) {
                    Object problemStartDateTime = problem.get("startDateTime");
                    Object visitStartDateTime = visit.get("startDateTime");
                    Object visitEndDateTime = visit.get("endDateTime");
                    if (problemStartDateTime != null && visitStartDateTime != null && visitEndDateTime != null) {
                        if (DateUtils.getDateValue(problemStartDateTime.toString()) >= DateUtils.getDateValue(visitStartDateTime.toString())
                                && DateUtils.getDateValue(problemStartDateTime.toString()) <= DateUtils.getDateValue(visitEndDateTime.toString())) {
                            resultList.add(visit);
                        }
                    }
                }
            }
        }
        return resultList;
    }
    
}
