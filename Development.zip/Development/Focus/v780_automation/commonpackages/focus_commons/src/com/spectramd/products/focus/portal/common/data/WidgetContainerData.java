/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.portal.common.data;

/**
 *
 * @author rpalaparthi
 */
public abstract class WidgetContainerData {
    
    private String id = "";
    private String type;
    
    private WidgetStyle style = null;
    
    private int width;
    private int height;
    
    private String htmlHeader;
    
    public String getId() {
        return id;
    }
    
    public void setId(String widgetId)    {
        id = widgetId;
    }
    
    public String getType() {
        return type;
    }
    
    public void setType(String widgetType) {
        type = widgetType;
    }
    
    public WidgetStyle getStyle()   {
        return style;
    }
    
    public void setStyle(WidgetStyle widgetStyle)   {
        style = widgetStyle;
    }
    
    public int getHeight() {
        return height;
    }

    public void setHeight(int chartHeight) {
        this.height = chartHeight;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int chartWidth) {
        this.width = chartWidth;
    }

    /**
     * @return the htmlHeader
     */
    public String getHtmlHeader() {
        return htmlHeader;
    }

    /**
     * @param htmlHeader the htmlHeader to set
     */
    public void setHtmlHeader(String htmlHeader) {
        this.htmlHeader = htmlHeader;
    }
}
