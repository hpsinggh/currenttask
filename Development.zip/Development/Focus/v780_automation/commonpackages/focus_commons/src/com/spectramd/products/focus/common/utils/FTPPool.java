/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.common.utils;

import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import org.ftp4che.FTPConnection;
import org.ftp4che.FTPConnectionFactory;

/**
 *
 * @author sathyaji.raja
 */
// Currently it is a singleton, but to be changed to a pool
public class FTPPool {
 
    public static FTPPool pool = new FTPPool();
    private FTPConnection connection = null;
    private static int count = 0;
    
    private FTPPool() {
        
    }
    
    public static FTPPool getInstance() {
        return pool;
    }
    
    public synchronized FTPConnection getConnection(FTPInfo ftpInfo) throws Exception {
        
         if (connection == null || count==0) {
            Properties ftpProperties = FTPUtils.getProperties(ftpInfo);
            connection = FTPConnectionFactory.getInstance(ftpProperties);
            connection.connect();
            connection.noOperation();
         }
         count++;
         
         return connection;
    }
    
    
     public synchronized void release() throws Exception {
        
         count--;
         if (count == 0 && connection != null) {
             //connection.disconnect();
             connection=null;
         }
     }
 
    
}
