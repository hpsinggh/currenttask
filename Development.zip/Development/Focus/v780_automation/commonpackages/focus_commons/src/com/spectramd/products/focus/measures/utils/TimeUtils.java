/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spectramd.products.focus.measures.utils;

import com.spectramd.products.focus.common.FocusLogger;

/**
 *
 * @author sathyaji.raja
 */
public class TimeUtils {

    public static double getTimeInDouble(String admitTime)   {
        double timeValue = -1;
        
        if (admitTime != null)  {
            int colonIndex = admitTime.indexOf(":");
            if (colonIndex != -1)   {
                String revisedTime = admitTime.replace(":", ".");
                
                try {
                    timeValue = Double.parseDouble(revisedTime) ;
                } catch (Exception ex)  {
                      // do nothing..
                }
            }
        }
        
        return timeValue;
    }
}
